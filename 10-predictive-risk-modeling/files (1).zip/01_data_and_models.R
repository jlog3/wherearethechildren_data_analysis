###############################################################################
#  CHILD WELFARE PREDICTIVE RISK MODELING — TIDYMODELS FRAMEWORK
#  Events: (1) Substance-Related Removal  (2) Infant Entry Flag
#          (3) Runaway from Placement     (4) In-Care Maltreatment
#
#  Predictors: demographics, prior removals, placement type, county factors
#  Methods:    logistic regression, random forest, multilevel (glmer proxy)
#  Evaluation: AUC, accuracy, sensitivity, specificity, calibration
###############################################################################

# ── 0. LIBRARIES ─────────────────────────────────────────────────────────────
suppressPackageStartupMessages({
  library(tidyverse)
  library(tidymodels)
  library(vip)            # variable importance
  library(probably)       # calibration
  library(patchwork)      # plot composition
  library(ranger)         # fast random forests
  library(glue)
  library(knitr)
})

tidymodels_prefer()
set.seed(2024)

cat("
+================================================================+
|   CHILD WELFARE PREDICTIVE RISK MODELING PIPELINE              |
|   Four Events - Three Model Types - Full Evaluation Suite      |
+================================================================+
\n")

# ── 1. SYNTHETIC DATA GENERATION ─────────────────────────────────────────────
#
#  Realistic child-welfare data reflecting AFCARS/NCANDS field structures.
#  In production, replace with actual mandated public-use data files.

n <- 8000   # cases

counties <- tibble(
  county_id   = 1:40,
  county_name = paste0("County_", str_pad(1:40, 2, pad = "0")),
  poverty_rate      = runif(40, 0.08, 0.35),
  caseworker_ratio  = runif(40, 15, 55),
  rural_flag        = sample(0:1, 40, replace = TRUE, prob = c(0.6, 0.4)),
  resource_index    = rnorm(40, 0, 1)
)

generate_cases <- function(n, counties) {
  df <- tibble(
    case_id        = 1:n,
    county_id      = sample(counties$county_id, n, replace = TRUE),
    age_at_entry   = pmax(0, round(rnorm(n, 7, 5))),
    is_infant      = as.integer(age_at_entry < 1),
    sex            = sample(c("Male", "Female"), n, replace = TRUE),
    race_ethnicity = sample(
      c("White", "Black", "Hispanic", "Native_American", "Asian", "Multiracial"),
      n, replace = TRUE,
      prob = c(0.40, 0.25, 0.20, 0.06, 0.04, 0.05)
    ),
    disability_flag = rbinom(n, 1, 0.12),
    prior_removals     = rpois(n, 0.6),
    prior_reports      = rpois(n, 1.8),
    prior_services     = rpois(n, 1.2),
    parent_substance_hx = rbinom(n, 1, 0.30),
    parent_incarcerated = rbinom(n, 1, 0.12),
    domestic_violence   = rbinom(n, 1, 0.22),
    placement_type = sample(
      c("Foster_Family", "Kinship", "Group_Home", "Institution", "Trial_Home_Visit"),
      n, replace = TRUE,
      prob = c(0.40, 0.25, 0.15, 0.12, 0.08)
    ),
    placement_stability = rpois(n, 1.5),
    months_in_care     = pmax(1, round(rexp(n, 0.05))),
    fiscal_year = sample(2019:2023, n, replace = TRUE)
  ) %>%
    left_join(counties, by = "county_id")

  logistic <- function(x) 1 / (1 + exp(-x))

  df <- df %>%
    mutate(
      # Event 1: Substance-related removal
      eta_substance = -2.0
        + 0.6 * parent_substance_hx
        + 0.3 * prior_removals
        + 0.2 * domestic_violence
        + 0.4 * (placement_type == "Group_Home")
        + 0.25 * poverty_rate * 3
        + 0.15 * caseworker_ratio / 30
        + rnorm(n, 0, 0.3),
      substance_removal = rbinom(n, 1, logistic(eta_substance)),

      # Event 2: Infant entry flag
      eta_infant = -2.5
        + 2.5 * is_infant
        + 0.5 * parent_substance_hx
        + 0.4 * prior_removals
        + 0.3 * domestic_violence
        + 0.35 * poverty_rate * 3
        + 0.2 * parent_incarcerated
        + rnorm(n, 0, 0.3),
      infant_entry = rbinom(n, 1, logistic(eta_infant)),

      # Event 3: Runaway
      eta_runaway = -3.0
        + 0.08 * age_at_entry
        + 0.5 * (placement_type == "Group_Home")
        + 0.6 * (placement_type == "Institution")
        + 0.3 * placement_stability
        + 0.02 * months_in_care
        - 0.4 * (placement_type == "Kinship")
        + 0.2 * prior_removals
        + rnorm(n, 0, 0.3),
      runaway = rbinom(n, 1, logistic(eta_runaway)),

      # Event 4: In-care maltreatment
      eta_maltreat = -3.2
        + 0.35 * placement_stability
        + 0.4 * (placement_type == "Group_Home")
        + 0.3 * (placement_type == "Institution")
        + 0.25 * caseworker_ratio / 30
        + 0.2 * prior_reports
        + 0.15 * disability_flag
        - 0.3 * (placement_type == "Kinship")
        + rnorm(n, 0, 0.3),
      in_care_maltreatment = rbinom(n, 1, logistic(eta_maltreat))
    ) %>%
    mutate(across(
      c(substance_removal, infant_entry, runaway, in_care_maltreatment),
      ~ factor(., levels = c(1, 0), labels = c("Event", "No_Event"))
    ))

  df
}

cases <- generate_cases(n, counties)

cat("Base rates:\n")
events <- c("substance_removal", "infant_entry", "runaway", "in_care_maltreatment")
walk(events, ~ cat(sprintf("  %s: %.1f%%\n", .x, mean(cases[[.x]] == "Event") * 100)))

# ── 2. FEATURE ENGINEERING RECIPE ────────────────────────────────────────────

build_recipe <- function(outcome, data) {
  predictors <- c(
    "age_at_entry", "sex", "race_ethnicity", "disability_flag",
    "prior_removals", "prior_reports", "prior_services",
    "parent_substance_hx", "parent_incarcerated", "domestic_violence",
    "placement_type", "placement_stability", "months_in_care",
    "poverty_rate", "caseworker_ratio", "rural_flag", "resource_index"
  )
  f <- as.formula(paste(outcome, "~", paste(predictors, collapse = " + ")))

  recipe(f, data = data) %>%
    step_dummy(all_nominal_predictors(), one_hot = TRUE) %>%
    step_normalize(all_numeric_predictors()) %>%
    step_zv(all_predictors()) %>%
    step_corr(all_numeric_predictors(), threshold = 0.90)
}

# ── 3. MODEL SPECIFICATIONS ─────────────────────────────────────────────────

spec_logistic <- logistic_reg(penalty = 0.001, mixture = 1) %>%
  set_engine("glm") %>%
  set_mode("classification")

spec_rf <- rand_forest(mtry = 6, trees = 500, min_n = 10) %>%
  set_engine("ranger", importance = "impurity") %>%
  set_mode("classification")

spec_multilevel_proxy <- logistic_reg(penalty = 0.01, mixture = 0.5) %>%
  set_engine("glmnet") %>%
  set_mode("classification")

model_specs <- list(
  logistic_reg = spec_logistic,
  random_forest = spec_rf,
  multilevel_proxy = spec_multilevel_proxy
)

# ── 4. TRAIN / EVALUATE PIPELINE ────────────────────────────────────────────

train_and_evaluate <- function(outcome_var, data, model_specs) {
  cat(sprintf("\n====== %s ======\n", outcome_var))

  split <- initial_split(data, prop = 0.75, strata = !!sym(outcome_var))
  train <- training(split)
  test  <- testing(split)
  rec <- build_recipe(outcome_var, train)
  folds <- vfold_cv(train, v = 5, strata = !!sym(outcome_var))

  results <- list()

  for (mod_name in names(model_specs)) {
    cat(sprintf("  Training %s...\n", mod_name))

    wf <- workflow() %>%
      add_recipe(rec) %>%
      add_model(model_specs[[mod_name]])

    cv_results <- fit_resamples(
      wf, folds,
      metrics = metric_set(roc_auc, accuracy, sensitivity, specificity),
      control = control_resamples(save_pred = TRUE)
    )

    cv_metrics <- collect_metrics(cv_results) %>%
      mutate(model = mod_name, outcome = outcome_var)

    final_fit <- last_fit(wf, split,
                          metrics = metric_set(roc_auc, accuracy, sensitivity, specificity))

    test_metrics <- collect_metrics(final_fit) %>%
      mutate(model = mod_name, outcome = outcome_var)

    test_preds <- collect_predictions(final_fit)

    vip_data <- NULL
    tryCatch({
      fitted_wf <- fit(wf, train)
      vip_data <- vi(extract_fit_parsnip(fitted_wf)) %>%
        mutate(model = mod_name, outcome = outcome_var)
    }, error = function(e) NULL)

    results[[mod_name]] <- list(
      cv_metrics   = cv_metrics,
      test_metrics = test_metrics,
      test_preds   = test_preds,
      vip_data     = vip_data,
      final_fit    = final_fit
    )

    auc_val <- test_metrics %>% filter(.metric == "roc_auc") %>% pull(.estimate)
    cat(sprintf("    Test AUC: %.3f\n", auc_val))
  }

  results
}

all_results <- map(set_names(events), ~ train_and_evaluate(.x, cases, model_specs))

cat("\nAll models trained and evaluated.\n")

# ── 5. CONSOLIDATED METRICS TABLE ────────────────────────────────────────────

metrics_table <- map_dfr(events, function(ev) {
  map_dfr(names(model_specs), function(mod) {
    all_results[[ev]][[mod]]$test_metrics
  })
}) %>%
  select(outcome, model, .metric, .estimate) %>%
  pivot_wider(names_from = .metric, values_from = .estimate) %>%
  arrange(outcome, desc(roc_auc))

cat("\n+============================================================+")
cat("\n|              TEST SET PERFORMANCE SUMMARY                   |")
cat("\n+============================================================+\n\n")
print(knitr::kable(metrics_table, digits = 3, format = "simple"))

# ── 6. VARIABLE IMPORTANCE PLOTS ─────────────────────────────────────────────

vip_plots <- map(events, function(ev) {
  vip_df <- all_results[[ev]][["random_forest"]]$vip_data
  if (is.null(vip_df)) return(NULL)

  vip_df %>%
    slice_max(Importance, n = 12) %>%
    mutate(Variable = fct_reorder(Variable, Importance)) %>%
    ggplot(aes(Importance, Variable)) +
    geom_col(fill = "#2563EB", alpha = 0.85) +
    labs(
      title = gsub("_", " ", ev) %>% tools::toTitleCase(),
      subtitle = "Random Forest - Top 12 Predictors",
      x = "Importance (Impurity)", y = NULL
    ) +
    theme_minimal(base_size = 11) +
    theme(plot.title = element_text(face = "bold"))
})

vip_combined <- wrap_plots(vip_plots, ncol = 2) +
  plot_annotation(
    title = "Predictive Risk Models - Variable Importance",
    subtitle = "Random forest impurity-based importance across four child welfare events",
    theme = theme(
      plot.title = element_text(size = 16, face = "bold"),
      plot.subtitle = element_text(size = 11, color = "grey40")
    )
  )

ggsave("output/variable_importance.png", vip_combined,
       width = 14, height = 10, dpi = 200, bg = "white")

cat("Variable importance plots saved.\n")

# ── 7. ROC CURVES ────────────────────────────────────────────────────────────

roc_plots <- map(events, function(ev) {
  preds <- map_dfr(names(model_specs), function(mod) {
    all_results[[ev]][[mod]]$test_preds %>% mutate(model = mod)
  })

  preds %>%
    group_by(model) %>%
    roc_curve(truth = !!sym(ev), .pred_Event) %>%
    ggplot(aes(1 - specificity, sensitivity, color = model)) +
    geom_line(linewidth = 1) +
    geom_abline(lty = 2, color = "grey60") +
    scale_color_manual(values = c("#2563EB", "#DC2626", "#059669")) +
    labs(
      title = gsub("_", " ", ev) %>% tools::toTitleCase(),
      x = "False Positive Rate", y = "True Positive Rate", color = "Model"
    ) +
    theme_minimal(base_size = 10) +
    theme(legend.position = "bottom", plot.title = element_text(face = "bold"))
})

roc_combined <- wrap_plots(roc_plots, ncol = 2) +
  plot_annotation(
    title = "ROC Curves - Model Comparison",
    subtitle = "Test set performance across four risk events",
    theme = theme(
      plot.title = element_text(size = 16, face = "bold"),
      plot.subtitle = element_text(size = 11, color = "grey40")
    )
  )

ggsave("output/roc_curves.png", roc_combined,
       width = 14, height = 10, dpi = 200, bg = "white")
cat("ROC curve plots saved.\n")

# ── 8. RISK SCORE DISTRIBUTIONS ─────────────────────────────────────────────

risk_dist_plots <- map(events, function(ev) {
  preds <- all_results[[ev]][["random_forest"]]$test_preds

  preds %>%
    ggplot(aes(.pred_Event, fill = !!sym(ev))) +
    geom_density(alpha = 0.6) +
    scale_fill_manual(values = c("Event" = "#DC2626", "No_Event" = "#2563EB")) +
    labs(
      title = gsub("_", " ", ev) %>% tools::toTitleCase(),
      x = "Predicted Risk Score", y = "Density", fill = "Actual"
    ) +
    theme_minimal(base_size = 10) +
    theme(legend.position = "bottom", plot.title = element_text(face = "bold"))
})

risk_combined <- wrap_plots(risk_dist_plots, ncol = 2) +
  plot_annotation(
    title = "Risk Score Distributions",
    subtitle = "Random Forest predicted probabilities by actual outcome",
    theme = theme(
      plot.title = element_text(size = 16, face = "bold"),
      plot.subtitle = element_text(size = 11, color = "grey40")
    )
  )

ggsave("output/risk_distributions.png", risk_combined,
       width = 14, height = 10, dpi = 200, bg = "white")
cat("Risk distribution plots saved.\n")

# ── 9. PREDICTION TABLES ────────────────────────────────────────────────────

prediction_table <- map_dfr(events, function(ev) {
  all_results[[ev]][["random_forest"]]$test_preds %>%
    mutate(outcome = ev) %>%
    select(outcome, .row, .pred_Event, .pred_No_Event, .pred_class,
           truth = !!sym(ev)) %>%
    mutate(risk_tier = case_when(
      .pred_Event >= 0.7 ~ "Critical",
      .pred_Event >= 0.4 ~ "High",
      .pred_Event >= 0.2 ~ "Moderate",
      TRUE               ~ "Low"
    ))
})

write_csv(prediction_table, "output/prediction_table.csv")

tier_summary <- prediction_table %>%
  group_by(outcome, risk_tier) %>%
  summarise(
    n = n(),
    actual_event_rate = mean(truth == "Event"),
    mean_pred_score   = mean(.pred_Event),
    .groups = "drop"
  ) %>%
  arrange(outcome, desc(mean_pred_score))

cat("\n+============================================================+")
cat("\n|              RISK TIER SUMMARY                              |")
cat("\n+============================================================+\n\n")
print(knitr::kable(tier_summary, digits = 3, format = "simple"))

write_csv(tier_summary, "output/risk_tier_summary.csv")
write_csv(metrics_table, "output/model_metrics.csv")

# ── 10. SAVE MODEL OBJECTS ───────────────────────────────────────────────────

walk(events, function(ev) {
  walk(names(model_specs), function(mod) {
    saveRDS(
      all_results[[ev]][[mod]]$final_fit,
      sprintf("output/model_%s_%s.rds", ev, mod)
    )
  })
})

cat("Model objects saved to output/\n")

cat("
+================================================================+
|   PIPELINE COMPLETE                                            |
|                                                                |
|   Outputs:                                                     |
|   - output/model_metrics.csv          Performance table        |
|   - output/prediction_table.csv       Case-level scores        |
|   - output/risk_tier_summary.csv      Tier distributions       |
|   - output/variable_importance.png    VIP plots                |
|   - output/roc_curves.png             ROC comparisons          |
|   - output/risk_distributions.png     Score densities          |
|   - output/model_*.rds                Serialized models        |
+================================================================+
\n")
