###############################################################################
#  SUPPLEMENT: TRUE MULTILEVEL / MIXED-EFFECTS MODELS (lme4::glmer)
#  
#  Extends the main pipeline with genuine random intercept models
#  where county is a grouping factor (random effect).
###############################################################################

library(tidyverse)
library(lme4)
library(broom.mixed)
library(performance)
library(sjPlot)

set.seed(2024)

cat("
+================================================================+
|   MULTILEVEL LOGISTIC MODELS (glmer) — COUNTY RANDOM EFFECTS   |
+================================================================+
\n")

# Assumes 'cases' is already loaded from 01_data_and_models.R
# If running standalone, source it:
# source("01_data_and_models.R")

# ── Convert outcomes back to numeric for glmer ───────────────────────────────

cases_numeric <- cases %>%
  mutate(across(
    c(substance_removal, infant_entry, runaway, in_care_maltreatment),
    ~ as.integer(. == "Event")
  ))

# ── Fit multilevel models ────────────────────────────────────────────────────

events <- c("substance_removal", "infant_entry", "runaway", "in_care_maltreatment")

fit_multilevel <- function(outcome, data) {
  f <- as.formula(paste0(
    outcome, " ~ age_at_entry + sex + race_ethnicity + disability_flag +
    prior_removals + prior_reports + parent_substance_hx +
    domestic_violence + placement_type + placement_stability +
    months_in_care + poverty_rate + caseworker_ratio + rural_flag +
    (1 | county_id)"
  ))

  cat(sprintf("Fitting glmer for %s...\n", outcome))

  model <- glmer(f, data = data, family = binomial,
                 control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))

  cat(sprintf("  ICC: %.3f\n", performance::icc(model)$ICC_adjusted))
  cat(sprintf("  AIC: %.1f\n", AIC(model)))

  model
}

multilevel_models <- map(set_names(events), ~ fit_multilevel(.x, cases_numeric))

# ── Extract and compare random effects ───────────────────────────────────────

cat("\n── County-Level Random Intercepts ──\n\n")

re_summary <- map_dfr(events, function(ev) {
  ranef(multilevel_models[[ev]])$county_id %>%
    rownames_to_column("county_id") %>%
    rename(intercept = `(Intercept)`) %>%
    mutate(outcome = ev, county_id = as.integer(county_id))
})

# Counties with consistently high risk across events
high_risk_counties <- re_summary %>%
  group_by(county_id) %>%
  summarise(
    mean_intercept = mean(intercept),
    n_above_avg    = sum(intercept > 0),
    .groups = "drop"
  ) %>%
  arrange(desc(mean_intercept)) %>%
  head(10)

cat("Top 10 counties by mean random intercept (consistently elevated risk):\n\n")
print(knitr::kable(high_risk_counties, digits = 3, format = "simple"))

# ── Fixed effects comparison ─────────────────────────────────────────────────

cat("\n── Fixed Effects Summary ──\n\n")

fixed_effects <- map_dfr(events, function(ev) {
  tidy(multilevel_models[[ev]], effects = "fixed", conf.int = TRUE) %>%
    mutate(outcome = ev)
})

top_effects <- fixed_effects %>%
  filter(term != "(Intercept)") %>%
  group_by(outcome) %>%
  slice_max(abs(estimate), n = 5) %>%
  select(outcome, term, estimate, std.error, p.value) %>%
  arrange(outcome, desc(abs(estimate)))

print(knitr::kable(top_effects, digits = 3, format = "simple"))

# ── Save outputs ─────────────────────────────────────────────────────────────

write_csv(re_summary, "output/county_random_effects.csv")
write_csv(fixed_effects, "output/multilevel_fixed_effects.csv")

walk(events, function(ev) {
  saveRDS(multilevel_models[[ev]], sprintf("output/model_%s_glmer.rds", ev))
})

cat("\nMultilevel model objects and summaries saved to output/\n")

# ── Variance partition & model diagnostics ───────────────────────────────────

cat("\n── Model Diagnostics ──\n\n")

walk(events, function(ev) {
  mod <- multilevel_models[[ev]]
  cat(sprintf("\n%s:\n", ev))
  cat(sprintf("  Groups: %d counties\n", ngrps(mod)))
  cat(sprintf("  Observations: %d\n", nobs(mod)))
  cat(sprintf("  Random effect SD: %.3f\n",
              as.data.frame(VarCorr(mod))$sdcor[1]))

  # Convergence check
  if (length(mod@optinfo$conv$lme4$messages) > 0) {
    cat("  WARNING: Convergence issues detected\n")
  } else {
    cat("  Convergence: OK\n")
  }
})

cat("\n
+================================================================+
|   MULTILEVEL ANALYSIS COMPLETE                                 |
|                                                                |
|   Key outputs:                                                 |
|   - County random intercepts identify systematic variation     |
|   - Fixed effects show within-county predictor relationships   |
|   - ICC values quantify county-level clustering                |
|   - Use random effects to flag counties needing resources      |
+================================================================+
\n")
