# Child Welfare Predictive Risk Modeling System

## Overview

This project implements a complete predictive risk modeling pipeline for four child welfare adverse events using R's `tidymodels` framework, with a fully interactive Shiny dashboard prototype for operational deployment.

## Events Modeled

| # | Event | Description | Typical Base Rate |
|---|-------|-------------|-------------------|
| 1 | **Substance-Related Removal** | Child removed due to caregiver substance abuse | ~22% |
| 2 | **Infant Entry Flag** | Infant (<1 year) entry into foster care system | ~18% |
| 3 | **Runaway from Placement** | Youth absconds from foster/residential placement | ~12% |
| 4 | **In-Care Maltreatment** | Maltreatment occurring while child is in state custody | ~14% |

## Predictor Categories

- **Demographics**: age at entry, sex, race/ethnicity, disability status
- **Prior System Involvement**: prior removals, prior reports, prior services
- **Family Factors**: parental substance history, incarceration, domestic violence
- **Placement Characteristics**: placement type, stability (number of moves), months in care
- **County-Level Factors**: poverty rate, caseworker caseload ratio, rural/urban flag, resource index

## Model Architectures

1. **Logistic Regression** (L1-penalized via `glm`) — interpretable baseline
2. **Random Forest** (`ranger`, 500 trees) — nonlinear ensemble, best predictive performance
3. **Multilevel/Elastic Net** (`glmnet`, α=0.5) — captures county-level variation through penalization
4. **True Multilevel** (`lme4::glmer`) — random intercepts for county clustering (supplementary script)

## File Structure

```
predictive_risk_modeling/
├── 01_data_and_models.R          # Main pipeline: data gen, training, evaluation, plots
├── 02_shiny_dashboard.R          # Production Shiny app with 6 tabs
├── 03_multilevel_models.R        # True glmer mixed-effects extension
├── dashboard_prototype.html      # Interactive HTML dashboard prototype
├── README.md                     # This file
└── output/                       # Generated artifacts
    ├── model_metrics.csv         # Performance comparison table
    ├── prediction_table.csv      # Case-level risk scores & tiers
    ├── risk_tier_summary.csv     # Tier distribution summary
    ├── variable_importance.png   # VIP plots (4 events × RF)
    ├── roc_curves.png            # ROC comparison (3 models × 4 events)
    ├── risk_distributions.png    # Score density plots
    ├── county_random_effects.csv # glmer county intercepts
    ├── multilevel_fixed_effects.csv
    └── model_*.rds               # Serialized model objects
```

## Running the Pipeline

```r
# 1. Install dependencies
install.packages(c("tidymodels", "vip", "probably", "patchwork",
                    "ranger", "glue", "knitr", "lme4", "broom.mixed",
                    "performance", "sjPlot", "shiny", "shinydashboard",
                    "DT", "plotly"))

# 2. Run main pipeline
setwd("predictive_risk_modeling")
dir.create("output", showWarnings = FALSE)
source("01_data_and_models.R")

# 3. Run multilevel extension
source("03_multilevel_models.R")

# 4. Launch Shiny dashboard
shiny::runApp("02_shiny_dashboard.R")
```

## Evaluation Metrics

All models evaluated via 5-fold stratified cross-validation and held-out test set:

- **AUC (ROC)** — discrimination ability
- **Accuracy** — overall classification correctness
- **Sensitivity** — true positive rate (catching actual events)
- **Specificity** — true negative rate (avoiding false flags)
- **Calibration** — predicted probabilities vs. observed rates

## Risk Tier Definitions

| Tier | Score Range | Recommended Action |
|------|-------------|-------------------|
| **Critical** | ≥ 70% | Immediate supervisor review, enhanced monitoring |
| **High** | 40–69% | Priority case review within 48 hours |
| **Moderate** | 20–39% | Standard monitoring with periodic reassessment |
| **Low** | < 20% | Routine case management |

## Dashboard Features

The Shiny dashboard (and HTML prototype) includes:

1. **Risk Overview** — KPI cards, score distributions, tier breakdowns, flagged case table
2. **Case Lookup** — Individual case risk profiles with demographic context
3. **County Analysis** — Geographic risk heatmap, poverty-risk correlation, top-risk counties
4. **Model Performance** — AUC comparison bars, calibration curves, full metrics table
5. **What-If Scenarios** — Interactive scenario builder with radar chart risk profiles
6. **About** — Methodology documentation and ethical guardrails

## Ethical Considerations

Predictive risk models in child welfare require extraordinary care:

- **Decision Support, Not Decision Making**: Scores trigger enhanced review, never automatic action
- **Racial Equity Auditing**: Regular disparate impact analysis across race/ethnicity groups
- **Transparency**: Variable importance and model explanations available to all stakeholders
- **Recalibration**: Models must be retrained periodically as populations and policies shift
- **Human Oversight**: Every flagged case requires professional caseworker judgment
- **Data Quality**: Model performance depends entirely on mandated reporting completeness

## Data Sources (Production)

In production deployment, replace synthetic data with:

- **AFCARS** (Adoption and Foster Care Analysis and Reporting System)
- **NCANDS** (National Child Abuse and Neglect Data System)
- **State-level administrative data** (county characteristics, workforce data)
- **ACS/Census** (poverty rates, demographic context)

## Policy Value Proposition

This system demonstrates how mandated public child welfare data can power actionable analytics:

1. **Early identification** of children at elevated risk before adverse events occur
2. **Resource allocation** guided by county-level risk patterns and caseload analysis
3. **Accountability metrics** tracking whether high-risk cases receive enhanced services
4. **Transparency** in how publicly mandated data translates to better child outcomes
