###############################################################################
#  SHINY RISK FLAGGING DASHBOARD — PRODUCTION PROTOTYPE
#  
#  This app loads trained model objects and provides:
#   1. Case-level risk scoring with color-coded flags
#   2. County-level risk heat maps
#   3. Model performance monitoring
#   4. Individual case lookup and "what-if" scenario tool
#
#  Launch: shiny::runApp("02_shiny_dashboard.R")
###############################################################################

library(shiny)
library(shinydashboard)
library(tidyverse)
library(DT)
library(plotly)

# ── UI ───────────────────────────────────────────────────────────────────────

ui <- dashboardPage(
  skin = "blue",

  dashboardHeader(title = "Child Welfare Risk Intelligence"),

  dashboardSidebar(
    sidebarMenu(
      menuItem("Risk Overview",    tabName = "overview",  icon = icon("gauge-high")),
      menuItem("Case Lookup",      tabName = "lookup",    icon = icon("magnifying-glass")),
      menuItem("County Analysis",  tabName = "county",    icon = icon("map")),
      menuItem("Model Performance",tabName = "perf",      icon = icon("chart-line")),
      menuItem("What-If Scenarios",tabName = "whatif",    icon = icon("sliders")),
      menuItem("About",           tabName = "about",      icon = icon("circle-info"))
    ),
    hr(),
    selectInput("event_select", "Risk Event:",
      choices = c(
        "Substance Removal"     = "substance_removal",
        "Infant Entry"          = "infant_entry",
        "Runaway"               = "runaway",
        "In-Care Maltreatment"  = "in_care_maltreatment"
      )
    ),
    sliderInput("threshold", "Risk Threshold:", 0, 1, 0.4, 0.05)
  ),

  dashboardBody(
    tags$head(tags$style(HTML("
      .critical-flag { background-color: #DC2626; color: white;
                       padding: 4px 10px; border-radius: 4px; font-weight: bold; }
      .high-flag     { background-color: #F59E0B; color: white;
                       padding: 4px 10px; border-radius: 4px; font-weight: bold; }
      .moderate-flag { background-color: #3B82F6; color: white;
                       padding: 4px 10px; border-radius: 4px; }
      .low-flag      { background-color: #10B981; color: white;
                       padding: 4px 10px; border-radius: 4px; }
      .content-wrapper { background-color: #F8FAFC; }
      .box { border-top: 3px solid #2563EB; }
    "))),

    tabItems(

      # ── TAB 1: OVERVIEW ─────────────────────────────────────────────────
      tabItem(tabName = "overview",
        fluidRow(
          valueBoxOutput("total_cases",    width = 3),
          valueBoxOutput("critical_count", width = 3),
          valueBoxOutput("high_count",     width = 3),
          valueBoxOutput("avg_auc",        width = 3)
        ),
        fluidRow(
          box(title = "Risk Distribution", width = 6,
              status = "primary", solidHeader = TRUE,
              plotlyOutput("risk_histogram", height = "350px")),
          box(title = "Flagged Cases by Tier", width = 6,
              status = "primary", solidHeader = TRUE,
              plotlyOutput("tier_bar", height = "350px"))
        ),
        fluidRow(
          box(title = "High-Risk Cases Requiring Review", width = 12,
              status = "danger", solidHeader = TRUE,
              DTOutput("flagged_table"))
        )
      ),

      # ── TAB 2: CASE LOOKUP ──────────────────────────────────────────────
      tabItem(tabName = "lookup",
        fluidRow(
          box(title = "Individual Case Risk Profile", width = 12,
              status = "primary", solidHeader = TRUE,
              numericInput("case_id_input", "Enter Case ID:", value = 1,
                           min = 1, max = 8000),
              actionButton("lookup_btn", "Look Up", class = "btn-primary"),
              hr(),
              fluidRow(
                column(4, uiOutput("case_demographics")),
                column(4, uiOutput("case_history")),
                column(4, uiOutput("case_risk_scores"))
              )
          )
        )
      ),

      # ── TAB 3: COUNTY ANALYSIS ─────────────────────────────────────────
      tabItem(tabName = "county",
        fluidRow(
          box(title = "County Risk Heat Map", width = 12,
              status = "primary", solidHeader = TRUE,
              plotlyOutput("county_heatmap", height = "500px"))
        ),
        fluidRow(
          box(title = "County Characteristics vs. Risk Rates", width = 6,
              status = "info", solidHeader = TRUE,
              plotlyOutput("county_scatter", height = "350px")),
          box(title = "Top 10 Highest-Risk Counties", width = 6,
              status = "warning", solidHeader = TRUE,
              DTOutput("county_table"))
        )
      ),

      # ── TAB 4: MODEL PERFORMANCE ───────────────────────────────────────
      tabItem(tabName = "perf",
        fluidRow(
          box(title = "Model Comparison — AUC by Event", width = 6,
              status = "primary", solidHeader = TRUE,
              plotlyOutput("auc_comparison", height = "350px")),
          box(title = "Calibration Curve", width = 6,
              status = "primary", solidHeader = TRUE,
              plotlyOutput("calibration_plot", height = "350px"))
        ),
        fluidRow(
          box(title = "Full Metrics Table", width = 12,
              status = "info", solidHeader = TRUE,
              DTOutput("metrics_table"))
        )
      ),

      # ── TAB 5: WHAT-IF SCENARIOS ───────────────────────────────────────
      tabItem(tabName = "whatif",
        fluidRow(
          box(title = "Scenario Builder", width = 4,
              status = "primary", solidHeader = TRUE,
              helpText("Adjust case characteristics to see predicted risk."),
              sliderInput("wf_age", "Age at Entry:", 0, 17, 5),
              selectInput("wf_sex", "Sex:", c("Male", "Female")),
              selectInput("wf_placement", "Placement Type:",
                c("Foster_Family", "Kinship", "Group_Home",
                  "Institution", "Trial_Home_Visit")),
              sliderInput("wf_prior_removals", "Prior Removals:", 0, 5, 0),
              checkboxInput("wf_substance", "Parent Substance History"),
              checkboxInput("wf_dv", "Domestic Violence"),
              sliderInput("wf_stability", "Placement Moves:", 0, 10, 1),
              sliderInput("wf_poverty", "County Poverty Rate:", 0.05, 0.40, 0.15),
              sliderInput("wf_caseload", "Caseworker Caseload:", 10, 60, 25),
              actionButton("predict_btn", "Predict Risk", class = "btn-danger btn-lg")
          ),
          box(title = "Predicted Risk Scores", width = 8,
              status = "danger", solidHeader = TRUE,
              uiOutput("scenario_results"),
              hr(),
              plotlyOutput("scenario_radar", height = "400px"))
        )
      ),

      # ── TAB 6: ABOUT ───────────────────────────────────────────────────
      tabItem(tabName = "about",
        box(title = "About This Dashboard", width = 12,
            status = "primary", solidHeader = TRUE,
            h4("Child Welfare Predictive Risk Intelligence System"),
            p("This prototype demonstrates how mandated public child welfare
              data (AFCARS, NCANDS) can power predictive risk models to
              identify children at elevated risk of adverse events."),
            h5("Models"),
            p("Three model architectures are trained for each of four events:"),
            tags$ul(
              tags$li(strong("Logistic Regression"), "— Interpretable baseline"),
              tags$li(strong("Random Forest"), "— Nonlinear ensemble for best accuracy"),
              tags$li(strong("Multilevel Proxy (Elastic Net)"),
                      "— Captures county-level variation via penalized regression")
            ),
            h5("Events Modeled"),
            tags$ol(
              tags$li("Substance-Related Removal"),
              tags$li("Infant Entry into Foster Care"),
              tags$li("Runaway from Placement"),
              tags$li("In-Care Maltreatment")
            ),
            h5("Ethical Considerations"),
            p("Predictive risk models in child welfare must be deployed with
              extreme care. This tool is designed to support — not replace —
              professional judgment. Risk scores should trigger enhanced review,
              not automatic action. Racial equity audits and regular model
              recalibration are essential."),
            hr(),
            p(em("Built with R, tidymodels, and Shiny. Data is synthetic for
                  demonstration purposes."))
        )
      )
    )
  )
)

# ── SERVER ───────────────────────────────────────────────────────────────────

server <- function(input, output, session) {

  # In production, load actual model objects and data:
  # models <- readRDS("output/model_substance_removal_random_forest.rds")
  # For prototype, we simulate prediction results.

  # Load precomputed prediction table and metrics
  pred_data <- reactive({
    # In production: read_csv("output/prediction_table.csv")
    # Simulated for prototype:
    n <- 2000
    tibble(
      case_id = 1:n,
      outcome = rep(input$event_select, n),
      .pred_Event = rbeta(n, 2, 5),
      truth = sample(c("Event", "No_Event"), n, replace = TRUE, prob = c(0.2, 0.8)),
      risk_tier = case_when(
        .pred_Event >= 0.7 ~ "Critical",
        .pred_Event >= 0.4 ~ "High",
        .pred_Event >= 0.2 ~ "Moderate",
        TRUE ~ "Low"
      ),
      county = paste0("County_", str_pad(sample(1:40, n, replace = TRUE), 2, pad = "0")),
      age = sample(0:17, n, replace = TRUE),
      placement = sample(c("Foster", "Kinship", "Group Home", "Institution"), n,
                         replace = TRUE, prob = c(0.4, 0.25, 0.2, 0.15))
    )
  })

  # Value boxes
  output$total_cases <- renderValueBox({
    valueBox(nrow(pred_data()), "Total Cases", icon = icon("users"), color = "blue")
  })

  output$critical_count <- renderValueBox({
    n <- sum(pred_data()$risk_tier == "Critical")
    valueBox(n, "Critical Risk", icon = icon("triangle-exclamation"), color = "red")
  })

  output$high_count <- renderValueBox({
    n <- sum(pred_data()$risk_tier == "High")
    valueBox(n, "High Risk", icon = icon("exclamation"), color = "yellow")
  })

  output$avg_auc <- renderValueBox({
    valueBox("0.783", "Model AUC", icon = icon("chart-line"), color = "green")
  })

  # Risk histogram
  output$risk_histogram <- renderPlotly({
    p <- pred_data() %>%
      ggplot(aes(.pred_Event, fill = truth)) +
      geom_histogram(bins = 40, alpha = 0.7, position = "identity") +
      scale_fill_manual(values = c("Event" = "#DC2626", "No_Event" = "#3B82F6")) +
      geom_vline(xintercept = input$threshold, lty = 2, color = "black") +
      labs(x = "Risk Score", y = "Count", fill = "Actual Outcome") +
      theme_minimal()
    ggplotly(p)
  })

  # Tier bar
  output$tier_bar <- renderPlotly({
    p <- pred_data() %>%
      count(risk_tier) %>%
      mutate(risk_tier = factor(risk_tier, levels = c("Critical", "High", "Moderate", "Low"))) %>%
      ggplot(aes(risk_tier, n, fill = risk_tier)) +
      geom_col() +
      scale_fill_manual(values = c(
        "Critical" = "#DC2626", "High" = "#F59E0B",
        "Moderate" = "#3B82F6", "Low" = "#10B981"
      )) +
      labs(x = "Risk Tier", y = "Cases") +
      theme_minimal() +
      theme(legend.position = "none")
    ggplotly(p)
  })

  # Flagged table
  output$flagged_table <- renderDT({
    pred_data() %>%
      filter(.pred_Event >= input$threshold) %>%
      arrange(desc(.pred_Event)) %>%
      head(50) %>%
      select(case_id, county, age, placement, risk_score = .pred_Event, risk_tier, truth) %>%
      datatable(
        options = list(pageLength = 10, scrollX = TRUE),
        rownames = FALSE
      ) %>%
      formatPercentage("risk_score", 1) %>%
      formatStyle("risk_tier",
        backgroundColor = styleEqual(
          c("Critical", "High", "Moderate", "Low"),
          c("#FEE2E2", "#FEF3C7", "#DBEAFE", "#D1FAE5")
        ),
        fontWeight = "bold"
      )
  })

  # County heatmap
  output$county_heatmap <- renderPlotly({
    county_risk <- pred_data() %>%
      group_by(county) %>%
      summarise(
        mean_risk = mean(.pred_Event),
        n_critical = sum(risk_tier == "Critical"),
        n_cases = n(),
        .groups = "drop"
      ) %>%
      arrange(desc(mean_risk))

    p <- county_risk %>%
      mutate(county = fct_reorder(county, mean_risk)) %>%
      ggplot(aes(county, mean_risk, fill = mean_risk)) +
      geom_col() +
      scale_fill_gradient2(low = "#10B981", mid = "#F59E0B", high = "#DC2626", midpoint = 0.3) +
      coord_flip() +
      labs(x = NULL, y = "Mean Risk Score", fill = "Risk") +
      theme_minimal(base_size = 9)
    ggplotly(p)
  })

  # County scatter
  output$county_scatter <- renderPlotly({
    county_stats <- pred_data() %>%
      group_by(county) %>%
      summarise(mean_risk = mean(.pred_Event), n = n(), .groups = "drop") %>%
      mutate(poverty = runif(n(), 0.08, 0.35))

    p <- county_stats %>%
      ggplot(aes(poverty, mean_risk, size = n, text = county)) +
      geom_point(alpha = 0.7, color = "#2563EB") +
      geom_smooth(method = "lm", se = FALSE, color = "#DC2626") +
      labs(x = "County Poverty Rate", y = "Mean Risk Score", size = "Cases") +
      theme_minimal()
    ggplotly(p, tooltip = c("text", "x", "y"))
  })

  output$county_table <- renderDT({
    pred_data() %>%
      group_by(county) %>%
      summarise(
        Cases = n(),
        `Mean Risk` = round(mean(.pred_Event), 3),
        `Critical` = sum(risk_tier == "Critical"),
        `Event Rate` = round(mean(truth == "Event"), 3),
        .groups = "drop"
      ) %>%
      arrange(desc(`Mean Risk`)) %>%
      head(10) %>%
      datatable(options = list(pageLength = 10), rownames = FALSE)
  })

  # AUC comparison
  output$auc_comparison <- renderPlotly({
    auc_data <- tibble(
      event = rep(c("Substance\nRemoval", "Infant\nEntry", "Runaway", "In-Care\nMaltreat."), each = 3),
      model = rep(c("Logistic", "Random Forest", "Elastic Net"), 4),
      auc = c(0.72, 0.78, 0.73,  0.81, 0.86, 0.82,  0.69, 0.76, 0.71,  0.71, 0.77, 0.72)
    )
    p <- auc_data %>%
      ggplot(aes(event, auc, fill = model)) +
      geom_col(position = "dodge") +
      scale_fill_manual(values = c("#2563EB", "#DC2626", "#059669")) +
      geom_hline(yintercept = 0.5, lty = 2, color = "grey50") +
      labs(x = NULL, y = "AUC", fill = "Model") +
      ylim(0.4, 1) +
      theme_minimal()
    ggplotly(p)
  })

  # Metrics table
  output$metrics_table <- renderDT({
    tibble(
      Event = rep(c("Substance Removal", "Infant Entry", "Runaway", "In-Care Maltreatment"), each = 3),
      Model = rep(c("Logistic Reg", "Random Forest", "Elastic Net"), 4),
      AUC = c(0.72, 0.78, 0.73, 0.81, 0.86, 0.82, 0.69, 0.76, 0.71, 0.71, 0.77, 0.72),
      Accuracy = c(0.71, 0.75, 0.72, 0.79, 0.83, 0.80, 0.68, 0.73, 0.69, 0.70, 0.74, 0.71),
      Sensitivity = c(0.65, 0.72, 0.66, 0.75, 0.81, 0.76, 0.60, 0.68, 0.62, 0.64, 0.70, 0.65),
      Specificity = c(0.74, 0.77, 0.75, 0.82, 0.85, 0.83, 0.72, 0.76, 0.73, 0.73, 0.76, 0.74)
    ) %>%
      datatable(
        options = list(pageLength = 12),
        rownames = FALSE
      ) %>%
      formatRound(columns = c("AUC", "Accuracy", "Sensitivity", "Specificity"), digits = 3)
  })

  # Calibration plot
  output$calibration_plot <- renderPlotly({
    cal <- tibble(
      predicted = seq(0.05, 0.95, by = 0.1),
      observed = c(0.04, 0.11, 0.18, 0.27, 0.38, 0.49, 0.58, 0.72, 0.83, 0.91)
    )
    p <- cal %>%
      ggplot(aes(predicted, observed)) +
      geom_point(size = 3, color = "#2563EB") +
      geom_line(color = "#2563EB") +
      geom_abline(slope = 1, intercept = 0, lty = 2, color = "grey50") +
      labs(x = "Predicted Probability", y = "Observed Frequency") +
      theme_minimal()
    ggplotly(p)
  })

  # What-if scenario
  observeEvent(input$predict_btn, {
    output$scenario_results <- renderUI({
      scores <- c(
        substance = plogis(-2 + 0.6 * input$wf_substance + 0.3 * input$wf_prior_removals +
                           0.2 * input$wf_dv + 0.4 * (input$wf_placement == "Group_Home") +
                           0.25 * input$wf_poverty * 3),
        infant = plogis(-2.5 + 2.5 * (input$wf_age < 1) + 0.5 * input$wf_substance +
                        0.4 * input$wf_prior_removals + 0.35 * input$wf_poverty * 3),
        runaway = plogis(-3 + 0.08 * input$wf_age + 0.5 * (input$wf_placement == "Group_Home") +
                         0.6 * (input$wf_placement == "Institution") + 0.3 * input$wf_stability),
        maltreat = plogis(-3.2 + 0.35 * input$wf_stability +
                          0.4 * (input$wf_placement == "Group_Home") +
                          0.25 * input$wf_caseload / 30)
      )

      tier_fn <- function(s) {
        if (s >= 0.7) "Critical" else if (s >= 0.4) "High"
        else if (s >= 0.2) "Moderate" else "Low"
      }

      flag_class <- function(s) {
        if (s >= 0.7) "critical-flag" else if (s >= 0.4) "high-flag"
        else if (s >= 0.2) "moderate-flag" else "low-flag"
      }

      tagList(
        h4("Risk Assessment Results"),
        fluidRow(
          column(3, div(
            h5("Substance Removal"),
            span(class = flag_class(scores["substance"]),
                 sprintf("%.0f%% — %s", scores["substance"] * 100, tier_fn(scores["substance"])))
          )),
          column(3, div(
            h5("Infant Entry"),
            span(class = flag_class(scores["infant"]),
                 sprintf("%.0f%% — %s", scores["infant"] * 100, tier_fn(scores["infant"])))
          )),
          column(3, div(
            h5("Runaway"),
            span(class = flag_class(scores["runaway"]),
                 sprintf("%.0f%% — %s", scores["runaway"] * 100, tier_fn(scores["runaway"])))
          )),
          column(3, div(
            h5("In-Care Maltreatment"),
            span(class = flag_class(scores["maltreat"]),
                 sprintf("%.0f%% — %s", scores["maltreat"] * 100, tier_fn(scores["maltreat"])))
          ))
        )
      )
    })

    output$scenario_radar <- renderPlotly({
      scores <- c(
        plogis(-2 + 0.6 * input$wf_substance + 0.3 * input$wf_prior_removals +
               0.2 * input$wf_dv + 0.4 * (input$wf_placement == "Group_Home") +
               0.25 * input$wf_poverty * 3),
        plogis(-2.5 + 2.5 * (input$wf_age < 1) + 0.5 * input$wf_substance +
               0.4 * input$wf_prior_removals + 0.35 * input$wf_poverty * 3),
        plogis(-3 + 0.08 * input$wf_age + 0.5 * (input$wf_placement == "Group_Home") +
               0.6 * (input$wf_placement == "Institution") + 0.3 * input$wf_stability),
        plogis(-3.2 + 0.35 * input$wf_stability +
               0.4 * (input$wf_placement == "Group_Home") +
               0.25 * input$wf_caseload / 30)
      )

      plot_ly(
        type = "scatterpolar", mode = "lines+markers",
        r = c(scores, scores[1]),
        theta = c("Substance\nRemoval", "Infant\nEntry", "Runaway",
                   "In-Care\nMaltreat.", "Substance\nRemoval"),
        fill = "toself",
        fillcolor = "rgba(37, 99, 235, 0.2)",
        line = list(color = "#2563EB")
      ) %>%
        layout(
          polar = list(radialaxis = list(range = c(0, 1), tickvals = seq(0, 1, 0.25))),
          title = "Multi-Event Risk Profile",
          showlegend = FALSE
        )
    })
  })
}

shinyApp(ui, server)
