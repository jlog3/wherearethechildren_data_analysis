# Workforce & System-Capacity Correlations with Child-Welfare Risk Rates

## Overview

This R workflow merges state-year workforce indicators (caseload size, turnover, staffing ratios, vacancy rates) with four focal child-welfare outcome rates and produces:

| Output | File |
|---|---|
| Full correlation heat-map | `fig01_correlation_heatmap.png` |
| Focused workforce→outcome sub-matrix | `fig02_focused_correlation_matrix.png` |
| 16-panel scatter-plot grid | `fig03_scatter_grid.png` |
| Coefficient plot (FE estimates) | `fig04_coefficient_plot.png` |
| Marginal-effects predictions | `fig05_marginal_effects.png` |
| Turnover spotlight (accountability) | `fig06_turnover_spotlight.png` |
| Regression table (HTML + LaTeX) | `table01_fe_regressions.*` |
| Correlation matrices (CSV) | `correlation_*.csv` |
| Dashboard narrative captions | `narrative_captions.txt` |

## Data Sources

| Source | Used For |
|---|---|
| **AFCARS** / **NCANDS** | Four focal risk rates (recurrence, re-entry, missing, maltreatment in care) |
| **NDACAN NSCAW III Workforce Study (#288)** | Caseload, staffing, and survey-based turnover measures |
| **NCANDS caseworker ID files** | Turnover calculations (year-over-year ID attrition) |
| **ACF / QIC-WD state reports** | State-level workforce aggregates |

## Quick Start

```r
# 1. Run with simulated data (default)
source("workforce_capacity_correlations.R")

# 2. Run with real data — place CSVs in working directory:
#    outcomes_state_year.csv
#    workforce_state_year.csv
# Then edit line ~68:  USE_SIMULATED <- FALSE
```

### Required CSV schemas

**outcomes_state_year.csv**

| Column | Type | Description |
|---|---|---|
| `state_fips` | char | 2-digit FIPS |
| `state_name` | char | State name |
| `year` | int | Fiscal year |
| `rate_maltreatment_recurrence` | num | Per 1,000 |
| `rate_reentry_foster_care` | num | Per 1,000 |
| `rate_missing_from_care` | num | Per 1,000 |
| `rate_maltreatment_in_care` | num | Per 1,000 |

**workforce_state_year.csv**

| Column | Type | Description |
|---|---|---|
| `state_fips` | char | 2-digit FIPS |
| `year` | int | Fiscal year |
| `avg_caseload` | num | Avg cases per worker |
| `turnover_rate` | num | Annual proportion (0–1) |
| `staffing_ratio` | num | Workers per 1,000 children |
| `vacancy_rate` | num | Proportion unfilled (0–1) |

## Methodology

- **Merge**: Inner join on `state_fips` × `year`
- **Correlations**: Pairwise Pearson on the 8-variable panel
- **Regressions**: Two-way fixed effects (state + year) via `fixest::feols`; SEs clustered at state level
- **Marginal effects**: Conditional predictions via `marginaleffects::plot_predictions`

## Key Finding (for Dashboard Accountability)

> States with higher annual caseworker turnover exhibit systematically elevated rates of children missing from foster care and maltreatment occurring in care. This relationship persists after state and year fixed effects, supporting real-time workforce dashboards that flag jurisdictions where rising turnover may be increasing child-safety risk.
