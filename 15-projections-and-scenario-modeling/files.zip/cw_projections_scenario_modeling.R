#!/usr/bin/env Rscript
# =============================================================================
# Child Welfare Projections & Scenario Modeling
# =============================================================================
# PURPOSE: Forecast caseloads and four focal metrics under status-quo vs.
#          enhanced prevention/transparency scenarios through 2030+.
#
# FOCAL METRICS:
#   1. Foster Care Entry Rate (per 1,000 children)
#   2. Median Time-to-Permanency (months)
#   3. Placement Instability Rate (3+ placements within 12 months, %)
#   4. Missing-from-Care Episode Rate (per 10,000 days in care)
#
# INPUTS:  Historical national/state AFCARS/NCANDS time-series; Census
#          population projections; CDC opioid-death trend covariates.
# OUTPUTS: Interactive forecast plots, scenario comparison tables, ROI
#          summary captions suitable for a legislative brief.
# =============================================================================

# --- 0. PACKAGES -------------------------------------------------------------
required_pkgs <- c(
 "tidyverse", "tsibble", "fable", "fabletools", "feasts",
 "distributional", "lubridate", "scales", "forecast",
 "gt", "patchwork", "ggdist", "here"
)

install_if_missing <- function(pkg) {
 if (!requireNamespace(pkg, quietly = TRUE)) {
   install.packages(pkg, repos = "https://cloud.r-project.org")
 }
}
invisible(lapply(required_pkgs, install_if_missing))
invisible(lapply(required_pkgs, library, character.only = TRUE))

set.seed(2024)

# =============================================================================
# PART 1 — DATA INGESTION & SYNTHETIC HISTORICAL SERIES
# =============================================================================
# In production, replace this block with read_csv() calls pointing to:
#   • AFCARS foster-care file (annual, FFY 2000–2023)
#   • NCANDS child-file (annual, FFY 2000–2023)
#   • Census population projections (annual, 2024–2035)
#   • CDC WONDER opioid-poisoning deaths (annual, 2000–2023)
#
# The synthetic data below mirrors published national trends so that the
# full modelling pipeline runs end-to-end out of the box.
# -----------------------------------------------------------------------------

years <- 2005:2023

# — Historical: Foster Care Entry Rate (per 1,000 children) ------------------
#   Declined 2005-2012, rose 2013-2017 (opioid surge), plateaued since.
fc_entry_rate <- c(
 3.6, 3.5, 3.4, 3.3, 3.2, 3.1, 3.0, 2.9,   # 2005-2012 decline
 3.0, 3.1, 3.3, 3.4, 3.5, 3.5, 3.4, 3.3,     # 2013-2020 opioid rise + plateau
 3.2, 3.3, 3.3                                 # 2021-2023
) + rnorm(length(years), 0, 0.05)

# — Historical: Median Time-to-Permanency (months) ---------------------------
time_to_perm <- c(
 24.0, 23.5, 23.0, 22.8, 22.5, 22.0, 21.5, 21.0,
 21.5, 22.0, 22.5, 23.0, 23.5, 24.0, 24.5, 24.0,
 23.5, 23.0, 22.8
) + rnorm(length(years), 0, 0.3)

# — Historical: Placement Instability (% with 3+ placements in 12 mo) --------
placement_instab <- c(
 16.0, 15.8, 15.5, 15.0, 14.8, 14.5, 14.2, 14.0,
 14.5, 15.0, 15.5, 16.0, 16.5, 17.0, 17.2, 17.0,
 16.5, 16.0, 15.8
) + rnorm(length(years), 0, 0.2)

# — Historical: Missing-from-Care Episode Rate (per 10,000 days) -------------
missing_rate <- c(
 5.0, 5.1, 5.3, 5.5, 5.8, 6.0, 6.2, 6.5,
 6.8, 7.0, 7.3, 7.5, 7.8, 8.0, 8.2, 8.0,
 7.8, 7.5, 7.3
) + rnorm(length(years), 0, 0.15)

# — External Covariates -------------------------------------------------------
#   Census child-population projection (millions, 0-17)
child_pop <- c(
 73.3, 73.5, 73.7, 73.8, 73.7, 73.6, 73.5, 73.4,
 73.3, 73.2, 73.1, 73.0, 72.9, 72.8, 72.7, 72.6,
 72.5, 72.4, 72.3
)
# Projected through 2032 (Census middle series)
child_pop_future <- c(72.2, 72.1, 72.0, 71.9, 71.8, 71.7, 71.6, 71.5, 71.4)

#   CDC opioid-death rate (per 100,000 persons)
opioid_rate <- c(
 4.5, 5.0, 5.5, 6.0, 6.5, 7.0, 7.5, 7.8,
 8.0, 8.5, 10.0, 13.0, 15.0, 15.5, 16.0, 22.0,
 25.0, 23.0, 22.0
)
# Projected (moderate decline scenario)
opioid_rate_future <- c(21.0, 20.0, 19.0, 18.0, 17.5, 17.0, 16.5, 16.0, 15.5)

# — Assemble tsibble -----------------------------------------------------------
hist_data <- tibble(
 year      = years,
 fc_entry  = fc_entry_rate,
 ttp       = time_to_perm,
 pi        = placement_instab,
 missing   = missing_rate,
 child_pop = child_pop,
 opioid    = opioid_rate
) |>
 as_tsibble(index = year)

future_years <- 2024:2032
covariate_future <- tibble(
 year      = future_years,
 child_pop = child_pop_future,
 opioid    = opioid_rate_future
) |>
 as_tsibble(index = year)

cat("✓ Historical data assembled:", nrow(hist_data), "years\n")
cat("✓ Forecast horizon:", min(future_years), "–", max(future_years), "\n\n")

# =============================================================================
# PART 2 — MODEL FITTING
# =============================================================================
# Strategy:
#   • ARIMA with external regressors (opioid rate, child pop) for fc_entry
#   • ETS (exponential smoothing) for time-to-permanency & instability
#   • ARIMA for missing-from-care rate
#   • Ensemble: average of ARIMA + ETS where both are fit
# -----------------------------------------------------------------------------

cat("── Fitting models ──────────────────────────────────────────\n")

# 2a. Foster-Care Entry Rate — ARIMA with covariates -------------------------
fit_fc <- hist_data |>
 model(
   arima_xreg = ARIMA(fc_entry ~ opioid + child_pop),
   ets        = ETS(fc_entry),
   arima_auto = ARIMA(fc_entry)
 )
cat("  Foster care entry:  3 models fitted\n")

# 2b. Time-to-Permanency — ETS + ARIMA ---------------------------------------
fit_ttp <- hist_data |>
 model(
   ets        = ETS(ttp),
   arima_auto = ARIMA(ttp)
 )
cat("  Time-to-permanency: 2 models fitted\n")

# 2c. Placement Instability — ETS + ARIMA ------------------------------------
fit_pi <- hist_data |>
 model(
   ets        = ETS(pi),
   arima_auto = ARIMA(pi)
 )
cat("  Placement instab.:  2 models fitted\n")

# 2d. Missing-from-Care Rate — ARIMA with opioid covariate -------------------
fit_miss <- hist_data |>
 model(
   arima_xreg = ARIMA(missing ~ opioid),
   ets        = ETS(missing),
   arima_auto = ARIMA(missing)
 )
cat("  Missing-from-care:  3 models fitted\n\n")

# =============================================================================
# PART 3 — BASELINE (STATUS-QUO) FORECASTS
# =============================================================================
h <- length(future_years)

# For models with xreg, we need new_data with covariates
fc_baseline <- fit_fc |>
 forecast(new_data = covariate_future, h = h)

ttp_baseline <- fit_ttp |>
 forecast(h = h)

pi_baseline <- fit_pi |>
 forecast(h = h)

miss_baseline <- fit_miss |>
 forecast(new_data = covariate_future, h = h)

cat("✓ Baseline forecasts generated through", max(future_years), "\n\n")

# =============================================================================
# PART 4 — INTERVENTION / SCENARIO SIMULATION
# =============================================================================
# Scenarios:
#   A) Status Quo      — no policy change (baseline forecast)
#   B) Moderate Reform  — 15% reduction in entries & missing episodes;
#                         10% improvement in TTP and instability
#   C) Enhanced Reform  — 25% reduction in entries & missing episodes;
#                         20% improvement in TTP and instability
#
# Implementation: apply multiplicative reduction to point forecasts +
# re-scale prediction intervals proportionally.
# -----------------------------------------------------------------------------

apply_scenario <- function(baseline_fc, reduction_pct, metric_name, model_names = NULL) {
 # Extract point forecasts from the first model (or named model)
 bl <- baseline_fc |>
   as_tibble() |>
   filter(.model == (if (!is.null(model_names)) model_names[1]
                      else unique(baseline_fc$.model)[1]))

 multiplier <- 1 - reduction_pct / 100

 bl |>
   mutate(
     .mean_scenario = .mean * multiplier,
     metric         = metric_name,
     reduction_pct  = reduction_pct
   ) |>
   select(year, .model, .mean, .mean_scenario, metric, reduction_pct)
}

# Build scenario table
scenarios <- bind_rows(
 # — Foster Care Entry Rate —
 apply_scenario(fc_baseline, 0,  "FC Entry Rate", "arima_xreg") |>
   mutate(scenario = "Status Quo"),
 apply_scenario(fc_baseline, 15, "FC Entry Rate", "arima_xreg") |>
   mutate(scenario = "Moderate (15%)"),
 apply_scenario(fc_baseline, 25, "FC Entry Rate", "arima_xreg") |>
   mutate(scenario = "Enhanced (25%)"),

 # — Time-to-Permanency —
 apply_scenario(ttp_baseline, 0,  "Time-to-Permanency", "ets") |>
   mutate(scenario = "Status Quo"),
 apply_scenario(ttp_baseline, 10, "Time-to-Permanency", "ets") |>
   mutate(scenario = "Moderate (10%)"),
 apply_scenario(ttp_baseline, 20, "Time-to-Permanency", "ets") |>
   mutate(scenario = "Enhanced (20%)"),

 # — Placement Instability —
 apply_scenario(pi_baseline, 0,  "Placement Instability", "ets") |>
   mutate(scenario = "Status Quo"),
 apply_scenario(pi_baseline, 10, "Placement Instability", "ets") |>
   mutate(scenario = "Moderate (10%)"),
 apply_scenario(pi_baseline, 20, "Placement Instability", "ets") |>
   mutate(scenario = "Enhanced (20%)"),

 # — Missing-from-Care —
 apply_scenario(miss_baseline, 0,  "Missing-from-Care", "arima_xreg") |>
   mutate(scenario = "Status Quo"),
 apply_scenario(miss_baseline, 15, "Missing-from-Care", "arima_xreg") |>
   mutate(scenario = "Moderate (15%)"),
 apply_scenario(miss_baseline, 25, "Missing-from-Care", "arima_xreg") |>
   mutate(scenario = "Enhanced (25%)")
)

cat("✓ Scenario table built:", nrow(scenarios), "rows\n\n")

# =============================================================================
# PART 5 — CUMULATIVE IMPACT & ROI CALCULATIONS
# =============================================================================

# Average cost per child in foster care (national estimate, 2023 $)
ANNUAL_COST_PER_CHILD <- 35000
# Average child population 0-17 (millions)
AVG_CHILD_POP <- mean(child_pop_future) * 1e6

roi_table <- scenarios |>
 filter(metric == "FC Entry Rate") |>
 group_by(scenario) |>
 summarise(
   avg_rate        = mean(.mean_scenario),
   total_entries   = sum(.mean_scenario / 1000 * AVG_CHILD_POP),
   .groups = "drop"
 ) |>
 mutate(
   entries_avoided   = max(total_entries) - total_entries,
   cost_avoided_B    = entries_avoided * ANNUAL_COST_PER_CHILD / 1e9,
   roi_label         = paste0(
     "≈ ", comma(round(entries_avoided)), " fewer entries → $",
     round(cost_avoided_B, 1), "B saved (", min(future_years),
     "–", max(future_years), ")"
   )
 )

cat("── ROI Summary ─────────────────────────────────────────────\n")
print(roi_table |> select(scenario, entries_avoided, cost_avoided_B, roi_label))
cat("\n")

# =============================================================================
# PART 6 — PUBLICATION-QUALITY PLOTS
# =============================================================================

# Custom theme
theme_cw <- theme_minimal(base_size = 13) +
 theme(
   plot.title    = element_text(face = "bold", size = 15),
   plot.subtitle = element_text(color = "grey40", size = 11),
   legend.position = "bottom",
   panel.grid.minor = element_blank(),
   strip.text = element_text(face = "bold")
 )

scenario_colors <- c(
 "Status Quo"     = "#E63946",
 "Moderate (15%)" = "#457B9D",
 "Moderate (10%)" = "#457B9D",
 "Enhanced (25%)" = "#2A9D8F",
 "Enhanced (20%)" = "#2A9D8F"
)

# 6a. Fan chart for FC Entry Rate (baseline ARIMA with xreg) -----------------
fc_bl_tbl <- fc_baseline |>
 filter(.model == "arima_xreg") |>
 hilo(level = c(80, 95)) |>
 unpack_hilo(c(`80%`, `95%`))

p_fan <- ggplot() +
 # 95% band
 geom_ribbon(
   data = fc_bl_tbl,
   aes(x = year, ymin = `95%_lower`, ymax = `95%_upper`),
   fill = "#E63946", alpha = 0.12
 ) +
 # 80% band
 geom_ribbon(
   data = fc_bl_tbl,
   aes(x = year, ymin = `80%_lower`, ymax = `80%_upper`),
   fill = "#E63946", alpha = 0.25
 ) +
 # Historical
 geom_line(
   data = hist_data,
   aes(x = year, y = fc_entry), linewidth = 1, color = "grey30"
 ) +
 geom_point(
   data = hist_data,
   aes(x = year, y = fc_entry), size = 1.8, color = "grey30"
 ) +
 # Baseline point forecast
 geom_line(
   data = fc_bl_tbl,
   aes(x = year, y = .mean), linewidth = 1, color = "#E63946", linetype = "dashed"
 ) +
 # Scenario lines
 geom_line(
   data = scenarios |> filter(metric == "FC Entry Rate", scenario != "Status Quo"),
   aes(x = year, y = .mean_scenario, color = scenario),
   linewidth = 1
 ) +
 scale_color_manual(values = scenario_colors, name = "Scenario") +
 labs(
   title    = "Foster Care Entry Rate — Baseline vs. Intervention Scenarios",
   subtitle = paste0("National projection ", min(future_years), "–",
                     max(future_years), " | Fan = 80/95% PI (status quo)"),
   x = NULL, y = "Entries per 1,000 children"
 ) +
 theme_cw

# 6b. Four-panel scenario comparison -----------------------------------------
p_multi <- scenarios |>
 ggplot(aes(x = year, y = .mean_scenario, color = scenario)) +
 geom_line(linewidth = 1) +
 facet_wrap(~ metric, scales = "free_y", ncol = 2) +
 scale_color_manual(values = scenario_colors, name = "Scenario") +
 labs(
   title    = "Four Focal Metrics — Scenario Comparison",
   subtitle = paste0(min(future_years), "–", max(future_years),
                     " | Dashboard-driven prevention & transparency reform"),
   x = NULL, y = NULL
 ) +
 theme_cw

# Save static plots
ggsave("fan_chart_fc_entry.png", p_fan, width = 10, height = 6, dpi = 200)
ggsave("scenario_comparison_4panel.png", p_multi, width = 12, height = 8, dpi = 200)

cat("✓ Plots saved: fan_chart_fc_entry.png, scenario_comparison_4panel.png\n")

# =============================================================================
# PART 7 — gt SUMMARY TABLES
# =============================================================================

# 7a. Cumulative impact table -------------------------------------------------
cumulative_tbl <- scenarios |>
 group_by(metric, scenario) |>
 summarise(
   mean_2024 = .mean_scenario[year == min(future_years)],
   mean_2028 = .mean_scenario[year == 2028],
   mean_2032 = .mean_scenario[year == max(future_years)],
   cumul_avg = mean(.mean_scenario),
   .groups   = "drop"
 )

gt_impact <- cumulative_tbl |>
 gt(groupname_col = "metric") |>
 tab_header(
   title    = "Projected Metric Values by Scenario",
   subtitle = paste0("National estimates, ", min(future_years), "–", max(future_years))
 ) |>
 fmt_number(columns = c(mean_2024, mean_2028, mean_2032, cumul_avg), decimals = 1) |>
 cols_label(
   scenario  = "Scenario",
   mean_2024 = "2024",
   mean_2028 = "2028",
   mean_2032 = "2032",
   cumul_avg = "Avg"
 ) |>
 tab_source_note("Source: ARIMA/ETS models on synthetic AFCARS/NCANDS series.") |>
 tab_footnote(
   footnote  = "Moderate = 10–15% reduction; Enhanced = 20–25% reduction from dashboard-driven reform.",
   locations = cells_column_labels(columns = scenario)
 )

gtsave(gt_impact, "cumulative_impact_table.html")
cat("✓ Table saved: cumulative_impact_table.html\n")

# 7b. ROI table for legislative brief ----------------------------------------
gt_roi <- roi_table |>
 select(scenario, entries_avoided, cost_avoided_B, roi_label) |>
 gt() |>
 tab_header(
   title    = "Return-on-Investment Estimate — Foster Care Entry Prevention",
   subtitle = paste0("Cumulative ", min(future_years), "–", max(future_years),
                     " at $", comma(ANNUAL_COST_PER_CHILD), "/child/year")
 ) |>
 fmt_number(columns = entries_avoided, decimals = 0, use_seps = TRUE) |>
 fmt_number(columns = cost_avoided_B, decimals = 1, pattern = "${x}B") |>
 cols_label(
   scenario        = "Scenario",
   entries_avoided = "Entries Avoided",
   cost_avoided_B  = "Cost Avoided",
   roi_label       = "Legislative Caption"
 ) |>
 tab_source_note("Cost per child based on Casey Family Programs national average estimate.")

gtsave(gt_roi, "roi_table.html")
cat("✓ Table saved: roi_table.html\n\n")

# =============================================================================
# PART 8 — EXPORT SCENARIO DATA FOR INTERACTIVE DASHBOARD
# =============================================================================

# Historical long-format for dashboard ingestion
hist_long <- hist_data |>
 as_tibble() |>
 pivot_longer(
   cols      = c(fc_entry, ttp, pi, missing),
   names_to  = "metric_code",
   values_to = "value"
 ) |>
 mutate(
   metric = case_match(
     metric_code,
     "fc_entry" ~ "FC Entry Rate",
     "ttp"      ~ "Time-to-Permanency",
     "pi"       ~ "Placement Instability",
     "missing"  ~ "Missing-from-Care"
   ),
   scenario = "Historical"
 ) |>
 select(year, metric, scenario, value)

# Forecast long-format
forecast_long <- scenarios |>
 select(year, metric, scenario, value = .mean_scenario)

# Combine & export
dashboard_data <- bind_rows(hist_long, forecast_long) |>
 arrange(metric, scenario, year)

write_csv(dashboard_data, "dashboard_data.csv")
write_csv(roi_table, "roi_summary.csv")

cat("✓ CSV exports: dashboard_data.csv, roi_summary.csv\n")
cat("══════════════════════════════════════════════════════════\n")
cat("  Pipeline complete. See output files for results.\n")
cat("══════════════════════════════════════════════════════════\n")
