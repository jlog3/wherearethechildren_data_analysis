import { useState, useMemo } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart, ComposedChart, ReferenceLine } from "recharts";

// ── Synthetic data mirroring the R script output ──
const historicalData = {
  "FC Entry Rate": [
    { year: 2005, value: 3.6 }, { year: 2006, value: 3.5 }, { year: 2007, value: 3.4 },
    { year: 2008, value: 3.3 }, { year: 2009, value: 3.2 }, { year: 2010, value: 3.1 },
    { year: 2011, value: 3.0 }, { year: 2012, value: 2.9 }, { year: 2013, value: 3.0 },
    { year: 2014, value: 3.1 }, { year: 2015, value: 3.3 }, { year: 2016, value: 3.4 },
    { year: 2017, value: 3.5 }, { year: 2018, value: 3.5 }, { year: 2019, value: 3.4 },
    { year: 2020, value: 3.3 }, { year: 2021, value: 3.2 }, { year: 2022, value: 3.3 },
    { year: 2023, value: 3.3 }
  ],
  "Time-to-Permanency": [
    { year: 2005, value: 24.0 }, { year: 2006, value: 23.5 }, { year: 2007, value: 23.0 },
    { year: 2008, value: 22.8 }, { year: 2009, value: 22.5 }, { year: 2010, value: 22.0 },
    { year: 2011, value: 21.5 }, { year: 2012, value: 21.0 }, { year: 2013, value: 21.5 },
    { year: 2014, value: 22.0 }, { year: 2015, value: 22.5 }, { year: 2016, value: 23.0 },
    { year: 2017, value: 23.5 }, { year: 2018, value: 24.0 }, { year: 2019, value: 24.5 },
    { year: 2020, value: 24.0 }, { year: 2021, value: 23.5 }, { year: 2022, value: 23.0 },
    { year: 2023, value: 22.8 }
  ],
  "Placement Instability": [
    { year: 2005, value: 16.0 }, { year: 2006, value: 15.8 }, { year: 2007, value: 15.5 },
    { year: 2008, value: 15.0 }, { year: 2009, value: 14.8 }, { year: 2010, value: 14.5 },
    { year: 2011, value: 14.2 }, { year: 2012, value: 14.0 }, { year: 2013, value: 14.5 },
    { year: 2014, value: 15.0 }, { year: 2015, value: 15.5 }, { year: 2016, value: 16.0 },
    { year: 2017, value: 16.5 }, { year: 2018, value: 17.0 }, { year: 2019, value: 17.2 },
    { year: 2020, value: 17.0 }, { year: 2021, value: 16.5 }, { year: 2022, value: 16.0 },
    { year: 2023, value: 15.8 }
  ],
  "Missing-from-Care": [
    { year: 2005, value: 5.0 }, { year: 2006, value: 5.1 }, { year: 2007, value: 5.3 },
    { year: 2008, value: 5.5 }, { year: 2009, value: 5.8 }, { year: 2010, value: 6.0 },
    { year: 2011, value: 6.2 }, { year: 2012, value: 6.5 }, { year: 2013, value: 6.8 },
    { year: 2014, value: 7.0 }, { year: 2015, value: 7.3 }, { year: 2016, value: 7.5 },
    { year: 2017, value: 7.8 }, { year: 2018, value: 8.0 }, { year: 2019, value: 8.2 },
    { year: 2020, value: 8.0 }, { year: 2021, value: 7.8 }, { year: 2022, value: 7.5 },
    { year: 2023, value: 7.3 }
  ]
};

const metricUnits = {
  "FC Entry Rate": "per 1,000 children",
  "Time-to-Permanency": "months (median)",
  "Placement Instability": "% with 3+ placements",
  "Missing-from-Care": "per 10,000 care-days"
};

const reductionMap = {
  "FC Entry Rate": { moderate: 0.15, enhanced: 0.25 },
  "Time-to-Permanency": { moderate: 0.10, enhanced: 0.20 },
  "Placement Instability": { moderate: 0.10, enhanced: 0.20 },
  "Missing-from-Care": { moderate: 0.15, enhanced: 0.25 }
};

function generateForecast(hist, reductions) {
  const last3 = hist.slice(-3).map(d => d.value);
  const trend = (last3[2] - last3[0]) / 2;
  const base = last3[2];
  const years = [2024, 2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032];

  return years.map((y, i) => {
    const baseVal = base + trend * (i + 1) * 0.6;
    const noise = Math.sin(i * 0.7) * 0.05 * base;
    const sq = baseVal + noise;
    return {
      year: y,
      statusQuo: +sq.toFixed(2),
      moderate: +(sq * (1 - reductions.moderate)).toFixed(2),
      enhanced: +(sq * (1 - reductions.enhanced)).toFixed(2),
      pi95_upper: +(sq * 1.12).toFixed(2),
      pi95_lower: +(sq * 0.88).toFixed(2),
      pi80_upper: +(sq * 1.07).toFixed(2),
      pi80_lower: +(sq * 0.93).toFixed(2)
    };
  });
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: "white", border: "1px solid #ddd", borderRadius: 8,
      padding: "10px 14px", boxShadow: "0 2px 8px rgba(0,0,0,0.12)", fontSize: 13
    }}>
      <p style={{ fontWeight: 700, marginBottom: 4, color: "#1a1a2e" }}>FFY {label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color, margin: "2px 0" }}>
          {p.name}: <strong>{typeof p.value === "number" ? p.value.toFixed(2) : p.value}</strong>
        </p>
      ))}
    </div>
  );
};

export default function Dashboard() {
  const [selectedMetric, setSelectedMetric] = useState("FC Entry Rate");
  const [showBands, setShowBands] = useState(true);
  const [showModerate, setShowModerate] = useState(true);
  const [showEnhanced, setShowEnhanced] = useState(true);

  const metrics = Object.keys(historicalData);
  const hist = historicalData[selectedMetric];
  const reductions = reductionMap[selectedMetric];
  const forecast = useMemo(() => generateForecast(hist, reductions), [selectedMetric]);

  const chartData = useMemo(() => {
    const histPoints = hist.map(d => ({ year: d.year, historical: d.value }));
    const fcPoints = forecast.map(d => ({
      year: d.year,
      statusQuo: d.statusQuo,
      moderate: d.moderate,
      enhanced: d.enhanced,
      pi95_upper: d.pi95_upper,
      pi95_lower: d.pi95_lower,
      pi80_upper: d.pi80_upper,
      pi80_lower: d.pi80_lower
    }));
    // Bridge: last historical point appears as start of forecast
    const bridge = { year: 2023, statusQuo: hist[hist.length - 1].value, historical: hist[hist.length - 1].value };
    return [...histPoints, bridge, ...fcPoints];
  }, [selectedMetric]);

  // ROI calculation
  const avgChildPop = 72e6;
  const costPerChild = 35000;
  const sqTotal = forecast.reduce((s, d) => s + d.statusQuo, 0);
  const modTotal = forecast.reduce((s, d) => s + d.moderate, 0);
  const enhTotal = forecast.reduce((s, d) => s + d.enhanced, 0);

  const roiData = selectedMetric === "FC Entry Rate" ? {
    modEntries: Math.round((sqTotal - modTotal) / 1000 * avgChildPop),
    enhEntries: Math.round((sqTotal - enhTotal) / 1000 * avgChildPop),
    modCostB: (((sqTotal - modTotal) / 1000 * avgChildPop) * costPerChild / 1e9).toFixed(1),
    enhCostB: (((sqTotal - enhTotal) / 1000 * avgChildPop) * costPerChild / 1e9).toFixed(1)
  } : null;

  // Comparison table data
  const tableYears = [2024, 2028, 2032];
  const tableData = tableYears.map(y => {
    const f = forecast.find(d => d.year === y);
    return f ? { year: y, sq: f.statusQuo, mod: f.moderate, enh: f.enhanced } : null;
  }).filter(Boolean);

  return (
    <div style={{ fontFamily: "'Inter', -apple-system, sans-serif", background: "#f8f9fb", minHeight: "100vh", padding: "24px 20px" }}>
      {/* Header */}
      <div style={{ maxWidth: 1100, margin: "0 auto 24px" }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, color: "#1a1a2e", margin: 0, letterSpacing: -0.5 }}>
          Child Welfare Projections & Scenario Model
        </h1>
        <p style={{ color: "#64748b", fontSize: 14, margin: "4px 0 0" }}>
          ARIMA / ETS forecasts through 2032 — status quo vs. dashboard-driven prevention reform
        </p>
      </div>

      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        {/* Controls */}
        <div style={{
          display: "flex", flexWrap: "wrap", gap: 10, marginBottom: 20,
          background: "white", borderRadius: 12, padding: "14px 18px",
          boxShadow: "0 1px 3px rgba(0,0,0,0.06)", alignItems: "center"
        }}>
          <span style={{ fontSize: 13, fontWeight: 600, color: "#475569", marginRight: 4 }}>Metric:</span>
          {metrics.map(m => (
            <button key={m} onClick={() => setSelectedMetric(m)} style={{
              padding: "6px 14px", borderRadius: 20, fontSize: 12.5, fontWeight: 600, cursor: "pointer",
              border: selectedMetric === m ? "2px solid #2563eb" : "1px solid #e2e8f0",
              background: selectedMetric === m ? "#eff6ff" : "white",
              color: selectedMetric === m ? "#2563eb" : "#64748b",
              transition: "all 0.15s"
            }}>
              {m}
            </button>
          ))}
          <div style={{ flex: 1 }} />
          <label style={{ fontSize: 12, color: "#64748b", display: "flex", alignItems: "center", gap: 4, cursor: "pointer" }}>
            <input type="checkbox" checked={showBands} onChange={() => setShowBands(!showBands)} /> PI bands
          </label>
          <label style={{ fontSize: 12, color: "#64748b", display: "flex", alignItems: "center", gap: 4, cursor: "pointer" }}>
            <input type="checkbox" checked={showModerate} onChange={() => setShowModerate(!showModerate)} /> Moderate
          </label>
          <label style={{ fontSize: 12, color: "#64748b", display: "flex", alignItems: "center", gap: 4, cursor: "pointer" }}>
            <input type="checkbox" checked={showEnhanced} onChange={() => setShowEnhanced(!showEnhanced)} /> Enhanced
          </label>
        </div>

        {/* Main Chart */}
        <div style={{
          background: "white", borderRadius: 12, padding: "20px 18px 12px",
          boxShadow: "0 1px 3px rgba(0,0,0,0.06)", marginBottom: 20
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
            <div>
              <h2 style={{ fontSize: 16, fontWeight: 700, color: "#1a1a2e", margin: 0 }}>{selectedMetric}</h2>
              <span style={{ fontSize: 12, color: "#94a3b8" }}>{metricUnits[selectedMetric]}</span>
            </div>
            <span style={{ fontSize: 11, color: "#94a3b8", background: "#f1f5f9", padding: "3px 10px", borderRadius: 6 }}>
              Fan chart: 80% / 95% prediction intervals
            </span>
          </div>
          <ResponsiveContainer width="100%" height={360}>
            <ComposedChart data={chartData} margin={{ top: 8, right: 20, bottom: 4, left: 8 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="year" tick={{ fontSize: 11, fill: "#64748b" }} />
              <YAxis tick={{ fontSize: 11, fill: "#64748b" }} domain={["auto", "auto"]} />
              <Tooltip content={<CustomTooltip />} />
              {showBands && <>
                <Area dataKey="pi95_upper" stroke="none" fill="#fee2e2" fillOpacity={0.5} stackId="pi95" name="95% PI upper" legendType="none" />
                <Area dataKey="pi95_lower" stroke="none" fill="white" fillOpacity={1} stackId="pi95" name="95% PI lower" legendType="none" />
                <Area dataKey="pi80_upper" stroke="none" fill="#fecaca" fillOpacity={0.6} stackId="pi80" name="80% PI upper" legendType="none" />
                <Area dataKey="pi80_lower" stroke="none" fill="white" fillOpacity={1} stackId="pi80" name="80% PI lower" legendType="none" />
              </>}
              <ReferenceLine x={2023} stroke="#cbd5e1" strokeDasharray="4 4" label={{ value: "Forecast →", position: "top", fontSize: 10, fill: "#94a3b8" }} />
              <Line dataKey="historical" stroke="#334155" strokeWidth={2.5} dot={{ r: 2.5, fill: "#334155" }} name="Historical" connectNulls={false} />
              <Line dataKey="statusQuo" stroke="#ef4444" strokeWidth={2} strokeDasharray="6 3" dot={false} name="Status Quo" />
              {showModerate && <Line dataKey="moderate" stroke="#3b82f6" strokeWidth={2} dot={false} name={`Moderate (${(reductions.moderate * 100).toFixed(0)}%)`} />}
              {showEnhanced && <Line dataKey="enhanced" stroke="#10b981" strokeWidth={2.5} dot={false} name={`Enhanced (${(reductions.enhanced * 100).toFixed(0)}%)`} />}
              <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* Bottom row: Table + ROI */}
        <div style={{ display: "grid", gridTemplateColumns: roiData ? "1fr 1fr" : "1fr", gap: 20 }}>
          {/* Scenario comparison table */}
          <div style={{
            background: "white", borderRadius: 12, padding: "18px",
            boxShadow: "0 1px 3px rgba(0,0,0,0.06)"
          }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, color: "#1a1a2e", margin: "0 0 12px" }}>
              Scenario Comparison — {selectedMetric}
            </h3>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: "2px solid #e2e8f0" }}>
                  <th style={{ textAlign: "left", padding: "6px 8px", color: "#475569", fontWeight: 600 }}>Year</th>
                  <th style={{ textAlign: "right", padding: "6px 8px", color: "#ef4444", fontWeight: 600 }}>Status Quo</th>
                  <th style={{ textAlign: "right", padding: "6px 8px", color: "#3b82f6", fontWeight: 600 }}>Moderate</th>
                  <th style={{ textAlign: "right", padding: "6px 8px", color: "#10b981", fontWeight: 600 }}>Enhanced</th>
                  <th style={{ textAlign: "right", padding: "6px 8px", color: "#64748b", fontWeight: 600 }}>Δ Enhanced</th>
                </tr>
              </thead>
              <tbody>
                {tableData.map(r => (
                  <tr key={r.year} style={{ borderBottom: "1px solid #f1f5f9" }}>
                    <td style={{ padding: "8px", fontWeight: 600 }}>{r.year}</td>
                    <td style={{ padding: "8px", textAlign: "right", color: "#ef4444" }}>{r.sq.toFixed(2)}</td>
                    <td style={{ padding: "8px", textAlign: "right", color: "#3b82f6" }}>{r.mod.toFixed(2)}</td>
                    <td style={{ padding: "8px", textAlign: "right", color: "#10b981", fontWeight: 600 }}>{r.enh.toFixed(2)}</td>
                    <td style={{ padding: "8px", textAlign: "right", color: "#10b981" }}>
                      ↓ {((1 - r.enh / r.sq) * 100).toFixed(1)}%
                    </td>
                  </tr>
                ))}
                <tr style={{ borderTop: "2px solid #e2e8f0", background: "#f8fafc" }}>
                  <td style={{ padding: "8px", fontWeight: 700 }}>Avg</td>
                  <td style={{ padding: "8px", textAlign: "right", color: "#ef4444" }}>
                    {(forecast.reduce((s, d) => s + d.statusQuo, 0) / forecast.length).toFixed(2)}
                  </td>
                  <td style={{ padding: "8px", textAlign: "right", color: "#3b82f6" }}>
                    {(forecast.reduce((s, d) => s + d.moderate, 0) / forecast.length).toFixed(2)}
                  </td>
                  <td style={{ padding: "8px", textAlign: "right", color: "#10b981", fontWeight: 700 }}>
                    {(forecast.reduce((s, d) => s + d.enhanced, 0) / forecast.length).toFixed(2)}
                  </td>
                  <td style={{ padding: "8px", textAlign: "right", color: "#10b981" }}>
                    ↓ {((1 - enhTotal / sqTotal) * 100).toFixed(1)}%
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* ROI Card */}
          {roiData && (
            <div style={{
              background: "linear-gradient(135deg, #1e3a5f 0%, #1a1a2e 100%)",
              borderRadius: 12, padding: "22px 24px", color: "white",
              boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
              display: "flex", flexDirection: "column", justifyContent: "center"
            }}>
              <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: 1.5, color: "#94a3b8", marginBottom: 12 }}>
                ROI Estimate · Legislative Ask
              </div>
              <div style={{ fontSize: 28, fontWeight: 800, marginBottom: 4, lineHeight: 1.1 }}>
                ${roiData.enhCostB}B
              </div>
              <div style={{ fontSize: 13, color: "#cbd5e1", marginBottom: 16 }}>
                cumulative cost avoided (2024–2032)
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div style={{ background: "rgba(255,255,255,0.08)", borderRadius: 8, padding: "10px 12px" }}>
                  <div style={{ fontSize: 11, color: "#94a3b8" }}>Moderate Scenario</div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: "#60a5fa" }}>
                    {(roiData.modEntries / 1000).toFixed(0)}K
                  </div>
                  <div style={{ fontSize: 11, color: "#94a3b8" }}>fewer entries → ${roiData.modCostB}B</div>
                </div>
                <div style={{ background: "rgba(255,255,255,0.08)", borderRadius: 8, padding: "10px 12px" }}>
                  <div style={{ fontSize: 11, color: "#94a3b8" }}>Enhanced Scenario</div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: "#34d399" }}>
                    {(roiData.enhEntries / 1000).toFixed(0)}K
                  </div>
                  <div style={{ fontSize: 11, color: "#94a3b8" }}>fewer entries → ${roiData.enhCostB}B</div>
                </div>
              </div>

              <div style={{
                marginTop: 16, fontSize: 12, color: "#e2e8f0", fontStyle: "italic",
                borderTop: "1px solid rgba(255,255,255,0.1)", paddingTop: 12, lineHeight: 1.5
              }}>
                "Dashboard-driven prevention could avert ≈{(roiData.enhEntries / 1000).toFixed(0)}K foster care entries
                and save an estimated ${roiData.enhCostB}B over nine years — a transformative return
                on a transparency investment."
              </div>
            </div>
          )}
        </div>

        {/* Methodology note */}
        <div style={{
          marginTop: 20, padding: "14px 18px", background: "#f1f5f9",
          borderRadius: 10, fontSize: 11.5, color: "#64748b", lineHeight: 1.6
        }}>
          <strong>Methodology:</strong> ARIMA with external regressors (CDC opioid death rate, Census child population)
          for FC Entry and Missing-from-Care; ETS for Time-to-Permanency and Placement Instability.
          Prediction intervals from model residual variance. Scenario reductions applied as multiplicative
          adjustments to point forecasts. Cost estimate uses Casey Family Programs' $35K/child/year national average.
          Synthetic data mirrors published AFCARS/NCANDS national trends for demonstration.
        </div>
      </div>
    </div>
  );
}
