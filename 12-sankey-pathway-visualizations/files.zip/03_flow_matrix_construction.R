###############################################################################
# 03_flow_matrix_construction.R
# Aggregate pathway data into weighted flow matrices for visualization
###############################################################################

# ══════════════════════════════════════════════════════════════════════════════
# Build flow matrices at multiple granularities
# ══════════════════════════════════════════════════════════════════════════════

build_flow_matrices <- function(data, config = CONFIG) {
  
  results <- list()
  
  # ── A. Full 4-stage flow (Entry → Placement → Event → Exit) ─────────────
  cat("  Building 4-stage flow matrices...\n")
  
  # National aggregate
  flow_national <- data %>%
    count(entry_reason, placement, key_event, exit_outcome, name = "n_children") %>%
    mutate(pct = n_children / sum(n_children) * 100) %>%
    arrange(desc(n_children))
  
  results$national_4stage <- flow_national
  
  # ── B. Pairwise link tables (for Sankey) ─────────────────────────────────
  # Sankey diagrams need source → target → value triples.
  # We create 3 link sets: entry→placement, placement→event, event→exit
  
  build_sankey_links <- function(df, label_suffix = "") {
    
    # Link 1: Entry → Placement
    link1 <- df %>%
      count(source = entry_reason, target = placement, name = "value") %>%
      mutate(stage_link = "entry_to_placement")
    
    # Link 2: Placement → Key Event
    link2 <- df %>%
      count(source = placement, target = key_event, name = "value") %>%
      mutate(stage_link = "placement_to_event")
    
    # Link 3: Key Event → Exit
    link3 <- df %>%
      count(source = key_event, target = exit_outcome, name = "value") %>%
      mutate(stage_link = "event_to_exit")
    
    links <- bind_rows(link1, link2, link3) %>%
      mutate(
        pct = value / sum(df %>% nrow()) * 100,
        label_suffix = label_suffix
      )
    
    links
  }
  
  results$links_national <- build_sankey_links(data, "National")
  
  # ── C. By focal issue ───────────────────────────────────────────────────
  cat("  Building focal-issue stratified flows...\n")
  
  for (fi in config$focal_issues) {
    focal_df <- data %>% filter(primary_focal == fi)
    if (nrow(focal_df) > 0) {
      results[[paste0("links_", tolower(fi))]] <- 
        build_sankey_links(focal_df, fi)
      results[[paste0("4stage_", tolower(fi))]] <- focal_df %>%
        count(entry_reason, placement, key_event, exit_outcome, name = "n_children") %>%
        mutate(pct = n_children / sum(n_children) * 100) %>%
        arrange(desc(n_children))
    }
  }
  
  # ── D. By demographics ─────────────────────────────────────────────────
  cat("  Building demographic stratified flows...\n")
  
  # By age group
  for (ag in unique(data$age_group)) {
    sub <- data %>% filter(age_group == ag)
    if (nrow(sub) >= 100) {
      results[[paste0("links_age_", tolower(ag))]] <- 
        build_sankey_links(sub, paste("Age:", ag))
    }
  }
  
  # By race/ethnicity
  for (re in unique(data$race_eth)) {
    sub <- data %>% filter(race_eth == re)
    if (nrow(sub) >= 100) {
      results[[paste0("links_race_", tolower(re))]] <- 
        build_sankey_links(sub, paste("Race:", re))
    }
  }
  
  # ── E. By state (top 10 by volume + user-specified) ────────────────────
  cat("  Building state-level flows (top 10 by volume)...\n")
  
  top_states <- data %>%
    count(STATE) %>%
    slice_max(n, n = 10) %>%
    pull(STATE)
  
  for (st in top_states) {
    sub <- data %>% filter(STATE == st)
    results[[paste0("links_state_", tolower(st))]] <- 
      build_sankey_links(sub, paste("State:", st))
  }
  
  # ── F. Special subgroup: Infants (age 0-1) ─────────────────────────────
  cat("  Building infant-specific pathways...\n")
  
  infant_data <- data %>% filter(age_group == "Infant_0_1")
  if (nrow(infant_data) > 0) {
    results$links_infants <- build_sankey_links(infant_data, "Infants (0-1)")
    results$`4stage_infants` <- infant_data %>%
      count(entry_reason, placement, key_event, exit_outcome, name = "n_children") %>%
      mutate(pct = n_children / sum(n_children) * 100) %>%
      arrange(desc(n_children))
  }
  
  # ── G. Re-entry pathways ───────────────────────────────────────────────
  cat("  Building re-entry pathway flows...\n")
  
  reentry_data <- data %>% filter(is_reentry)
  if (nrow(reentry_data) > 100) {
    results$links_reentry <- build_sankey_links(reentry_data, "Re-Entries")
  }
  
  results
}

# ── Execute and export CSVs ──────────────────────────────────────────────────
flow_matrices <- build_flow_matrices(pathway_data)

# Export all flow matrices as CSV
cat("  Exporting CSV flow matrices...\n")
for (nm in names(flow_matrices)) {
  outfile <- file.path(CONFIG$output_dir, "csv", paste0("flow_", nm, ".csv"))
  write_csv(flow_matrices[[nm]], outfile)
}

# ── Summary cross-tabulation matrix ──────────────────────────────────────────
# Classic entry × exit matrix (petition-ready)
entry_exit_matrix <- pathway_data %>%
  count(entry_reason, exit_outcome, name = "n") %>%
  pivot_wider(names_from = exit_outcome, values_from = n, values_fill = 0) %>%
  arrange(entry_reason)

write_csv(entry_exit_matrix,
          file.path(CONFIG$output_dir, "csv", "entry_exit_crosstab.csv"))

# Entry × Placement matrix
entry_placement_matrix <- pathway_data %>%
  count(entry_reason, placement, name = "n") %>%
  pivot_wider(names_from = placement, values_from = n, values_fill = 0) %>%
  arrange(entry_reason)

write_csv(entry_placement_matrix,
          file.path(CONFIG$output_dir, "csv", "entry_placement_crosstab.csv"))

cat("  ✓", length(flow_matrices), "flow matrices constructed and exported.\n")
