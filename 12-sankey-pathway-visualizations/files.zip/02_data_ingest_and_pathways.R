###############################################################################
# 02_data_ingest_and_pathways.R
# Ingest AFCARS + NCANDS → derive multi-step pathways per child/episode
###############################################################################

# ══════════════════════════════════════════════════════════════════════════════
# SECTION A: SYNTHETIC DATA GENERATOR (for demonstration / testing)
# Replace with real AFCARS/NCANDS reads for production use
# ══════════════════════════════════════════════════════════════════════════════

generate_synthetic_data <- function(n_episodes = 50000, seed = 2024) {
  set.seed(seed)
  cat("  Generating", format(n_episodes, big.mark = ","), "synthetic episodes...\n")
  
  # --- AFCARS episodes ---
  states <- c(state.abb, "DC", "PR")
  
  afcars <- tibble(
    RECNUMBR   = sprintf("EP%07d", 1:n_episodes),
    CHILDID    = sprintf("CH%06d", sample(1:round(n_episodes * 0.85), n_episodes, replace = TRUE)),
    STATE      = sample(states, n_episodes, replace = TRUE,
                        prob = c(rep(1, 50), 0.5, 0.3)),
    FY         = sample(CONFIG$year_range[1]:CONFIG$year_range[2], n_episodes, replace = TRUE),
    
    # Removal reasons (can be multiple; flags)
    DAParent   = rbinom(n_episodes, 1, 0.22),
    DAChild    = rbinom(n_episodes, 1, 0.04),
    DAALCOHL   = rbinom(n_episodes, 1, 0.12),
    NEGLECT    = rbinom(n_episodes, 1, 0.40),
    PHYABUSE   = rbinom(n_episodes, 1, 0.10),
    SEXABUSE   = rbinom(n_episodes, 1, 0.04),
    ABANDMNT   = rbinom(n_episodes, 1, 0.03),
    RELINQSH   = rbinom(n_episodes, 1, 0.02),
    
    # Demographics
    AgeAtEntry = pmin(17, pmax(0, round(rgamma(n_episodes, shape = 2, rate = 0.4)))),
    SEX        = sample(c("Male", "Female"), n_episodes, replace = TRUE),
    
    # Race flags (simplified)
    HIESSION        = rbinom(n_episodes, 1, 0.22),
    APTS_RACE_WHITE = rbinom(n_episodes, 1, 0.42),
    APTS_RACE_BLACK = rbinom(n_episodes, 1, 0.24),
    APTS_RACE_AIAN  = rbinom(n_episodes, 1, 0.02),
    APTS_RACE_ASIAN = rbinom(n_episodes, 1, 0.01),
    APTS_RACE_NHOPI = rbinom(n_episodes, 1, 0.005),
    
    # Current placement setting
    CurPlSet   = sample(1:8, n_episodes, replace = TRUE,
                        prob = c(0.04, 0.30, 0.28, 0.08, 0.06, 0.03, 0.03, 0.18)),
    
    # Number of placement changes
    NPLCMNT    = pmin(15, rpois(n_episodes, lambda = 2.5)),
    
    # Discharge reason (NA = still in care)
    DISREASN   = sample(c(1:7, NA), n_episodes, replace = TRUE,
                        prob = c(0.35, 0.06, 0.20, 0.08, 0.04, 0.02, 0.002, 0.248)),
    
    # Episode dates
    REMOVALDT  = as.Date("2018-01-01") + sample(0:1825, n_episodes, replace = TRUE),
    DISCHDT    = as.Date(NA)
  ) %>%
    mutate(
      # Generate discharge dates for discharged episodes
      DISCHDT = if_else(
        !is.na(DISREASN),
        REMOVALDT + rpois(n_episodes, lambda = 400),
        as.Date(NA)
      ),
      # Some missing/runaway during episode
      had_missing_episode = (CurPlSet == 7) | (DISREASN == 6 & !is.na(DISREASN)) |
        rbinom(n_episodes, 1, 0.06),
      # Re-entry flag (some children have multiple episodes)
      is_reentry = duplicated(CHILDID)
    )
  
  # --- NCANDS maltreatment linkage ---
  n_ncands <- round(n_episodes * 0.35)
  ncands <- tibble(
    CHILDID     = sample(afcars$CHILDID, n_ncands, replace = TRUE),
    RPT_DT      = as.Date("2018-01-01") + sample(0:1825, n_ncands, replace = TRUE),
    MAL_TYPE    = sample(c("Neglect", "Physical", "Sexual", "Emotional", "Other"),
                         n_ncands, replace = TRUE,
                         prob = c(0.55, 0.20, 0.08, 0.12, 0.05)),
    PERP_REL    = sample(c("Parent", "Other_Relative", "Foster_Parent",
                           "Facility_Staff", "Other"),
                         n_ncands, replace = TRUE,
                         prob = c(0.60, 0.15, 0.10, 0.05, 0.10)),
    RPT_DISP    = sample(c("Substantiated", "Indicated", "Unsubstantiated"),
                         n_ncands, replace = TRUE,
                         prob = c(0.35, 0.15, 0.50)),
    STATE       = sample(states, n_ncands, replace = TRUE)
  )
  
  list(afcars = afcars, ncands = ncands)
}

# ══════════════════════════════════════════════════════════════════════════════
# SECTION B: DATA INGESTION
# ══════════════════════════════════════════════════════════════════════════════

load_data <- function() {
  if (file.exists(CONFIG$afcars_path) && file.exists(CONFIG$ncands_path)) {
    cat("  Reading AFCARS from:", CONFIG$afcars_path, "\n")
    afcars <- fread(CONFIG$afcars_path) %>% as_tibble()
    cat("  Reading NCANDS from:", CONFIG$ncands_path, "\n")
    ncands <- fread(CONFIG$ncands_path) %>% as_tibble()
    list(afcars = afcars, ncands = ncands)
  } else {
    cat("  ⚠ Data files not found — generating synthetic data for demonstration.\n")
    generate_synthetic_data()
  }
}

raw_data <- load_data()

# ══════════════════════════════════════════════════════════════════════════════
# SECTION C: PATHWAY DERIVATION
# ══════════════════════════════════════════════════════════════════════════════

derive_pathways <- function(afcars, ncands) {
  
  # ── Step 1: Map entry reasons ────────────────────────────────────────────
  episodes <- afcars %>%
    map_removal_reason() %>%
    derive_race_eth() %>%
    mutate(
      age_group     = derive_age_group(AgeAtEntry),
      placement     = map_placement(CurPlSet),
      exit_outcome  = map_discharge(DISREASN)
    ) %>%
    flag_focal_issue()
  
  # ── Step 2: Link NCANDS maltreatment-in-care ─────────────────────────────
  # Identify substantiated/indicated reports occurring during foster care episode
  ncands_linked <- ncands %>%
    filter(RPT_DISP %in% c("Substantiated", "Indicated")) %>%
    select(CHILDID, RPT_DT, MAL_TYPE, PERP_REL)
  
  # Join: maltreatment during episode window
  mal_in_care <- episodes %>%
    select(RECNUMBR, CHILDID, REMOVALDT, DISCHDT) %>%
    inner_join(ncands_linked, by = "CHILDID", relationship = "many-to-many") %>%
    filter(
      RPT_DT >= REMOVALDT,
      RPT_DT <= coalesce(DISCHDT, Sys.Date())
    ) %>%
    group_by(RECNUMBR) %>%
    summarise(
      n_mal_in_care     = n(),
      mal_types_in_care = paste(unique(MAL_TYPE), collapse = "; "),
      perp_types        = paste(unique(PERP_REL), collapse = "; "),
      .groups = "drop"
    )
  
  episodes <- episodes %>%
    left_join(mal_in_care, by = "RECNUMBR") %>%
    mutate(
      n_mal_in_care     = replace_na(n_mal_in_care, 0),
      focal_missing     = had_missing_episode,
      focal_maltreat    = (n_mal_in_care > 0)
    )
  
  # ── Step 3: Derive key mid-episode events ────────────────────────────────
  episodes <- episodes %>%
    mutate(
      key_event = case_when(
        focal_missing & focal_maltreat      ~ "Missing_Episode",
        focal_missing                        ~ "Missing_Episode",
        focal_maltreat                       ~ "Maltreatment_ICP",
        NPLCMNT >= 4                         ~ "Placement_Change",
        placement == "Trial_Home"            ~ "Reunification_Att",
        NPLCMNT <= 1 & !focal_missing       ~ "Stable_Placement",
        TRUE                                 ~ "No_Key_Event"
      )
    )
  
  # ── Step 4: Build canonical 4-stage pathway strings ──────────────────────
  episodes <- episodes %>%
    mutate(
      pathway = paste(entry_reason, placement, key_event, exit_outcome, sep = " → "),
      # Assign primary focal issue for stratification
      primary_focal = case_when(
        focal_substance ~ "SubstanceAbuse",
        focal_neglect   ~ "Neglect",
        focal_missing   ~ "MissingRunaway",
        focal_maltreat  ~ "Maltreatment",
        TRUE            ~ "Other"
      )
    )
  
  # ── Step 5: Flag re-entries ──────────────────────────────────────────────
  reentry_children <- episodes %>%
    group_by(CHILDID) %>%
    filter(n() > 1) %>%
    arrange(CHILDID, REMOVALDT) %>%
    mutate(episode_seq = row_number()) %>%
    ungroup()
  
  episodes <- episodes %>%
    left_join(
      reentry_children %>% select(RECNUMBR, episode_seq),
      by = "RECNUMBR"
    ) %>%
    mutate(
      is_reentry   = !is.na(episode_seq) & episode_seq > 1,
      episode_seq  = replace_na(episode_seq, 1)
    )
  
  cat("  ✓ Pathways derived for", format(nrow(episodes), big.mark = ","), "episodes.\n")
  cat("    Focal breakdown:\n")
  episodes %>%
    count(primary_focal) %>%
    mutate(pct = scales::percent(n / sum(n), 0.1)) %>%
    {walk2(.$primary_focal, paste0("      ", .$primary_focal, ": ", 
                                     format(.$n, big.mark = ","), " (", .$pct, ")"),
           ~cat(.y, "\n"))}
  
  episodes
}

# Execute
pathway_data <- derive_pathways(raw_data$afcars, raw_data$ncands)

cat("  ✓ Data ingestion and pathway derivation complete.\n")
