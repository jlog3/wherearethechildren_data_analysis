# Prompt 12: Sankey / Alluvial Pathway Visualizations

## Foster Care Entry → Placement → Event → Exit Flow Diagrams

### Overview

This workflow produces **interactive and static pathway visualizations** tracing children through four stages of the foster care system:

```
Entry Reason → Placement Setting → Key Mid-Care Event → Exit/Permanency Outcome
```

It covers the **four focal issues** (Substance Abuse, Neglect, Missing/Runaway, Maltreatment) at national, state, and demographic subgroup levels, with special attention to **"leakage points"** — system failure junctures where transparency dashboards could enable intervention.

---

### File Structure

```
sankey_workflow/
├── 00_main_controller.R          # Run this to execute full pipeline
├── 01_packages_and_helpers.R     # Package management, themes, code mappings
├── 02_data_ingest_and_pathways.R # AFCARS/NCANDS ingest + pathway derivation
├── 03_flow_matrix_construction.R # Weighted flow matrices at all stratifications
├── 04_visualization_engine.R     # networkD3, plotly, ggalluvial generators
├── 05_narrative_captions.R       # Automated petition captions + leakage stats
└── README.md                     # This file
```

### Outputs (written to `output/`)

| Directory | Contents |
|---|---|
| `output/html/` | Interactive Sankey diagrams (networkD3 + plotly) |
| `output/static/` | PNG + PDF alluvial diagrams (ggalluvial) |
| `output/csv/` | Flow matrices, cross-tabulations, leakage stats |
| `output/narratives/` | Exhibit captions for petitions (.txt) |

### Quick Start

```r
# Set working directory to this folder
setwd("path/to/sankey_workflow")

# Edit CONFIG in 00_main_controller.R to point to your AFCARS/NCANDS files:
#   CONFIG$afcars_path  <- "data/afcars_episodes.csv"
#   CONFIG$ncands_path  <- "data/ncands_maltreatment.csv"
# If files are not found, synthetic data is auto-generated for demonstration.

# Run everything:
source("00_main_controller.R")
```

### Data Requirements

**AFCARS fields used:**
- Episode ID (`RECNUMBR`), Child ID (`CHILDID`), State (`STATE`), Fiscal Year (`FY`)
- Removal reasons: `DAParent`, `DAChild`, `DAALCOHL`, `NEGLECT`, `PHYABUSE`, `SEXABUSE`, `ABANDMNT`, `RELINQSH`
- Placement: `CurPlSet` (1-8 AFCARS codes), `NPLCMNT` (number of placement changes)
- Demographics: `AgeAtEntry`, `SEX`, race flags (`APTS_RACE_*`, `HIESSION`)
- Dates: `REMOVALDT`, `DISCHDT`
- Discharge: `DISREASN` (1-7 or NA for still-in-care)

**NCANDS fields used:**
- `CHILDID`, `RPT_DT`, `MAL_TYPE`, `PERP_REL`, `RPT_DISP`, `STATE`

**Linkage:** NCANDS reports are joined to AFCARS episodes by `CHILDID` and date overlap (report date falls within removal–discharge window) for the "maltreatment in care" focal issue.

### Pathway Derivation Logic

Each episode is assigned a **4-stage canonical pathway**:

1. **Entry Reason** — Primary removal reason, prioritized: Substance (Parent/Child) > Neglect > Physical Abuse > Sexual Abuse > Abandonment > Relinquishment > Other
2. **Placement Setting** — Current placement type from AFCARS `CurPlSet` codes
3. **Key Event** — Most significant mid-episode event: Missing/Runaway > Maltreatment in Care > High Placement Instability > Reunification Attempt > Stable Placement
4. **Exit Outcome** — Discharge reason mapped to permanency outcomes

### Visualization Types

| Type | Library | Interactive? | Use Case |
|---|---|---|---|
| networkD3 Sankey | `networkD3` | Yes (drag nodes) | Exploratory analysis, presentations |
| Plotly Sankey | `plotly` | Yes (hover, zoom) | Web embedding, detailed inspection |
| Leakage Sankey | `plotly` | Yes | Petition exhibits (red = failure points) |
| ggalluvial | `ggalluvial` | No (PNG/PDF) | Print publications, reports |
| Demographic panels | `ggalluvial` + `patchwork` | No | Disparity analysis, faceted comparisons |

### Leakage Points Identified

The workflow flags five categories of system failure:

1. **Missing/Runaway Episodes** — Children lost to the system during care
2. **Maltreatment in Care** — Substantiated abuse/neglect while in foster care (NCANDS-linked)
3. **Placement Instability** — 4+ placement changes during a single episode
4. **Re-Entry** — Children returning to care after prior discharge
5. **Aging Out Without Permanency** — Emancipation or still-in-care without family connection

### Customization

- **Add states:** Modify `top_states` logic in `04_visualization_engine.R` or add state abbreviations to the loop
- **Change thresholds:** Adjust `CONFIG$viz$min_flow_pct` (minimum flow width) and `CONFIG$viz$top_n_paths`
- **New subgroups:** Add stratifications in `03_flow_matrix_construction.R` using the `build_sankey_links()` helper
- **Real data:** Replace file paths in `CONFIG` and ensure column names match AFCARS/NCANDS specifications

### Dependencies

`tidyverse`, `data.table`, `lubridate`, `janitor`, `ggalluvial`, `ggplot2`, `scales`, `patchwork`, `ggrepel`, `networkD3`, `plotly`, `htmlwidgets`, `htmltools`, `writexl`, `knitr`, `glue`

All packages are auto-installed on first run.
