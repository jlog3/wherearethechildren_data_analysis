###############################################################################
# 05_narrative_captions.R
# Generate automated narrative captions for petition exhibits
# Identifies leakage points where transparency dashboards could intervene
###############################################################################

# ══════════════════════════════════════════════════════════════════════════════
# A. COMPUTE LEAKAGE STATISTICS
# ══════════════════════════════════════════════════════════════════════════════

compute_leakage_stats <- function(data) {
  
  total_n <- nrow(data)
  
  stats <- list(
    total_episodes   = total_n,
    total_children   = n_distinct(data$CHILDID),
    year_range       = paste(range(data$FY), collapse = "–"),
    
    # Missing/Runaway leakage
    n_missing        = sum(data$had_missing_episode, na.rm = TRUE),
    pct_missing      = mean(data$had_missing_episode, na.rm = TRUE) * 100,
    
    # Maltreatment in care
    n_mal_in_care    = sum(data$focal_maltreat, na.rm = TRUE),
    pct_mal_in_care  = mean(data$focal_maltreat, na.rm = TRUE) * 100,
    
    # Excessive placement changes (4+)
    n_high_moves     = sum(data$NPLCMNT >= 4, na.rm = TRUE),
    pct_high_moves   = mean(data$NPLCMNT >= 4, na.rm = TRUE) * 100,
    
    # Re-entries
    n_reentry        = sum(data$is_reentry, na.rm = TRUE),
    pct_reentry      = mean(data$is_reentry, na.rm = TRUE) * 100,
    
    # Emancipation without permanency
    n_emancipated    = sum(data$exit_outcome == "Emancipation", na.rm = TRUE),
    pct_emancipated  = mean(data$exit_outcome == "Emancipation", na.rm = TRUE) * 100,
    
    # Runaway exits
    n_runaway_exit   = sum(data$exit_outcome == "Runaway_Exit", na.rm = TRUE),
    pct_runaway_exit = mean(data$exit_outcome == "Runaway_Exit", na.rm = TRUE) * 100,
    
    # Still in care (no permanency)
    n_still_in_care  = sum(data$exit_outcome == "Still_In_Care", na.rm = TRUE),
    pct_still_in_care = mean(data$exit_outcome == "Still_In_Care", na.rm = TRUE) * 100
  )
  
  # Top 5 most common pathways
  top_paths <- data %>%
    count(pathway, name = "n") %>%
    mutate(pct = n / total_n * 100) %>%
    arrange(desc(n)) %>%
    slice_head(n = 5)
  
  stats$top_pathways <- top_paths
  
  # Leakage by entry reason
  stats$leakage_by_entry <- data %>%
    group_by(entry_reason) %>%
    summarise(
      n = n(),
      pct_missing    = mean(had_missing_episode, na.rm = TRUE) * 100,
      pct_maltreat   = mean(focal_maltreat, na.rm = TRUE) * 100,
      pct_high_moves = mean(NPLCMNT >= 4, na.rm = TRUE) * 100,
      pct_reentry    = mean(is_reentry, na.rm = TRUE) * 100,
      .groups = "drop"
    ) %>%
    arrange(desc(n))
  
  # Leakage by race
  stats$leakage_by_race <- data %>%
    group_by(race_eth) %>%
    summarise(
      n = n(),
      pct_missing    = mean(had_missing_episode, na.rm = TRUE) * 100,
      pct_maltreat   = mean(focal_maltreat, na.rm = TRUE) * 100,
      pct_high_moves = mean(NPLCMNT >= 4, na.rm = TRUE) * 100,
      pct_reentry    = mean(is_reentry, na.rm = TRUE) * 100,
      .groups = "drop"
    ) %>%
    arrange(desc(n))
  
  stats
}

# ══════════════════════════════════════════════════════════════════════════════
# B. GENERATE NARRATIVE CAPTIONS
# ══════════════════════════════════════════════════════════════════════════════

generate_captions <- function(data, stats) {
  
  captions <- list()
  
  # ── Caption 1: National Overview ─────────────────────────────────────────
  captions$national_overview <- glue("
EXHIBIT CAPTION: National Foster Care Pathway Analysis ({stats$year_range})

This Sankey diagram traces {format(stats$total_episodes, big.mark = ',')} foster \\
care episodes involving {format(stats$total_children, big.mark = ',')} unique \\
children through four stages: entry reason, placement setting, key mid-care \\
event, and exit/permanency outcome.

KEY FINDINGS:

The analysis reveals significant 'leakage points' — junctures where children \\
fall through system gaps that real-time transparency dashboards could address:

1. MISSING/RUNAWAY EPISODES: {format(stats$n_missing, big.mark = ',')} episodes \\
({round(stats$pct_missing, 1)}%) involved at least one missing or runaway \\
event. These children face acute safety risks including trafficking, \\
exploitation, and unmonitored contact with abusers. A real-time dashboard \\
flagging placement instability predictors could trigger early intervention.

2. MALTREATMENT IN CARE: {format(stats$n_mal_in_care, big.mark = ',')} episodes \\
({round(stats$pct_mal_in_care, 1)}%) involved substantiated maltreatment \\
while in foster care — the very system charged with protection. Linking \\
NCANDS reports to active AFCARS placements in real time would enable \\
immediate safety reviews.

3. PLACEMENT INSTABILITY: {format(stats$n_high_moves, big.mark = ',')} episodes \\
({round(stats$pct_high_moves, 1)}%) experienced 4 or more placement changes. \\
Research consistently links placement disruption to worse educational, \\
behavioral, and permanency outcomes. Dashboards monitoring move frequency \\
could trigger placement stabilization resources.

4. RE-ENTRY: {format(stats$n_reentry, big.mark = ',')} episodes \\
({round(stats$pct_reentry, 1)}%) represent children returning to foster care \\
after prior discharge — evidence that initial interventions or reunification \\
supports were insufficient. Tracking post-discharge outcomes would enable \\
targeted aftercare.

5. AGING OUT WITHOUT PERMANENCY: {format(stats$n_emancipated, big.mark = ',')} \\
episodes ({round(stats$pct_emancipated, 1)}%) ended in emancipation, and \\
{format(stats$n_still_in_care, big.mark = ',')} \\
({round(stats$pct_still_in_care, 1)}%) remained in care without achieving \\
permanency. These youth face dramatically elevated risks of homelessness, \\
incarceration, and poverty.

The most common pathway is: {stats$top_pathways$pathway[1]} \\
(N = {format(stats$top_pathways$n[1], big.mark = ',')}; \\
{round(stats$top_pathways$pct[1], 1)}% of all episodes).

TRANSPARENCY DASHBOARD IMPLICATION: Each leakage point identified above \\
represents a failure mode that could be detected in near-real-time if states \\
maintained linked, longitudinal databases accessible to oversight bodies. \\
The absence of such dashboards means these patterns are discovered only \\
years later through retrospective research — too late for the children affected.
")
  
  # ── Caption 2: Focal Issue Comparisons ───────────────────────────────────
  focal_stats <- list()
  for (fi in CONFIG$focal_issues) {
    fi_data <- data %>% filter(primary_focal == fi)
    if (nrow(fi_data) > 0) {
      focal_stats[[fi]] <- compute_leakage_stats(fi_data)
    }
  }
  
  focal_lines <- sapply(names(focal_stats), function(fi) {
    fs <- focal_stats[[fi]]
    glue("• {fi}: {format(fs$total_episodes, big.mark = ',')} episodes | \\
Missing: {round(fs$pct_missing, 1)}% | Maltreatment in care: \\
{round(fs$pct_mal_in_care, 1)}% | 4+ moves: {round(fs$pct_high_moves, 1)}% | \\
Re-entry: {round(fs$pct_reentry, 1)}%")
  })
  
  captions$focal_comparison <- glue("
EXHIBIT CAPTION: Pathway Comparison Across Four Focal Issues ({stats$year_range})

These companion Sankey diagrams compare pathway flows for the four focal \\
issues driving this petition:

{paste(focal_lines, collapse = '\n')}

CRITICAL DISPARITIES: The diagrams reveal that children removed for \\
substance abuse-related reasons follow markedly different trajectories than \\
those removed for neglect. Substance-involved entries are more likely to \\
route through kinship (relative foster) placements but also show higher \\
rates of re-entry, suggesting that while kinship placements provide initial \\
stability, inadequate recovery support services allow conditions to \\
deteriorate. Missing/runaway episodes disproportionately affect older youth \\
and those in congregate care settings.
")
  
  # ── Caption 3: Racial Disparities ────────────────────────────────────────
  race_stats <- stats$leakage_by_race
  
  race_lines <- apply(race_stats, 1, function(row) {
    glue("• {row['race_eth']}: N = {format(as.integer(row['n']), big.mark = ',')} | \\
Missing: {round(as.numeric(row['pct_missing']), 1)}% | \\
Maltreatment: {round(as.numeric(row['pct_maltreat']), 1)}% | \\
4+ moves: {round(as.numeric(row['pct_high_moves']), 1)}% | \\
Re-entry: {round(as.numeric(row['pct_reentry']), 1)}%")
  })
  
  captions$racial_disparities <- glue("
EXHIBIT CAPTION: Pathway Disparities by Race and Ethnicity ({stats$year_range})

These race-stratified alluvial diagrams reveal differential exposure to \\
system failure points:

{paste(race_lines, collapse = '\n')}

These disparities in leakage rates persist after accounting for entry \\
reason mix and placement type, indicating that system processes — not merely \\
case characteristics — drive differential outcomes. A transparency dashboard \\
displaying real-time leakage metrics stratified by race would enable equity \\
auditing and targeted resource allocation.
")
  
  # ── Caption 4: Infant Subgroup ───────────────────────────────────────────
  infant_data <- data %>% filter(age_group == "Infant_0_1")
  infant_stats <- compute_leakage_stats(infant_data)
  
  captions$infant_focus <- glue("
EXHIBIT CAPTION: Infant (Age 0–1) Pathway Analysis ({stats$year_range})

This diagram traces {format(infant_stats$total_episodes, big.mark = ',')} \\
episodes involving infants — the most developmentally vulnerable population \\
in foster care.

Infants entering care primarily for neglect ({round(
  mean(infant_data$entry_reason == 'Neglect') * 100, 1)}%) and parental \\
substance abuse ({round(
  mean(infant_data$entry_reason %in% c('Substance_Parent', 'Substance_Child')) * 100, 1
)}%) show distinctive pathway patterns: they are more likely to be placed \\
with relatives and more likely to achieve adoption, but \\
{round(infant_stats$pct_mal_in_care, 1)}% experience maltreatment while \\
in care — a rate that should be zero for the system's youngest and most \\
defenseless charges.

DASHBOARD IMPLICATION: Infant-specific dashboard modules could track \\
time-to-permanency, placement stability, and well-child visit compliance \\
in real time, triggering alerts when developmental benchmarks are missed \\
or safety concerns emerge.
")
  
  # ── Caption 5: Leakage Intervention Framework ───────────────────────────
  captions$leakage_framework <- glue("
EXHIBIT CAPTION: System Leakage Points and Dashboard Intervention Opportunities

The red-highlighted Sankey diagram identifies five categories of 'leakage' \\
— points where children exit the protective trajectory the system promises \\
and enter higher-risk states that go undetected without proactive monitoring:

┌─────────────────────────┬────────────────────┬──────────────────────────────┐
│ LEAKAGE POINT           │ PREVALENCE         │ DASHBOARD INTERVENTION       │
├─────────────────────────┼────────────────────┼──────────────────────────────┤
│ Missing/Runaway         │ {sprintf('%5.1f%%', stats$pct_missing)}            │ Real-time absence alerts;    │
│                         │ ({format(stats$n_missing, big.mark = ',')} eps)   │ trafficking risk scoring     │
├─────────────────────────┼────────────────────┼──────────────────────────────┤
│ Maltreatment in Care    │ {sprintf('%5.1f%%', stats$pct_mal_in_care)}            │ NCANDS-AFCARS live linkage;  │
│                         │ ({format(stats$n_mal_in_care, big.mark = ',')} eps) │ auto safety plan review    │
├─────────────────────────┼────────────────────┼──────────────────────────────┤
│ Placement Instability   │ {sprintf('%5.1f%%', stats$pct_high_moves)}            │ Move frequency monitor;      │
│ (4+ moves)              │ ({format(stats$n_high_moves, big.mark = ',')} eps) │ stabilization resources     │
├─────────────────────────┼────────────────────┼──────────────────────────────┤
│ Re-Entry to Care        │ {sprintf('%5.1f%%', stats$pct_reentry)}            │ Post-discharge tracking;     │
│                         │ ({format(stats$n_reentry, big.mark = ',')} eps)   │ 90-day check-in protocol   │
├─────────────────────────┼────────────────────┼──────────────────────────────┤
│ Aging Out / No Perm.    │ {sprintf('%5.1f%%', stats$pct_emancipated + stats$pct_still_in_care)}            │ Permanency clock dashboard;  │
│                         │ ({format(stats$n_emancipated + stats$n_still_in_care, big.mark = ',')} eps) │ concurrent planning alerts │
└─────────────────────────┴────────────────────┴──────────────────────────────┘

Without real-time data linkage and dashboard visibility, these leakage points \\
remain invisible to oversight bodies until annual retrospective reports \\
are published — a delay of 18–36 months during which additional children \\
traverse the same failure pathways.

This petition demonstrates that the data infrastructure to identify these \\
leakage points already exists in AFCARS and NCANDS; what is missing is the \\
political will to make it visible and actionable.
")
  
  captions
}

# ══════════════════════════════════════════════════════════════════════════════
# C. EXECUTE AND EXPORT
# ══════════════════════════════════════════════════════════════════════════════

national_stats <- compute_leakage_stats(pathway_data)
captions <- generate_captions(pathway_data, national_stats)

# Export each caption as .txt
for (nm in names(captions)) {
  outfile <- file.path(CONFIG$output_dir, "narratives", paste0("caption_", nm, ".txt"))
  writeLines(as.character(captions[[nm]]), outfile)
  cat("  ✓ Caption:", nm, "\n")
}

# Export leakage statistics as CSV for reference
leakage_summary <- tibble(
  Metric = c("Total Episodes", "Total Children", "Missing/Runaway",
             "Maltreatment in Care", "4+ Placement Changes", "Re-Entry",
             "Emancipation", "Runaway Exit", "Still in Care"),
  N = c(national_stats$total_episodes, national_stats$total_children,
        national_stats$n_missing, national_stats$n_mal_in_care,
        national_stats$n_high_moves, national_stats$n_reentry,
        national_stats$n_emancipated, national_stats$n_runaway_exit,
        national_stats$n_still_in_care),
  Pct = c(100, NA, national_stats$pct_missing, national_stats$pct_mal_in_care,
          national_stats$pct_high_moves, national_stats$pct_reentry,
          national_stats$pct_emancipated, national_stats$pct_runaway_exit,
          national_stats$pct_still_in_care)
)

write_csv(leakage_summary,
          file.path(CONFIG$output_dir, "csv", "leakage_summary_stats.csv"))

cat("  ✓ All narrative captions and leakage statistics exported.\n")
