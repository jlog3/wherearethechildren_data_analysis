###############################################################################
# 04_visualization_engine.R
# Generate interactive Sankey (networkD3, plotly) + static alluvial (ggalluvial)
###############################################################################

# ══════════════════════════════════════════════════════════════════════════════
# A. HELPER: Prepare networkD3 inputs from link tables
# ══════════════════════════════════════════════════════════════════════════════

prepare_d3_sankey <- function(links_df, min_pct = CONFIG$viz$min_flow_pct,
                               top_n = CONFIG$viz$top_n_paths) {
  
  # Filter tiny flows
  links_clean <- links_df %>%
    group_by(stage_link) %>%
    mutate(stage_total = sum(value)) %>%
    ungroup() %>%
    mutate(link_pct = value / stage_total * 100) %>%
    filter(link_pct >= min_pct | value >= 50)
  
  # Build node list (unique names across all stages)
  # Prefix with stage to avoid collisions (e.g., "Neglect" as entry vs event)
  stage_prefix <- c(
    "entry_to_placement" = "1:",
    "placement_to_event" = "2:",
    "event_to_exit"      = "3:"
  )
  
  links_prefixed <- links_clean %>%
    mutate(
      source_label = case_when(
        stage_link == "entry_to_placement" ~ paste0("1: ", source),
        stage_link == "placement_to_event" ~ paste0("2: ", source),
        stage_link == "event_to_exit"      ~ paste0("3: ", source)
      ),
      target_label = case_when(
        stage_link == "entry_to_placement" ~ paste0("2: ", target),
        stage_link == "placement_to_event" ~ paste0("3: ", target),
        stage_link == "event_to_exit"      ~ paste0("4: ", target)
      )
    )
  
  nodes <- data.frame(
    name = unique(c(links_prefixed$source_label, links_prefixed$target_label)),
    stringsAsFactors = FALSE
  ) %>%
    mutate(
      stage = as.integer(substr(name, 1, 1)),
      clean_name = gsub("^[0-9]+: ", "", name)
    )
  
  # Assign colors
  all_colors <- c(stage_colors$entry, stage_colors$placement,
                   stage_colors$event, stage_colors$exit)
  nodes$color <- sapply(nodes$clean_name, function(nm) {
    if (nm %in% names(all_colors)) all_colors[[nm]] else "#94A3B8"
  })
  
  # Build link indices
  links_indexed <- links_prefixed %>%
    mutate(
      source_idx = match(source_label, nodes$name) - 1,  # 0-indexed
      target_idx = match(target_label, nodes$name) - 1
    ) %>%
    filter(!is.na(source_idx), !is.na(target_idx))
  
  list(
    nodes = nodes,
    links = links_indexed
  )
}

# ══════════════════════════════════════════════════════════════════════════════
# B. NETWORKD3 INTERACTIVE SANKEY
# ══════════════════════════════════════════════════════════════════════════════

create_networkd3_sankey <- function(links_df, title = "Pathway Sankey",
                                     subtitle = "", filename = NULL) {
  
  d3_data <- prepare_d3_sankey(links_df)
  
  # Color scale (JS)
  node_colors_js <- paste0(
    'd3.scaleOrdinal()',
    '.domain(["', paste(d3_data$nodes$name, collapse = '","'), '"])',
    '.range(["', paste(d3_data$nodes$color, collapse = '","'), '"])'
  )
  
  widget <- sankeyNetwork(
    Links       = data.frame(
      source = d3_data$links$source_idx,
      target = d3_data$links$target_idx,
      value  = d3_data$links$value
    ),
    Nodes       = data.frame(name = d3_data$nodes$name),
    Source      = "source",
    Target      = "target",
    Value       = "value",
    NodeID      = "name",
    colourScale = JS(node_colors_js),
    fontSize    = CONFIG$viz$sankey_font,
    nodeWidth   = 25,
    nodePadding = 12,
    sinksRight  = TRUE,
    iterations  = 32,
    units       = "children"
  )
  
  # Add title via htmltools
  widget <- htmlwidgets::prependContent(
    widget,
    htmltools::tags$div(
      style = "font-family: Arial, sans-serif; padding: 10px 15px;",
      htmltools::tags$h2(style = "margin-bottom: 4px; color: #1e293b;", title),
      htmltools::tags$p(style = "color: #64748b; font-size: 14px; margin-top: 0;", subtitle),
      htmltools::tags$p(
        style = "color: #94a3b8; font-size: 11px;",
        paste("Stages: Entry Reason → Placement Setting → Key Event → Exit Outcome |",
              "Hover for counts | Drag nodes to rearrange")
      )
    )
  )
  
  if (!is.null(filename)) {
    save_widget_safe(widget, file.path(CONFIG$output_dir, "html", filename))
  }
  
  widget
}

# ══════════════════════════════════════════════════════════════════════════════
# C. PLOTLY INTERACTIVE SANKEY
# ══════════════════════════════════════════════════════════════════════════════

create_plotly_sankey <- function(links_df, title = "Pathway Sankey",
                                  subtitle = "", filename = NULL) {
  
  d3_data <- prepare_d3_sankey(links_df)
  
  fig <- plot_ly(
    type        = "sankey",
    orientation = "h",
    arrangement = "snap",
    
    node = list(
      label     = d3_data$nodes$name,
      color     = d3_data$nodes$color,
      pad       = 15,
      thickness = 25,
      line      = list(color = "white", width = 0.5),
      hovertemplate = "%{label}<br>Total: %{value:,} children<extra></extra>"
    ),
    
    link = list(
      source        = d3_data$links$source_idx,
      target        = d3_data$links$target_idx,
      value         = d3_data$links$value,
      color         = sapply(d3_data$links$source_idx + 1, function(i) {
        col <- d3_data$nodes$color[i]
        paste0(col, "55")   # add transparency
      }),
      hovertemplate = paste(
        "%{source.label} → %{target.label}",
        "<br>Children: %{value:,}",
        "<extra></extra>"
      )
    )
  ) %>%
    layout(
      title = list(
        text = paste0(title, "<br><sup style='color:grey'>", subtitle, "</sup>"),
        font = list(size = 18, family = "Arial")
      ),
      font = list(size = 12, family = "Arial"),
      paper_bgcolor = "#fafafa",
      annotations = list(
        list(
          x = 0, y = -0.1, xref = "paper", yref = "paper",
          text = "Stages: Entry Reason → Placement Setting → Key Event → Exit Outcome",
          showarrow = FALSE, font = list(size = 10, color = "grey")
        )
      )
    )
  
  if (!is.null(filename)) {
    save_widget_safe(
      fig,
      file.path(CONFIG$output_dir, "html", filename)
    )
  }
  
  fig
}

# ══════════════════════════════════════════════════════════════════════════════
# D. GGALLUVIAL STATIC DIAGRAMS
# ══════════════════════════════════════════════════════════════════════════════

create_ggalluvial <- function(data, focal_filter = NULL,
                                title = "Foster Care Pathway Flows",
                                subtitle = "", filename = NULL,
                                top_n = 20) {
  
  # Filter to focal issue if specified
  plot_data <- if (!is.null(focal_filter)) {
    data %>% filter(primary_focal == focal_filter)
  } else {
    data
  }
  
  # Aggregate to top_n pathways
  alluvial_df <- plot_data %>%
    count(entry_reason, placement, key_event, exit_outcome, name = "Freq") %>%
    arrange(desc(Freq)) %>%
    slice_head(n = top_n) %>%
    mutate(across(c(entry_reason, placement, key_event, exit_outcome), as.factor))
  
  # Order factors by frequency for cleaner layout
  for (col in c("entry_reason", "placement", "key_event", "exit_outcome")) {
    lvls <- alluvial_df %>%
      group_by(.data[[col]]) %>%
      summarise(total = sum(Freq), .groups = "drop") %>%
      arrange(desc(total)) %>%
      pull(col) %>%
      as.character()
    alluvial_df[[col]] <- factor(alluvial_df[[col]], levels = lvls)
  }
  
  total_n <- sum(alluvial_df$Freq)
  
  p <- ggplot(alluvial_df,
              aes(axis1 = entry_reason, axis2 = placement,
                  axis3 = key_event, axis4 = exit_outcome,
                  y = Freq)) +
    geom_alluvium(aes(fill = entry_reason), alpha = 0.65, width = 1/6,
                  curve_type = "arctangent", decreasing = FALSE) +
    geom_stratum(width = 1/6, fill = "grey95", color = "grey60", linewidth = 0.3) +
    geom_text(stat = "stratum", aes(label = after_stat(stratum)),
              size = 2.8, fontface = "bold", color = "grey25") +
    scale_x_discrete(
      limits = c("Entry Reason", "Placement", "Key Event", "Exit Outcome"),
      expand = c(0.15, 0.05)
    ) +
    scale_fill_brewer(palette = "Set2", name = "Entry Reason") +
    scale_y_continuous(labels = scales::comma) +
    labs(
      title    = title,
      subtitle = paste0(subtitle, " | N = ", format(total_n, big.mark = ","),
                        " (top ", top_n, " pathways)"),
      caption  = paste(
        "Source: AFCARS/NCANDS synthetic data |",
        "Flows show children moving through foster care stages |",
        "Width proportional to volume"
      ),
      y = "Number of Children"
    ) +
    theme_sankey() +
    theme(legend.position = "right")
  
  if (!is.null(filename)) {
    ggsave(
      filename = file.path(CONFIG$output_dir, "static", paste0(filename, ".png")),
      plot = p, width = CONFIG$viz$fig_width, height = CONFIG$viz$fig_height,
      dpi = 300, bg = "white"
    )
    ggsave(
      filename = file.path(CONFIG$output_dir, "static", paste0(filename, ".pdf")),
      plot = p, width = CONFIG$viz$fig_width, height = CONFIG$viz$fig_height
    )
    cat("  ✓ Saved static:", filename, ".png/.pdf\n")
  }
  
  p
}

# ══════════════════════════════════════════════════════════════════════════════
# E. DEMOGRAPHIC COMPARISON PANEL (side-by-side alluvials)
# ══════════════════════════════════════════════════════════════════════════════

create_demographic_comparison <- function(data, group_var = "race_eth",
                                            focal_filter = NULL,
                                            filename = NULL) {
  
  plot_data <- if (!is.null(focal_filter)) {
    data %>% filter(primary_focal == focal_filter)
  } else {
    data
  }
  
  # Proportional alluvial by demographic group
  prop_df <- plot_data %>%
    count(.data[[group_var]], entry_reason, placement, key_event, exit_outcome,
          name = "Freq") %>%
    group_by(.data[[group_var]]) %>%
    mutate(
      group_total = sum(Freq),
      pct = Freq / group_total * 100
    ) %>%
    ungroup() %>%
    filter(pct >= CONFIG$viz$min_flow_pct)
  
  # Faceted alluvial
  p <- ggplot(prop_df,
              aes(axis1 = entry_reason, axis2 = placement,
                  axis3 = exit_outcome, y = Freq)) +
    geom_alluvium(aes(fill = entry_reason), alpha = 0.6, width = 1/5,
                  curve_type = "arctangent") +
    geom_stratum(width = 1/5, fill = "grey95", color = "grey60", linewidth = 0.3) +
    geom_text(stat = "stratum", aes(label = after_stat(stratum)),
              size = 2.2, color = "grey30") +
    facet_wrap(as.formula(paste("~", group_var)), scales = "free_y", ncol = 3) +
    scale_fill_brewer(palette = "Set2", name = "Entry Reason") +
    scale_x_discrete(
      limits = c("Entry", "Placement", "Exit"),
      expand = c(0.12, 0.05)
    ) +
    labs(
      title    = paste("Pathway Comparison by", str_to_title(gsub("_", " ", group_var))),
      subtitle = if (!is.null(focal_filter)) paste("Focal Issue:", focal_filter) else "All Issues",
      caption  = "Width proportional to volume within each group",
      y = "Children"
    ) +
    theme_sankey() +
    theme(
      strip.text       = element_text(face = "bold", size = 11),
      strip.background = element_rect(fill = "#f1f5f9", color = NA),
      legend.position  = "bottom"
    )
  
  if (!is.null(filename)) {
    ggsave(
      file.path(CONFIG$output_dir, "static", paste0(filename, ".png")),
      p, width = 18, height = 12, dpi = 300, bg = "white"
    )
    cat("  ✓ Saved demographic comparison:", filename, "\n")
  }
  
  p
}

# ══════════════════════════════════════════════════════════════════════════════
# F. LEAKAGE-POINT ANNOTATED SANKEY (plotly with annotations)
# ══════════════════════════════════════════════════════════════════════════════

create_leakage_sankey <- function(links_df, title, filename = NULL) {
  
  d3_data <- prepare_d3_sankey(links_df)
  
  # Identify "leakage" nodes: Missing_Episode, Runaway_Exit, Emancipation, Death
  leakage_nodes <- c("Missing_Episode", "Runaway_Exit", "Emancipation",
                      "Death", "Placement_Change")
  
  # Color leakage links red
  link_colors <- sapply(seq_len(nrow(d3_data$links)), function(i) {
    target_name <- d3_data$nodes$clean_name[d3_data$links$target_idx[i] + 1]
    source_name <- d3_data$nodes$clean_name[d3_data$links$source_idx[i] + 1]
    if (target_name %in% leakage_nodes || source_name %in% leakage_nodes) {
      "rgba(220, 38, 38, 0.45)"   # red for leakage
    } else {
      "rgba(148, 163, 184, 0.25)" # grey for normal
    }
  })
  
  # Highlight leakage nodes
  node_colors <- sapply(d3_data$nodes$clean_name, function(nm) {
    if (nm %in% leakage_nodes) "#DC2626" else d3_data$nodes$color[match(nm, d3_data$nodes$clean_name)]
  })
  
  fig <- plot_ly(
    type = "sankey", orientation = "h",
    node = list(
      label = d3_data$nodes$name,
      color = node_colors,
      pad = 15, thickness = 25,
      line = list(color = "white", width = 0.5),
      hovertemplate = "%{label}<br>Total: %{value:,}<extra></extra>"
    ),
    link = list(
      source = d3_data$links$source_idx,
      target = d3_data$links$target_idx,
      value  = d3_data$links$value,
      color  = link_colors,
      hovertemplate = "%{source.label} → %{target.label}<br>N = %{value:,}<extra></extra>"
    )
  ) %>%
    layout(
      title = list(
        text = paste0(
          title,
          "<br><sup style='color:#DC2626'>■ Red = Leakage Points ",
          "(where transparency dashboards could intervene)</sup>"
        ),
        font = list(size = 16, family = "Arial")
      ),
      font = list(size = 11),
      paper_bgcolor = "#fffbeb",
      annotations = list(
        list(
          x = 0, y = -0.12, xref = "paper", yref = "paper",
          text = paste(
            "LEAKAGE POINTS: Missing episodes, runaway exits, emancipation without",
            "permanency, excessive placement changes, and child deaths.",
            "These represent system failure points where real-time dashboards could trigger",
            "interventions."
          ),
          showarrow = FALSE,
          font = list(size = 10, color = "#92400e"),
          align = "left"
        )
      )
    )
  
  if (!is.null(filename)) {
    save_widget_safe(fig, file.path(CONFIG$output_dir, "html", filename))
  }
  
  fig
}

# ══════════════════════════════════════════════════════════════════════════════
# G. GENERATE ALL VISUALIZATIONS
# ══════════════════════════════════════════════════════════════════════════════

generate_all_visualizations <- function() {
  
  cat("\n── Interactive Sankey Diagrams (networkD3) ──\n")
  
  # National overview
  create_networkd3_sankey(
    flow_matrices$links_national,
    title    = "National Foster Care Pathways",
    subtitle = paste("All episodes", CONFIG$year_range[1], "-", CONFIG$year_range[2]),
    filename = "sankey_networkd3_national.html"
  )
  
  # By focal issue
  for (fi in CONFIG$focal_issues) {
    key <- paste0("links_", tolower(fi))
    if (!is.null(flow_matrices[[key]])) {
      create_networkd3_sankey(
        flow_matrices[[key]],
        title    = paste(fi, "— Pathway Flows"),
        subtitle = paste("Focal issue:", fi),
        filename = paste0("sankey_networkd3_", tolower(fi), ".html")
      )
    }
  }
  
  cat("\n── Interactive Sankey Diagrams (plotly) ──\n")
  
  # National plotly
  create_plotly_sankey(
    flow_matrices$links_national,
    title    = "National Foster Care Pathways",
    subtitle = paste("All episodes", CONFIG$year_range[1], "-", CONFIG$year_range[2]),
    filename = "sankey_plotly_national.html"
  )
  
  # Focal issue plotly versions
  for (fi in CONFIG$focal_issues) {
    key <- paste0("links_", tolower(fi))
    if (!is.null(flow_matrices[[key]])) {
      create_plotly_sankey(
        flow_matrices[[key]],
        title    = paste(fi, "— Pathway Flows"),
        subtitle = paste("Focal issue:", fi),
        filename = paste0("sankey_plotly_", tolower(fi), ".html")
      )
    }
  }
  
  # Infant-specific
  if (!is.null(flow_matrices$links_infants)) {
    create_plotly_sankey(
      flow_matrices$links_infants,
      title    = "Infant (0-1) Foster Care Pathways",
      subtitle = "Children entering care before age 2",
      filename = "sankey_plotly_infants.html"
    )
  }
  
  cat("\n── Leakage-Point Annotated Sankey ──\n")
  
  create_leakage_sankey(
    flow_matrices$links_national,
    title    = "National Pathways — Leakage Points Highlighted",
    filename = "sankey_leakage_national.html"
  )
  
  for (fi in CONFIG$focal_issues) {
    key <- paste0("links_", tolower(fi))
    if (!is.null(flow_matrices[[key]])) {
      create_leakage_sankey(
        flow_matrices[[key]],
        title    = paste(fi, "— Leakage Points"),
        filename = paste0("sankey_leakage_", tolower(fi), ".html")
      )
    }
  }
  
  cat("\n── Static Alluvial Diagrams (ggalluvial) ──\n")
  
  # National
  create_ggalluvial(
    pathway_data,
    title    = "National Foster Care Pathway Flows",
    subtitle = paste(CONFIG$year_range[1], "-", CONFIG$year_range[2]),
    filename = "alluvial_national"
  )
  
  # By focal issue
  for (fi in CONFIG$focal_issues) {
    create_ggalluvial(
      pathway_data,
      focal_filter = fi,
      title    = paste(fi, "— Pathway Flows"),
      subtitle = paste("Focal Issue |", CONFIG$year_range[1], "-", CONFIG$year_range[2]),
      filename = paste0("alluvial_", tolower(fi))
    )
  }
  
  # Infant-specific
  create_ggalluvial(
    pathway_data %>% filter(age_group == "Infant_0_1"),
    title    = "Infant (0-1) Pathway Flows",
    subtitle = "Youngest children in care",
    filename = "alluvial_infants"
  )
  
  cat("\n── Demographic Comparison Panels ──\n")
  
  # By race
  create_demographic_comparison(
    pathway_data,
    group_var = "race_eth",
    filename  = "alluvial_compare_race"
  )
  
  # By age group
  create_demographic_comparison(
    pathway_data,
    group_var = "age_group",
    filename  = "alluvial_compare_age"
  )
  
  # Race comparison within substance abuse
  create_demographic_comparison(
    pathway_data,
    group_var    = "race_eth",
    focal_filter = "SubstanceAbuse",
    filename     = "alluvial_compare_race_substance"
  )
  
  # State-level for top states
  top_states <- pathway_data %>%
    count(STATE) %>%
    slice_max(n, n = 5) %>%
    pull(STATE)
  
  for (st in top_states) {
    st_links <- flow_matrices[[paste0("links_state_", tolower(st))]]
    if (!is.null(st_links)) {
      create_plotly_sankey(
        st_links,
        title    = paste("State:", st, "— Foster Care Pathways"),
        subtitle = paste(CONFIG$year_range[1], "-", CONFIG$year_range[2]),
        filename = paste0("sankey_plotly_state_", tolower(st), ".html")
      )
    }
  }
  
  cat("\n  ✓ All visualizations generated.\n")
}

# Execute
generate_all_visualizations()
