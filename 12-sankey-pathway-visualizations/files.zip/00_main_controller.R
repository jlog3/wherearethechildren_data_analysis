###############################################################################
# PROMPT 12 — Sankey / Alluvial Pathway Visualizations
# Full R Workflow: Entry Reasons → Key Events → Exits
# Four Focal Issues: Substance Abuse, Neglect, Missing/Runaway, Maltreatment
#
# Outputs:
#   • Interactive HTML Sankey diagrams (plotly + networkD3)
#   • Static ggplot alluvial diagrams (ggalluvial)
#   • CSV flow matrices
#   • Narrative captions for petitions
#
# Usage:
#   source("00_main_controller.R")
#   # — or run each script sequentially —
###############################################################################

cat("
╔══════════════════════════════════════════════════════════════════╗
║  SANKEY / ALLUVIAL PATHWAY VISUALIZATION WORKFLOW               ║
║  Entry Reasons → Placement Events → Exits                       ║
║  Four Focal Issues · National + State + Subgroup                ║
╚══════════════════════════════════════════════════════════════════╝
\n")

# ── Global configuration ─────────────────────────────────────────────────────
CONFIG <- list(
  # Paths — adjust to your environment
  afcars_path      = "data/afcars_episodes.csv",
  ncands_path      = "data/ncands_maltreatment.csv",
  output_dir       = "output",
  

  # Focal issues
  focal_issues = c("SubstanceAbuse", "Neglect", "MissingRunaway", "Maltreatment"),
  
  # Demographic subgroups for stratification
  demo_groups = list(
    age   = c("Infant_0_1", "Toddler_2_5", "Child_6_12", "Teen_13_17"),
    race  = c("White", "Black", "Hispanic", "AIAN", "Asian_PI", "Multiracial"),
    state = "ALL"
  ),
  
  # Visualization parameters
  viz = list(
    min_flow_pct    = 0.5,     # drop flows < 0.5% for readability
    top_n_paths     = 25,       # max pathways per Sankey
    color_palette   = "Set2",
    sankey_font     = 12,
    fig_width       = 14,
    fig_height      = 10
  ),
  
  # Analysis year range
  year_range = c(2018, 2022)
)

# Create output directories
dirs <- c("output/html", "output/static", "output/csv", "output/narratives")
invisible(lapply(dirs, dir.create, recursive = TRUE, showWarnings = FALSE))

# ── Source component scripts ─────────────────────────────────────────────────
cat("Step 1/5: Loading packages and helpers...\n")
source("01_packages_and_helpers.R")

cat("Step 2/5: Ingesting and deriving pathways...\n")
source("02_data_ingest_and_pathways.R")

cat("Step 3/5: Building flow matrices...\n")
source("03_flow_matrix_construction.R")

cat("Step 4/5: Generating visualizations...\n")
source("04_visualization_engine.R")

cat("Step 5/5: Generating narrative captions...\n")
source("05_narrative_captions.R")

cat("\n✓ All outputs written to:", normalizePath(CONFIG$output_dir), "\n")
cat("  html/       — interactive Sankey diagrams\n")
cat("  static/     — ggplot alluvial PNGs/PDFs\n")
cat("  csv/        — flow matrices\n")
cat("  narratives/ — petition captions (.txt + .docx)\n")
