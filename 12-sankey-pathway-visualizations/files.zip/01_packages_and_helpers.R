###############################################################################
# 01_packages_and_helpers.R
# Package management and utility functions
###############################################################################

# ── Package installer / loader ────────────────────────────────────────────────
required_pkgs <- c(
  # Data wrangling
  "tidyverse", "data.table", "lubridate", "janitor",
  # Alluvial (static)
  "ggalluvial", "ggplot2", "scales", "patchwork", "ggrepel",
  # Sankey (interactive)
  "networkD3", "plotly", "htmlwidgets", "htmltools",
  # Tables and export
  "writexl", "knitr", "glue"
)

install_if_missing <- function(pkgs) {
  missing <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
  if (length(missing) > 0) {
    cat("Installing:", paste(missing, collapse = ", "), "\n")
    install.packages(missing, repos = "https://cloud.r-project.org", quiet = TRUE)
  }
  invisible(lapply(pkgs, library, character.only = TRUE, warn.conflicts = FALSE))
}

install_if_missing(required_pkgs)

# ── Theme for static plots ───────────────────────────────────────────────────
theme_sankey <- function(base_size = 12) {
  theme_minimal(base_size = base_size) +
    theme(
      plot.title       = element_text(face = "bold", size = base_size + 4, hjust = 0),
      plot.subtitle    = element_text(color = "grey40", size = base_size + 1, hjust = 0,
                                      margin = margin(b = 12)),
      plot.caption     = element_text(color = "grey50", size = base_size - 2, hjust = 0),
      panel.grid       = element_blank(),
      axis.text.y      = element_blank(),
      axis.ticks       = element_blank(),
      legend.position  = "bottom",
      legend.title     = element_text(face = "bold"),
      plot.margin      = margin(15, 15, 15, 15)
    )
}

# ── Color palettes by focal issue ────────────────────────────────────────────
focal_colors <- c(
  "SubstanceAbuse"  = "#E63946",
  "Neglect"         = "#457B9D",
  "MissingRunaway"  = "#F4A261",
  "Maltreatment"    = "#2A9D8F"
)

# Stage-level colors for Sankey nodes
stage_colors <- list(
  entry = c(
    "Substance_Parent"  = "#E63946",
    "Substance_Child"   = "#C1121F",
    "Neglect"           = "#457B9D",
    "Physical_Abuse"    = "#6A0572",
    "Sexual_Abuse"      = "#9B2226",
    "Abandonment"       = "#BB3E03",
    "Relinquishment"    = "#CA6702",
    "Other_Entry"       = "#94A3B8"
  ),
  placement = c(
    "Pre_Adoptive"      = "#48BFE3",
    "Foster_NonRelative" = "#5E60CE",
    "Foster_Relative"   = "#7B68EE",
    "Group_Home"        = "#E77C8E",
    "Institution"       = "#F28482",
    "Supervised_IL"     = "#84A59D",
    "Trial_Home"        = "#F6BD60",
    "Missing_Runaway"   = "#F4A261",
    "Other_Placement"   = "#94A3B8"
  ),
  event = c(
    "Missing_Episode"   = "#F4A261",
    "Placement_Change"  = "#E9C46A",
    "Maltreatment_ICP"  = "#2A9D8F",
    "Reunification_Att" = "#A8DADC",
    "Stable_Placement"  = "#81B29A",
    "No_Key_Event"      = "#CBD5E1"
  ),
  exit = c(
    "Reunification"     = "#2A9D8F",
    "Adoption"          = "#264653",
    "Guardianship"      = "#6A994E",
    "Emancipation"      = "#BC6C25",
    "Runaway_Exit"      = "#F4A261",
    "Transfer"          = "#ADB5BD",
    "Death"             = "#1D3557",
    "Still_In_Care"     = "#E9ECEF",
    "Other_Exit"        = "#94A3B8"
  )
)

# ── Helper: map AFCARS codes to readable labels ─────────────────────────────
map_removal_reason <- function(df) {
  df %>%
    mutate(
      entry_reason = case_when(
        DAParent == 1 | DAALCOHL == 1          ~ "Substance_Parent",
        DAChild  == 1                           ~ "Substance_Child",
        NEGLECT  == 1                           ~ "Neglect",
        PHYABUSE == 1                           ~ "Physical_Abuse",
        SEXABUSE == 1                           ~ "Sexual_Abuse",
        ABANDMNT == 1                           ~ "Abandonment",
        RELINQSH == 1                           ~ "Relinquishment",
        TRUE                                    ~ "Other_Entry"
      )
    )
}

map_placement <- function(curplset) {
  case_when(
    curplset == 1  ~ "Pre_Adoptive",
    curplset == 2  ~ "Foster_NonRelative",
    curplset == 3  ~ "Foster_Relative",
    curplset == 4  ~ "Group_Home",
    curplset == 5  ~ "Institution",
    curplset == 6  ~ "Supervised_IL",
    curplset == 7  ~ "Missing_Runaway",
    curplset == 8  ~ "Trial_Home",
    TRUE           ~ "Other_Placement"
  )
}

map_discharge <- function(disreasn) {
  case_when(
    disreasn == 1  ~ "Reunification",
    disreasn == 2  ~ "Guardianship",
    disreasn == 3  ~ "Adoption",       # simplified
    disreasn == 4  ~ "Emancipation",
    disreasn == 5  ~ "Transfer",
    disreasn == 6  ~ "Runaway_Exit",
    disreasn == 7  ~ "Death",
    is.na(disreasn) ~ "Still_In_Care",
    TRUE            ~ "Other_Exit"
  )
}

# ── Helper: derive age group ─────────────────────────────────────────────────
derive_age_group <- function(age_years) {
  case_when(
    age_years <= 1  ~ "Infant_0_1",
    age_years <= 5  ~ "Toddler_2_5",
    age_years <= 12 ~ "Child_6_12",
    age_years <= 17 ~ "Teen_13_17",
    TRUE            ~ "18_Plus"
  )
}

# ── Helper: derive race/ethnicity ────────────────────────────────────────────
derive_race_eth <- function(df) {
  df %>%
    mutate(
      race_eth = case_when(
        HIESSION == 1                       ~ "Hispanic",
        APTS_RACE_AIAN   == 1              ~ "AIAN",
        APTS_RACE_ASIAN  == 1 |
          APTS_RACE_NHOPI == 1             ~ "Asian_PI",
        APTS_RACE_BLACK  == 1 &
          APTS_RACE_WHITE == 0             ~ "Black",
        APTS_RACE_WHITE  == 1 &
          APTS_RACE_BLACK == 0             ~ "White",
        TRUE                                ~ "Multiracial"
      )
    )
}

# ── Helper: identify focal-issue flag ────────────────────────────────────────
flag_focal_issue <- function(df) {
  df %>%
    mutate(
      focal_substance = (entry_reason %in% c("Substance_Parent", "Substance_Child")),
      focal_neglect   = (entry_reason == "Neglect"),
      focal_missing   = FALSE,   # updated later based on events
      focal_maltreat  = FALSE    # updated later via NCANDS linkage
    )
}

# ── Helper: safely export interactive widget ─────────────────────────────────
save_widget_safe <- function(widget, filepath) {
  tryCatch({
    htmlwidgets::saveWidget(
      widget,
      file = normalizePath(filepath, mustWork = FALSE),
      selfcontained = TRUE
    )
    cat("  ✓ Saved:", filepath, "\n")
  }, error = function(e) {
    # Fallback: non-self-contained
    htmlwidgets::saveWidget(widget, file = filepath, selfcontained = FALSE)
    cat("  ✓ Saved (non-selfcontained):", filepath, "\n")
  })
}

cat("  ✓ Packages loaded, helpers defined.\n")
