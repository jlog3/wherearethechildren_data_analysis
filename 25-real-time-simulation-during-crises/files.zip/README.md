# Child Welfare Real-Time Crisis Simulation

## Purpose

Demonstrates what **live public dashboard feeds** would have revealed during child welfare crises — enabling the argument that real-time AFCARS/NCANDS monitoring could have flagged the **opioid surge (2016–2019)**, tracked **FFPSA rollout divergence**, detected **COVID-era runaway spikes**, and prepared for **future stimulant waves** — all months earlier than retrospective analysis.

## Four Tracked Metrics

| Metric | Source | Crisis Signal |
|---|---|---|
| Substance-related removals | AFCARS | Opioid / stimulant surges |
| Infant foster care entries | AFCARS | Substance-exposed newborns, FFPSA impact |
| Runaway / missing episodes | AFCARS | System stress, COVID disruption |
| In-care maltreatment | NCANDS | Oversight capacity under strain |

## Architecture

```
realtime_sim/
├── run_all.R                  # Master entry point
├── app.R                      # Shiny interactive dashboard
├── R/
│   ├── 00_config.R            # Shared config, thresholds, palettes
│   ├── 01_data_generator.R    # Synthetic data with embedded crisis signals
│   ├── 02_streaming_engine.R  # Rolling-window alerts, hotspot detection
│   └── 03_animated_outputs.R  # GIFs, time-lapse maps, static PNGs, CSVs
├── outputs/                   # Generated files land here
└── README.md
```

## Quick Start

```r
# Install dependencies
install.packages(c("tidyverse","data.table","lubridate","sf","tigris",
                   "gganimate","plotly","viridis","scales","zoo",
                   "htmlwidgets","gifski","patchwork","ggrepel",
                   "shiny","shinydashboard","shinyWidgets","DT"))

# Generate all static outputs (GIFs, PNGs, HTMLs, CSVs)
setwd("realtime_sim")
Rscript run_all.R

# Launch interactive Shiny dashboard
Rscript run_all.R --shiny

# Both
Rscript run_all.R --all
```

## Output Manifest

### Animated GIFs
- `national_trend_animation.gif` — 4-metric national trends revealed month-by-month with crisis period shading
- `timelapse_map_substance_removals.gif` — Choropleth time-lapse of substance removal rates
- `timelapse_map_runaway_episodes.gif` — Choropleth time-lapse of runaway rates
- `opioid_overlay_animated.gif` — Substance removals vs CDC opioid deaths, showing lead/lag
- `alert_timeline_animated.gif` — Focus-state alert heatmap strip unfolding over time
- `alert_counter_animated.gif` — Area chart of states-in-alert count over time

### Static PNGs
- `opioid_overlay.png` — Dual-axis CDC overlay
- `alert_timeline_heatmap.png` — Full alert history for 10 focus states
- `alert_counter_national.png` — National alert cascade area chart

### Interactive HTML (Plotly)
- `hotspot_emergence_map.html` — Quarterly animated choropleth with slider

### CSVs
- `full_alert_dataset.csv` — Complete state × month × 4 metrics with alert flags
- `national_monthly_summary.csv` — Aggregated national time series
- `crisis_hotspot_snapshots.csv` — Hotspot rankings at each crisis endpoint
- `policy_narrative_hooks.csv` — Pre-written policy justifications per crisis

## Shiny Dashboard Tabs

| Tab | Description |
|---|---|
| **Live Feed** | KPI boxes, national trend with crisis shading, alert count, focus-state heatmap — all reactive to the time slider with ▶ Play animation |
| **State Deep Dive** | Per-state multi-metric trends, alert strip, state vs national comparison |
| **Crisis Scenarios** | Select a crisis, jump to its onset, see counterfactual early-detection window |
| **Hotspot Map** | Interactive choropleth of current alert snapshot + top-10 hotspot table |
| **Alert Log** | Filterable, sortable table of all fired alerts up to sim date |
| **Policy Summary** | Auto-generated policy hooks with download buttons |

## Alert Threshold Logic

```
Z-score (6-month trailing window):
  ≥ 2.5  →  RED (Critical)
  ≥ 2.0  →  ORANGE (Warning)
  ≥ 1.5  →  YELLOW (Caution)

Month-over-month % change:
  ≥ 30%  →  ORANGE
  ≥ 20%  →  YELLOW

Minimum count filter: ≥ 5 (avoids small-state noise)
```

## Connecting Real Data

Replace the simulated data in `01_data_generator.R` with actual extracts:

```r
# AFCARS monthly aggregation
afcars <- fread("afcars_monthly_state.csv")
# Expected columns: state_fips, month, substance_removals,
#                   infant_entries, runaway_episodes

# NCANDS
ncands <- fread("ncands_monthly_state.csv")
# Expected: state_fips, month, incare_maltreatment

# CDC WONDER opioid deaths
cdc <- fread("cdc_monthly_opioid_deaths.csv")
# Expected: month, opioid_deaths

# Census child population
pop <- fread("census_child_pop.csv")
# Expected: state_fips, year, child_pop
```

## Key Policy Caption

> *"Had a real-time child welfare dashboard been operational during 2015–2019,
> the opioid-driven surge in substance-related removals and infant entries
> would have triggered state-level alerts months before the crisis was
> retrospectively identified — enabling faster prevention, targeted federal
> technical assistance, and oversight that could have protected thousands
> of additional children."*
