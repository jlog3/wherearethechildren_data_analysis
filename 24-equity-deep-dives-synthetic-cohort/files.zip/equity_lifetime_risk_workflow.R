################################################################################
#
#  EQUITY & DISPARITY DEEP-DIVES: CUMULATIVE LIFETIME RISKS
#  ─────────────────────────────────────────────────────────
#  Synthetic Cohort (Life Table) Methods for Child Welfare Events
#
#  Focal events:
#    1. Substance-related removal
#    2. Infant entry (age 0-1 entry into foster care)
#    3. Experiencing a missing episode while in care
#    4. In-care maltreatment (substantiated maltreatment while in care)
#
#  Methods:  Wildeman (2009, 2014); Edwards et al. (2021);
#            Putnam-Hornstein et al. (2013, 2021); Yi et al. (2020)
#            Illinois DCFS annual data reports; AFCARS/NCANDS national files
#
#  Author:   [Your Name / Organization]
#  Date:     2025
#
################################################################################


# ============================================================================
# 0.  ENVIRONMENT & PACKAGES
# ============================================================================

required_packages <- c(

  "tidyverse",    # data wrangling + ggplot2

  "data.table",   # fast I/O & manipulation
  "boot",         # bootstrap confidence intervals
  "broom",        # tidy model outputs
  "scales",       # axis formatting
  "patchwork",    # multi-panel plots
  "knitr",        # tables
  "kableExtra",   # enhanced tables
  "glue",         # string interpolation
  "RColorBrewer", # color palettes
  "ggrepel"       # label placement
)

install_if_missing <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg, repos = "https://cloud.r-project.org")
  }
}
invisible(lapply(required_packages, install_if_missing))
invisible(lapply(required_packages, library, character.only = TRUE))

# Reproducibility
set.seed(20250217)

# Plot theme
theme_equity <- theme_minimal(base_size = 13) +

  theme(
    plot.title       = element_text(face = "bold", size = 15),
    plot.subtitle    = element_text(color = "grey35", size = 11),
    plot.caption     = element_text(color = "grey50", size = 8, hjust = 0),
    legend.position  = "bottom",
    legend.title     = element_blank(),
    panel.grid.minor = element_blank(),
    strip.text       = element_text(face = "bold")
  )
theme_set(theme_equity)

# Equity-conscious color palette (colorblind-friendly)
race_colors <- c(
  "AI/AN"     = "#E69F00",
  "Black"     = "#0072B2",
  "Hispanic"  = "#009E73",
  "White"     = "#CC79A7",
  "NHPI"      = "#D55E00",
  "Asian"     = "#56B4E9",
  "Multirace" = "#999999",
  "Overall"   = "#000000"
)


# ============================================================================
# 1.  SYNTHETIC DATA GENERATION
# ============================================================================
#
#  In production, replace this section with actual AFCARS / NCANDS extracts
#  linked to Census / CDC bridged-race population denominators.
#
#  The synthetic rates below are *calibrated* to approximate published
#  national/state estimates (Wildeman 2014; Edwards et al. 2021;
#  Putnam-Hornstein et al. 2021) and are for DEMONSTRATION ONLY.
#
# ============================================================================

ages <- 0:17
n_ages <- length(ages)

race_groups <- c("AI/AN", "Black", "Hispanic", "White", "Asian", "NHPI",
                 "Multirace", "Overall")

# --- Helper: generate plausible age-specific incidence rates ----------------
# Rates per 1,000 children in the population at each single year of age.
# Shape: high in infancy/early childhood, trough in middle childhood,
#        modest rise in adolescence (mirrors AFCARS entry patterns).

generate_age_curve <- function(peak_rate, baseline, adolescent_bump = 0,
                               infant_weight = 1.0) {
  # peak_rate: maximum rate (per 1000) typically at age 0-1

  # baseline:  trough rate around ages 8-10
  # adolescent_bump: added rate at ages 14-17
  curve <- numeric(n_ages)
  for (i in seq_along(ages)) {
    a <- ages[i]
    infant   <- peak_rate * exp(-0.45 * a) * infant_weight
    base_val <- baseline
    adol     <- adolescent_bump * pmax(0, (a - 12)) / 5
    curve[i] <- infant + base_val + adol
  }
  curve / 1000                      # convert to probability scale
}

# --- Event 1: Substance-Related Removal ------------------------------------
# National ~30-40% of removals cite parental substance use;
# disproportionately affects AI/AN, White rural, and Black urban communities.

substance_rates <- tibble(
  age = rep(ages, length(race_groups)),
  race = rep(race_groups, each = n_ages),
  event = "Substance-Related Removal",
  rate = c(
    generate_age_curve(12.0, 0.6, 0.4, 1.2),   # AI/AN
    generate_age_curve( 8.0, 0.5, 0.3, 1.0),   # Black
    generate_age_curve( 4.5, 0.25, 0.15, 0.9),  # Hispanic
    generate_age_curve( 5.0, 0.30, 0.20, 1.0),  # White
    generate_age_curve( 1.2, 0.08, 0.05, 0.7),  # Asian
    generate_age_curve( 7.0, 0.40, 0.25, 1.0),  # NHPI
    generate_age_curve( 5.5, 0.35, 0.20, 0.9),  # Multirace
    generate_age_curve( 5.2, 0.30, 0.18, 1.0)   # Overall
  )
)

# --- Event 2: Infant Entry (age 0-1 foster care placement) -----------------
# Concentrated at age 0; effectively zero at later ages by definition.

infant_entry_rates <- tibble(
  age = rep(ages, length(race_groups)),
  race = rep(race_groups, each = n_ages),
  event = "Infant Entry",
  rate = c(
    c(28.0, 8.0, rep(0, 16)) / 1000,   # AI/AN
    c(22.0, 6.5, rep(0, 16)) / 1000,   # Black
    c(10.0, 3.0, rep(0, 16)) / 1000,   # Hispanic
    c(11.5, 3.5, rep(0, 16)) / 1000,   # White
    c( 3.5, 1.0, rep(0, 16)) / 1000,   # Asian
    c(16.0, 5.0, rep(0, 16)) / 1000,   # NHPI
    c(13.0, 4.0, rep(0, 16)) / 1000,   # Multirace
    c(12.5, 3.8, rep(0, 16)) / 1000    # Overall
  )
)

# --- Event 3: Missing Episode While in Care --------------------------------
# Primarily adolescents; disproportionately affects older Black and
# AI/AN youth in care (see AFCARS missing-from-care flags).

missing_rates <- tibble(
  age = rep(ages, length(race_groups)),
  race = rep(race_groups, each = n_ages),
  event = "Missing Episode",
  rate = c(
    generate_age_curve(0.5, 0.10, 2.8, 0.3),  # AI/AN
    generate_age_curve(0.4, 0.10, 3.5, 0.3),  # Black
    generate_age_curve(0.3, 0.06, 1.8, 0.2),  # Hispanic
    generate_age_curve(0.3, 0.05, 1.5, 0.2),  # White
    generate_age_curve(0.1, 0.02, 0.6, 0.1),  # Asian
    generate_age_curve(0.4, 0.08, 2.2, 0.3),  # NHPI
    generate_age_curve(0.3, 0.07, 2.0, 0.2),  # Multirace
    generate_age_curve(0.3, 0.06, 1.8, 0.2)   # Overall
  )
)

# --- Event 4: In-Care Maltreatment -----------------------------------------
# Substantiated maltreatment occurring while child is in foster care.
# Based on NCANDS + AFCARS linkage methods (Putnam-Hornstein et al.).

incare_malt_rates <- tibble(
  age = rep(ages, length(race_groups)),
  race = rep(race_groups, each = n_ages),
  event = "In-Care Maltreatment",
  rate = c(
    generate_age_curve(4.5, 0.30, 0.20, 1.1),  # AI/AN
    generate_age_curve(3.8, 0.28, 0.18, 1.0),  # Black
    generate_age_curve(2.5, 0.15, 0.10, 0.9),  # Hispanic
    generate_age_curve(2.8, 0.18, 0.12, 0.9),  # White
    generate_age_curve(0.8, 0.05, 0.03, 0.6),  # Asian
    generate_age_curve(3.2, 0.22, 0.15, 1.0),  # NHPI
    generate_age_curve(2.6, 0.17, 0.11, 0.9),  # Multirace
    generate_age_curve(2.7, 0.17, 0.11, 0.9)   # Overall
  )
)

# --- Combine all events -----------------------------------------------------
incidence_data <- bind_rows(
  substance_rates,
  infant_entry_rates,
  missing_rates,
  incare_malt_rates
)

# --- Synthetic population denominators (Census / CDC bridged-race style) ----
# Single-year-of-age counts by race (approximate US child population shares)
pop_shares <- c(
  "AI/AN" = 0.012, "Black" = 0.137, "Hispanic" = 0.258,
  "White" = 0.485, "Asian" = 0.055, "NHPI" = 0.004,
  "Multirace" = 0.049, "Overall" = 1.0
)

total_children_per_age <- 4000000   # ~4 million births/year in US

population_denom <- expand_grid(age = ages, race = race_groups) %>%

  mutate(
    population = round(total_children_per_age * pop_shares[race]),
    # Derive synthetic event counts from rates × population
    # (for bootstrap purposes)
    event_count_substance  = NA_real_,
    event_count_infant     = NA_real_,
    event_count_missing    = NA_real_,
    event_count_incare     = NA_real_
  )

# Fill event counts using incidence rates (adds Poisson noise)
for (r in race_groups) {
  for (a in ages) {
    idx <- which(population_denom$race == r & population_denom$age == a)
    pop <- population_denom$population[idx]

    get_rate <- function(ev) {
      incidence_data %>%
        filter(race == r, age == a, event == ev) %>%
        pull(rate)
    }

    population_denom$event_count_substance[idx] <-
      rpois(1, pop * get_rate("Substance-Related Removal"))
    population_denom$event_count_infant[idx] <-
      rpois(1, pop * get_rate("Infant Entry"))
    population_denom$event_count_missing[idx] <-
      rpois(1, pop * get_rate("Missing Episode"))
    population_denom$event_count_incare[idx] <-
      rpois(1, pop * get_rate("In-Care Maltreatment"))
  }
}

# --- Add geographic breakdown (state × urban/rural) for sub-analyses --------
states_sample <- c("Illinois", "Texas", "California", "New York", "Oklahoma")
urbanicity    <- c("Urban", "Rural")

geo_data <- expand_grid(
  age   = ages,
  race  = race_groups,
  state = states_sample,
  urban_rural = urbanicity
) %>%
  mutate(
    # Adjust rates: rural areas +30% for substance, urban +20% for missing
    geo_multiplier_substance = ifelse(urban_rural == "Rural", 1.3, 0.85),
    geo_multiplier_missing   = ifelse(urban_rural == "Urban", 1.2, 0.90),
    # State-level variation (illustrative)
    state_multiplier = case_when(
      state == "Illinois"   ~ 1.05,
      state == "Oklahoma"   ~ 1.25,
      state == "California" ~ 0.90,
      state == "Texas"      ~ 1.00,
      state == "New York"   ~ 0.95,
      TRUE                  ~ 1.0
    )
  )

cat("✓ Synthetic data generated for", length(race_groups), "race/ethnicity groups,",
    length(ages), "ages,", length(states_sample), "states\n")


# ============================================================================
# 2.  SYNTHETIC COHORT LIFE TABLE ENGINE
# ============================================================================
#
#  Method (Wildeman 2009, 2014; Preston et al. 2001, Ch. 3):
#
#  For a non-repeatable event experienced by age x:
#    q(x) = age-specific incidence rate at age x (events / population)
#    S(x) = ∏_{a=0}^{x-1} [1 - q(a)]   ... survival to age x without event
#    F(x) = 1 - S(x)                    ... cumulative risk by age x
#
#  Cumulative lifetime risk by age 18 = F(18) = 1 - ∏_{a=0}^{17} [1 - q(a)]
#
#  This treats the cross-sectional age-specific rates as if they applied to
#  a single synthetic cohort passing through ages 0-17.
#
# ============================================================================

#' Compute cumulative risk from a vector of age-specific rates
#'
#' @param q_x Numeric vector of age-specific incidence rates (length 18: ages 0-17)
#' @return    Tibble with columns: age, q_x, survival, cum_risk
compute_life_table <- function(q_x) {
  stopifnot(length(q_x) == 18)
  # Bound rates to [0, 1] for valid probability

  q_x <- pmin(pmax(q_x, 0), 1)

  survival <- numeric(n_ages)
  survival[1] <- 1.0                       # everyone starts alive/un-evented

  for (i in 2:n_ages) {
    survival[i] <- survival[i - 1] * (1 - q_x[i - 1])
  }

  cum_risk <- 1 - survival * (1 - q_x)    # F(x) after passing through age x

  tibble(
    age      = ages,
    q_x      = q_x,
    survival = survival,
    cum_risk = cum_risk
  )
}


#' Build life tables for all groups × events
#'
#' @param data  Tibble with columns: age, race, event, rate
#' @return      Tibble with life table columns appended
build_all_life_tables <- function(data) {
  data %>%
    group_by(race, event) %>%
    arrange(age, .by_group = TRUE) %>%
    group_modify(~ {
      lt <- compute_life_table(.x$rate)
      bind_cols(.x, lt %>% select(survival, cum_risk))
    }) %>%
    ungroup()
}

# --- Compute life tables for national data ----------------------------------
life_tables <- build_all_life_tables(incidence_data)

# Extract cumulative risk by age 18 (the final row per group)
cum_risk_18 <- life_tables %>%
  group_by(race, event) %>%
  slice_max(age, n = 1) %>%
  ungroup() %>%
  select(race, event, cum_risk_18 = cum_risk)

cat("\n✓ Life tables computed for all race × event combinations\n")
print(
  cum_risk_18 %>%
    mutate(cum_risk_pct = scales::percent(cum_risk_18, accuracy = 0.01)) %>%
    pivot_wider(names_from = event, values_from = cum_risk_pct) %>%
    arrange(race)
)


# ============================================================================
# 3.  DISPARITY RATIOS & DECOMPOSITION
# ============================================================================

# --- 3a. Disparity ratios (reference group = White) -------------------------

disparity_ratios <- cum_risk_18 %>%
  left_join(
    cum_risk_18 %>%
      filter(race == "White") %>%
      select(event, white_risk = cum_risk_18),
    by = "event"
  ) %>%
  mutate(
    ratio_vs_white   = cum_risk_18 / white_risk,
    diff_vs_white    = cum_risk_18 - white_risk,
    diff_per_1000    = diff_vs_white * 1000
  ) %>%
  filter(race != "Overall")

cat("\n✓ Disparity ratios (vs. White reference):\n")
print(
  disparity_ratios %>%
    select(race, event, ratio_vs_white) %>%
    mutate(ratio_vs_white = round(ratio_vs_white, 2)) %>%
    pivot_wider(names_from = event, values_from = ratio_vs_white)
)


# --- 3b. Age-decomposition of disparities -----------------------------------
#  Partition the cumulative risk gap into contributions from each age band.
#  Method: incremental decomposition following Kitagawa (1955) and
#  adapted for life table contexts (see Preston et al. 2001).
#
#  ΔF = Σ_x [ S_white(x) * Δq(x) + q_mean(x) * ΔS(x) ]
#  where Δq(x) = q_target(x) - q_white(x)

decompose_disparity <- function(lt_data, target_race, ref_race = "White",
                                 target_event) {
  lt_target <- lt_data %>%
    filter(race == target_race, event == target_event) %>%
    arrange(age)
  lt_ref <- lt_data %>%
    filter(race == ref_race, event == target_event) %>%
    arrange(age)

  delta_q <- lt_target$rate - lt_ref$rate
  mean_q  <- (lt_target$rate + lt_ref$rate) / 2
  delta_S <- lt_target$survival - lt_ref$survival
  mean_S  <- (lt_target$survival + lt_ref$survival) / 2

  # Approximate decomposition
  age_contribution <- mean_S * delta_q

  tibble(
    age             = ages,
    target_race     = target_race,
    ref_race        = ref_race,
    event           = target_event,
    delta_q         = delta_q,
    age_contribution = age_contribution,
    pct_of_gap      = age_contribution / sum(age_contribution)
  )
}

# Decompose Black-White gap for each event
decomp_results <- map_dfr(unique(incidence_data$event), function(ev) {
  map_dfr(setdiff(race_groups, c("White", "Overall")), function(r) {
    tryCatch(
      decompose_disparity(life_tables, target_race = r, target_event = ev),
      error = function(e) tibble()
    )
  })
})

cat("\n✓ Age-decomposition of disparities computed\n")


# ============================================================================
# 4.  BOOTSTRAP CONFIDENCE INTERVALS
# ============================================================================
#
#  Two methods are implemented:
#    (a) Parametric bootstrap: resample event counts ~ Poisson(λ = rate × pop)
#    (b) Delta method approximation (faster, for large denominators)
#
# ============================================================================

n_boot <- 1000

#' Bootstrap cumulative risk for one race × event combination
#'
#' @param rates      Age-specific incidence rates (length 18)
#' @param pops       Age-specific population denominators (length 18)
#' @param n_boot     Number of bootstrap iterations
#' @return           Tibble with age, mean, lower (2.5%), upper (97.5%)
bootstrap_cum_risk <- function(rates, pops, n_boot = 1000) {
  # Matrix: rows = ages, cols = bootstrap iterations
  boot_risks <- matrix(NA, nrow = n_ages, ncol = n_boot)

  for (b in 1:n_boot) {
    # Resample counts from Poisson; derive rates
    boot_counts <- rpois(n_ages, lambda = rates * pops)
    boot_rates  <- boot_counts / pmax(pops, 1)
    boot_rates  <- pmin(pmax(boot_rates, 0), 1)

    # Compute cumulative risk
    surv <- cumprod(c(1, 1 - boot_rates[-n_ages]))
    boot_risks[, b] <- 1 - surv * (1 - boot_rates)
  }

  tibble(
    age      = ages,
    mean     = rowMeans(boot_risks),
    lower_ci = apply(boot_risks, 1, quantile, probs = 0.025),
    upper_ci = apply(boot_risks, 1, quantile, probs = 0.975)
  )
}

#' Delta method SE for cumulative risk at age x
#'
#' Var(F_x) ≈ Σ_{a=0}^{x} [∂F_x/∂q_a]² × Var(q_a)
#' where Var(q_a) = q_a(1-q_a)/n_a  (binomial variance)
delta_method_ci <- function(rates, pops, z = 1.96) {
  q_x <- pmin(pmax(rates, 0), 1)
  n_x <- pmax(pops, 1)

  surv   <- cumprod(c(1, 1 - q_x[-n_ages]))
  cum_risk <- 1 - surv * (1 - q_x)

  # Variance of q_x (binomial)
  var_q <- q_x * (1 - q_x) / n_x

  # Gradient of F(x) w.r.t. each q(a) via chain rule
  se_F <- numeric(n_ages)
  for (x in 1:n_ages) {
    grad_sq_sum <- 0
    for (a in 1:x) {
      # ∂F_x/∂q_a ≈ product of (1-q_j) for j≠a, j<=x
      if (a <= x) {
        partial <- prod((1 - q_x[1:x])[-a]) / max(prod(1 - q_x[1:x]), 1e-12)
        partial <- partial * prod(1 - q_x[1:x])  # simplified
        grad_sq_sum <- grad_sq_sum + partial^2 * var_q[a]
      }
    }
    se_F[x] <- sqrt(grad_sq_sum)
  }

  tibble(
    age      = ages,
    cum_risk = cum_risk,
    se       = se_F,
    lower_ci = pmax(cum_risk - z * se_F, 0),
    upper_ci = pmin(cum_risk + z * se_F, 1)
  )
}

# --- Run bootstrap for all groups -------------------------------------------
cat("\n⏳ Running bootstrap (", n_boot, "iterations)... ")

boot_results <- incidence_data %>%
  left_join(
    population_denom %>% select(age, race, population),
    by = c("age", "race")
  ) %>%
  group_by(race, event) %>%
  arrange(age, .by_group = TRUE) %>%
  group_modify(~ {
    bootstrap_cum_risk(.x$rate, .x$population, n_boot = n_boot)
  }) %>%
  ungroup()

cat("Done ✓\n")

# Merge bootstrap CIs with point estimates
life_tables_ci <- life_tables %>%
  left_join(
    boot_results %>% select(race, event, age, lower_ci, upper_ci),
    by = c("race", "event", "age")
  )


# ============================================================================
# 5.  GEOGRAPHIC SUB-ANALYSES (State × Urban/Rural)
# ============================================================================

# Generate state-level life tables with geographic adjustments
geo_life_tables <- geo_data %>%
  left_join(incidence_data, by = c("age", "race")) %>%
  mutate(
    adjusted_rate = case_when(
      event == "Substance-Related Removal" ~
        rate * geo_multiplier_substance * state_multiplier,
      event == "Missing Episode" ~
        rate * geo_multiplier_missing * state_multiplier,
      TRUE ~ rate * state_multiplier
    )
  ) %>%
  group_by(race, event, state, urban_rural) %>%
  arrange(age, .by_group = TRUE) %>%
  group_modify(~ {
    lt <- compute_life_table(.x$adjusted_rate)
    bind_cols(.x, lt %>% select(survival, cum_risk))
  }) %>%
  ungroup()

geo_cum_risk_18 <- geo_life_tables %>%
  group_by(race, event, state, urban_rural) %>%
  slice_max(age, n = 1) %>%
  ungroup() %>%
  select(race, event, state, urban_rural, cum_risk_18 = cum_risk)

cat("\n✓ Geographic sub-analyses complete\n")


# ============================================================================
# 6.  VISUALIZATIONS
# ============================================================================

# --- 6a.  Cumulative Risk Curves by Race/Ethnicity --------------------------

plot_cumulative_risk <- function(lt_data, focal_event,
                                  title_suffix = "",
                                  show_ci = TRUE) {
  df <- lt_data %>% filter(event == focal_event)

  p <- ggplot(df, aes(x = age, y = cum_risk, color = race)) +
    geom_line(linewidth = 1.1) +
    geom_point(size = 1.2, alpha = 0.5)


  if (show_ci && "lower_ci" %in% names(df)) {
    p <- p +
      geom_ribbon(
        aes(ymin = lower_ci, ymax = upper_ci, fill = race),
        alpha = 0.12, color = NA
      ) +
      scale_fill_manual(values = race_colors, guide = "none")
  }

  p +
    scale_color_manual(values = race_colors) +
    scale_y_continuous(
      labels = scales::percent_format(accuracy = 0.1),
      expand = expansion(mult = c(0, 0.05))
    ) +
    scale_x_continuous(breaks = seq(0, 17, by = 2)) +
    labs(
      title    = glue("Cumulative Risk of {focal_event} by Age"),
      subtitle = glue(
        "Synthetic cohort life table estimates, by race/ethnicity{title_suffix}"
      ),
      x = "Age",
      y = "Cumulative Probability",
      caption = paste(
        "Method: Wildeman (2009, 2014); Edwards et al. (2021).",
        "Rates derived from AFCARS/NCANDS; denominators from Census.",
        "\nNote: Shaded bands = 95% bootstrap CIs.",
        "SYNTHETIC DATA FOR DEMONSTRATION."
      )
    )
}

# Generate all four focal event plots
p_substance <- plot_cumulative_risk(life_tables_ci, "Substance-Related Removal")
p_infant    <- plot_cumulative_risk(life_tables_ci, "Infant Entry")
p_missing   <- plot_cumulative_risk(life_tables_ci, "Missing Episode")
p_incare    <- plot_cumulative_risk(life_tables_ci, "In-Care Maltreatment")

# Combined panel
p_combined <- (p_substance + p_infant) / (p_missing + p_incare) +

  plot_annotation(
    title    = "Cumulative Lifetime Risks of Child Welfare Events by Race/Ethnicity",
    subtitle = "Synthetic cohort (life table) estimates through age 18",
    caption  = "Data: Synthetic demonstration data calibrated to national estimates.\nMethods: Wildeman (2009, 2014); Edwards et al. (2021); Putnam-Hornstein et al. (2013, 2021).",
    theme    = theme(
      plot.title    = element_text(face = "bold", size = 17),
      plot.subtitle = element_text(color = "grey35", size = 12)
    )
  )


# --- 6b.  Disparity Ratio Forest Plot --------------------------------------

p_disparity <- disparity_ratios %>%
  filter(race != "Asian") %>%    # exclude for readability
  ggplot(aes(x = ratio_vs_white, y = reorder(race, ratio_vs_white),
             color = race)) +
  geom_vline(xintercept = 1, linetype = "dashed", color = "grey60") +
  geom_point(size = 3.5) +
  geom_segment(
    aes(x = 1, xend = ratio_vs_white, yend = race),
    linewidth = 0.8
  ) +
  facet_wrap(~ event, scales = "free_x", ncol = 2) +
  scale_color_manual(values = race_colors) +
  labs(
    title    = "Disparity Ratios: Cumulative Risk Relative to White Children",
    subtitle = "Values > 1 indicate higher risk for the group vs. White reference",
    x        = "Risk Ratio (vs. White)",
    y        = NULL,
    caption  = "Reference group: White non-Hispanic. SYNTHETIC DATA."
  )


# --- 6c.  Age Decomposition Stacked Area Plot --------------------------------

p_decomp <- decomp_results %>%
  filter(target_race == "Black") %>%
  mutate(age_group = cut(age, breaks = c(-1, 0, 2, 5, 11, 17),
                         labels = c("0", "1-2", "3-5", "6-11", "12-17"))) %>%
  group_by(event, age_group) %>%
  summarise(contribution = sum(age_contribution), .groups = "drop") %>%
  ggplot(aes(x = event, y = contribution, fill = age_group)) +
  geom_col(position = "fill", width = 0.7) +
  scale_y_continuous(labels = scales::percent_format()) +
  scale_fill_brewer(palette = "YlOrRd", name = "Age Group") +
  labs(
    title    = "Age Decomposition of Black-White Disparity Gap",
    subtitle = "Share of cumulative risk gap attributable to each age band",
    x        = NULL,
    y        = "Proportion of Disparity Gap",
    caption  = "Method: Kitagawa decomposition adapted for life table framework."
  ) +
  theme(axis.text.x = element_text(angle = 15, hjust = 1))


# --- 6d.  Geographic Heatmap (State × Urban/Rural) --------------------------

p_geo_heatmap <- geo_cum_risk_18 %>%
  filter(event == "Substance-Related Removal",
         race %in% c("AI/AN", "Black", "White")) %>%
  mutate(label = scales::percent(cum_risk_18, accuracy = 0.1)) %>%
  ggplot(aes(x = interaction(state, urban_rural, sep = "\n"),
             y = race, fill = cum_risk_18)) +
  geom_tile(color = "white", linewidth = 0.5) +
  geom_text(aes(label = label), size = 3, fontface = "bold") +
  scale_fill_distiller(
    palette = "YlOrRd", direction = 1,
    labels = scales::percent_format(),
    name = "Cum. Risk\nby Age 18"
  ) +
  labs(
    title    = "Substance-Related Removal: Cumulative Risk by State & Urbanicity",
    subtitle = "Selected states, by race/ethnicity",
    x        = NULL, y = NULL,
    caption  = "Rural communities show elevated substance-related removal rates. SYNTHETIC DATA."
  ) +
  theme(axis.text.x = element_text(size = 8))


# --- 6e.  Urban vs. Rural Comparison Dot Plot --------------------------------

p_urban_rural <- geo_cum_risk_18 %>%
  filter(race %in% c("AI/AN", "Black", "Hispanic", "White"),
         event %in% c("Substance-Related Removal", "In-Care Maltreatment")) %>%
  ggplot(aes(x = cum_risk_18, y = race, color = urban_rural, shape = urban_rural)) +
  geom_point(size = 3, alpha = 0.8, position = position_dodge(width = 0.5)) +
  facet_grid(state ~ event, scales = "free_x") +
  scale_x_continuous(labels = scales::percent_format(accuracy = 0.1)) +
  scale_color_manual(values = c("Urban" = "#2166AC", "Rural" = "#B2182B")) +
  labs(
    title    = "Urban vs. Rural Cumulative Risk by Race and State",
    subtitle = "Substance-related removal and in-care maltreatment",
    x        = "Cumulative Risk by Age 18",
    y        = NULL,
    color    = NULL, shape = NULL,
    caption  = "SYNTHETIC DATA FOR DEMONSTRATION."
  )


# ============================================================================
# 7.  SUMMARY TABLES
# ============================================================================

# --- 7a. Master Summary Table -----------------------------------------------

summary_table <- cum_risk_18 %>%
  left_join(
    disparity_ratios %>%
      select(race, event, ratio_vs_white, diff_per_1000),
    by = c("race", "event")
  ) %>%
  mutate(
    cum_risk_pct   = scales::percent(cum_risk_18, accuracy = 0.01),
    ratio_display  = ifelse(is.na(ratio_vs_white), "Ref",
                            sprintf("%.2f", ratio_vs_white)),
    diff_display   = ifelse(is.na(diff_per_1000), "—",
                            sprintf("%+.1f", diff_per_1000))
  ) %>%
  select(Race = race, Event = event,
         `Cum. Risk (%)` = cum_risk_pct,
         `Ratio vs White` = ratio_display,
         `Diff per 1,000` = diff_display)

# --- 7b. Bootstrap CI Table at Age 18 --------------------------------------

ci_table <- boot_results %>%
  group_by(race, event) %>%
  slice_max(age, n = 1) %>%
  ungroup() %>%
  mutate(
    estimate = scales::percent(mean, accuracy = 0.01),
    ci       = glue("({scales::percent(lower_ci, accuracy = 0.01)}, ",
                    "{scales::percent(upper_ci, accuracy = 0.01)})")
  ) %>%
  select(Race = race, Event = event, Estimate = estimate, `95% CI` = ci)


# ============================================================================
# 8.  EQUITY-FOCUSED LEGISLATIVE NARRATIVE
# ============================================================================

generate_equity_narrative <- function(cum_risk_df, disparity_df, event_name) {

  # Extract key statistics
  aian_risk  <- cum_risk_df %>% filter(race == "AI/AN", event == event_name) %>%
    pull(cum_risk_18)
  black_risk <- cum_risk_df %>% filter(race == "Black", event == event_name) %>%
    pull(cum_risk_18)
  white_risk <- cum_risk_df %>% filter(race == "White", event == event_name) %>%
    pull(cum_risk_18)
  hisp_risk  <- cum_risk_df %>% filter(race == "Hispanic", event == event_name) %>%
    pull(cum_risk_18)

  aian_ratio  <- disparity_df %>%
    filter(race == "AI/AN", event == event_name) %>% pull(ratio_vs_white)
  black_ratio <- disparity_df %>%
    filter(race == "Black", event == event_name) %>% pull(ratio_vs_white)

  glue("
══════════════════════════════════════════════════════════════════════════
  EQUITY BRIEF: {toupper(event_name)}
══════════════════════════════════════════════════════════════════════════

KEY FINDING:
  Using synthetic cohort life table methods (Wildeman 2009, 2014),
  we estimate that by age 18:

  • {scales::percent(aian_risk, accuracy = 0.1)} of American Indian/Alaska Native children,
  • {scales::percent(black_risk, accuracy = 0.1)} of Black children,
  • {scales::percent(hisp_risk, accuracy = 0.1)} of Hispanic children, and
  • {scales::percent(white_risk, accuracy = 0.1)} of White children

  will experience {tolower(event_name)} if current age-specific rates persist.

DISPARITY MAGNITUDE:
  AI/AN children face {sprintf('%.1fx', aian_ratio)} the risk of White children.
  Black children face {sprintf('%.1fx', black_ratio)} the risk of White children.

  These disparities are NOT explained by differences in actual maltreatment
  prevalence alone. Research consistently shows that surveillance bias,
  poverty-related family stress misidentified as neglect, and systemic
  inequities in reporting, investigation, and removal decisions
  disproportionately affect communities of color (Roberts 2002;
  Dettlaff et al. 2011; Edwards et al. 2021).

STRUCTURAL CONTEXT:
  ◦ The Indian Child Welfare Act (ICWA) was enacted specifically to address
    the historical over-removal of AI/AN children; these data show the
    crisis persists despite federal protections.
  ◦ Black families are subject to heightened surveillance via mandated
    reporting in schools, hospitals, and public benefits systems,
    inflating investigation and removal rates (Dettlaff & Boyd 2020).
  ◦ Rural communities face compounded risk due to limited access to
    substance use treatment, family preservation services, and legal
    representation (Maguire-Jack et al. 2020).

POLICY IMPLICATIONS:
  1. Invest in community-based prevention and family support services
     targeted at the age windows driving the largest disparities
     (infancy and early childhood for removals; adolescence for
     missing episodes).
  2. Mandate racial equity impact assessments for all child welfare
     policy changes at state and federal levels.
  3. Expand access to substance use treatment and housing stability
     programs, which address root causes rather than surveilling
     and separating families.
  4. Strengthen data infrastructure to enable routine monitoring of
     cumulative lifetime risk disparities as an accountability metric.

──────────────────────────────────────────────────────────────────────────
  Method: Synthetic cohort (period) life tables applied to
  multi-year AFCARS/NCANDS microdata with Census denominators.
  References: Wildeman (2009); Wildeman (2014); Edwards et al. (2021);
  Putnam-Hornstein et al. (2013, 2021); Yi et al. (2020).
══════════════════════════════════════════════════════════════════════════
")
}

# Generate narratives for all four events
narratives <- map_chr(unique(incidence_data$event), function(ev) {
  generate_equity_narrative(cum_risk_18, disparity_ratios, ev)
})

cat("\n", paste(narratives, collapse = "\n\n"))


# ============================================================================
# 9.  SAVE ALL OUTPUTS
# ============================================================================

output_dir <- "/home/claude/outputs"
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

# --- Save plots ---
ggsave(file.path(output_dir, "01_cumulative_risk_panel.png"),
       p_combined, width = 16, height = 12, dpi = 300, bg = "white")

ggsave(file.path(output_dir, "02_disparity_ratios.png"),
       p_disparity, width = 12, height = 8, dpi = 300, bg = "white")

ggsave(file.path(output_dir, "03_age_decomposition.png"),
       p_decomp, width = 10, height = 7, dpi = 300, bg = "white")

ggsave(file.path(output_dir, "04_geo_heatmap.png"),
       p_geo_heatmap, width = 14, height = 6, dpi = 300, bg = "white")

ggsave(file.path(output_dir, "05_urban_rural_comparison.png"),
       p_urban_rural, width = 14, height = 10, dpi = 300, bg = "white")

# Individual event plots
ggsave(file.path(output_dir, "06_substance_removal_curve.png"),
       p_substance, width = 10, height = 7, dpi = 300, bg = "white")

ggsave(file.path(output_dir, "07_infant_entry_curve.png"),
       p_infant, width = 10, height = 7, dpi = 300, bg = "white")

ggsave(file.path(output_dir, "08_missing_episode_curve.png"),
       p_missing, width = 10, height = 7, dpi = 300, bg = "white")

ggsave(file.path(output_dir, "09_incare_maltreatment_curve.png"),
       p_incare, width = 10, height = 7, dpi = 300, bg = "white")

# --- Save tables as CSV ---
write_csv(summary_table, file.path(output_dir, "table_summary.csv"))
write_csv(ci_table,      file.path(output_dir, "table_bootstrap_ci.csv"))
write_csv(
  geo_cum_risk_18 %>% mutate(cum_risk_pct = scales::percent(cum_risk_18, 0.01)),
  file.path(output_dir, "table_geographic_risks.csv")
)
write_csv(decomp_results, file.path(output_dir, "table_decomposition.csv"))

# --- Save equity narratives ---
writeLines(paste(narratives, collapse = "\n\n"),
           file.path(output_dir, "equity_legislative_narratives.txt"))

# --- Save full life tables ---
write_csv(life_tables_ci, file.path(output_dir, "full_life_tables.csv"))

cat("\n\n══════════════════════════════════════════════════════════════\n")
cat("  ALL OUTPUTS SAVED to:", output_dir, "\n")
cat("══════════════════════════════════════════════════════════════\n")
cat("\nFiles generated:\n")
list.files(output_dir) %>% cat(sep = "\n")
