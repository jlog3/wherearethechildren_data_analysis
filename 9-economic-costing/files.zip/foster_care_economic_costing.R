###############################################################################
#  ECONOMIC COSTING OF CHILD-WELFARE TRANSPARENCY GAPS
#  ─────────────────────────────────────────────────────
#  Four cost domains:
#    1. Direct placement costs  (episode days × daily rates)
#    2. Search / recovery costs for missing-from-care children
#    3. Indirect lifetime costs  (health, education, justice multipliers)
#    4. Administrative / system friction costs
#
#  Data foundations:
#    • AFCARS episode durations  (public flat files)
#    • Published per-diem / per-child cost estimates (CWLA, Casey, GAO)
#    • Lifetime-cost multipliers from CCOULD / Courtney et al. / Jim Casey
#
#  Outputs:
#    cost_summary_tables.csv      – national & state aggregates
#    scenario_results.csv         – "what-if" reduction scenarios
#    waterfall_chart.png          – stacked cost decomposition
#    roi_dashboard.png            – ROI panel for transparency investment
#    full_report_tables.xlsx      – formatted Excel workbook (optional)
###############################################################################

# ── 0. SETUP ─────────────────────────────────────────────────────────────────

suppressPackageStartupMessages({
  library(tidyverse)
  library(scales)
  library(ggplot2)
  library(patchwork)    # multi-panel layouts
  library(gt)           # publication-quality tables
  library(readxl)       # if AFCARS comes in .xlsx
  library(writexl)      # Excel output
  library(glue)
})

theme_set(

  theme_minimal(base_size = 13) +
    theme(
      plot.title    = element_text(face = "bold", size = 15),
      plot.subtitle = element_text(color = "grey40"),
      panel.grid.minor = element_blank()
    )
)

out_dir <- "outputs"
dir.create(out_dir, showWarnings = FALSE)

cat("══════════════════════════════════════════════════════════\n")
cat("  Foster-Care Economic Costing Workflow\n")
cat("══════════════════════════════════════════════════════════\n\n")

###############################################################################
# ── 1. REFERENCE COST PARAMETERS ─────────────────────────────────────────────
#    Sources cited inline.  All figures inflation-adjusted to 2024 USD.
###############################################################################

cost_params <- list(

  # ---- 1A. DAILY PLACEMENT RATES (per child per day) ----
  # Source: Child Trends / CWLA surveys; state Medicaid rate schedules
  daily_rate = tibble::tribble(
    ~placement_type,       ~daily_rate_usd, ~source,
    "Family Foster Home",          85,      "CWLA 2023 avg; range $60-$130",
    "Kinship Care",                55,      "Typically 50-70% of foster rate",
    "Therapeutic Foster",         165,      "Level-2 treatment foster avg",
    "Group Home",                 290,      "GAO-2024; range $200-$500",
    "Residential Treatment",      490,      "Casey 2022; includes clinical",
    "Pre-Adoptive Home",           75,      "Similar to family foster",
    "Supervised Independent",      60,      "Transitional living stipends",
    "Trial Home Visit",            25,      "Minimal supervision costs"
  ),


  # ---- 1B. MISSING-FROM-CARE SEARCH COSTS ----
  # Source: NCMEC operational data; Polaris Project; state IG reports
  search_cost_per_episode = 4800,   # avg law-enforcement + caseworker hours
  search_cost_high        = 12000,  # complex / multi-jurisdiction
  pct_children_missing    = 0.015,  # ~1.5% of foster pop in any year (AFCARS)

  # ---- 1C. INDIRECT LIFETIME COST MULTIPLIERS (per child) ----
  # Source: Courtney et al. Midwest Study; Jim Casey Youth Opportunities;
  #         CCOULD linked-data studies; Zill & Bramlett HHS analysis
  indirect_costs = tibble::tribble(
    ~domain,               ~per_child_lifetime_usd, ~source,
    "Physical Health",              42700,           "Courtney 2011; excess Medicaid",
    "Mental Health",                38500,           "Havlicek et al.; CCOULD linked",
    "Education Gaps",               54200,           "Jim Casey 2023; lost earnings",
    "Criminal Justice",             62400,           "Courtney Midwest; Doyle 2007",
    "Homelessness Risk",            29100,           "Dworsky & Courtney 2009",
    "Substance Use Treatment",      18700,           "NSDUH cross-walk; Pecora 2005"
  ),

  # ---- 1D. ADMIN / SYSTEM FRICTION ----
  admin_cost_per_child_year = 8200,   # case management overhead
  duplicative_data_entry_pct = 0.12,  # 12% of admin is redundant data work
  transparency_infra_annual  = 0      # placeholder; set in scenarios
)

cat("✓ Cost parameters loaded (8 placement types, 6 indirect domains)\n")

###############################################################################
# ── 2. SYNTHETIC AFCARS-STYLE EPISODE DATA ───────────────────────────────────
#    In production, replace with actual AFCARS Research File or NDACAN extract.
#    This synthetic dataset mirrors the variable structure and distributions.
###############################################################################

set.seed(42)

states_pop <- tibble::tribble(
  ~state, ~foster_pop_approx,
  "CA", 52000, "TX", 30000, "FL", 24000, "NY", 16000, "OH", 15000,
  "PA", 13500, "IL", 12000, "MI", 11000, "GA", 10500, "NC",  9000,
  "AZ",  8500, "IN",  8200, "VA",  7000, "MO",  7500, "WI",  6500,
  "TN",  6800, "MN",  6000, "AL",  5500, "SC",  5200, "OR",  5000,
  "WA",  5800, "CO",  5300, "OK",  4800, "KY",  4600, "LA",  4200,
  "MD",  3900, "AR",  3500, "MS",  3200, "IA",  3000, "KS",  2800,
  "NV",  2600, "CT",  2500, "NM",  2300, "UT",  2200, "NE",  1900,
  "WV",  1800, "NJ",  4500, "MA",  3700, "HI",  1400, "ID",  1200,
  "ME",  1100, "MT",  1000, "NH",   900, "RI",   800, "SD",   750,
  "ND",   700, "AK",   650, "VT",   500, "WY",   450, "DE",  1300,
  "DC",  1100
)

# Placement-type distribution (approx. AFCARS FY2022 proportions)
placement_probs <- c(
  `Family Foster Home` = 0.45, `Kinship Care` = 0.32,
  `Therapeutic Foster`  = 0.06, `Group Home` = 0.05,
  `Residential Treatment` = 0.04, `Pre-Adoptive Home` = 0.04,
  `Supervised Independent` = 0.025, `Trial Home Visit` = 0.015
)

generate_state_episodes <- function(st, n) {
  tibble(
    state          = st,
    placement_type = sample(names(placement_probs), n,
                            replace = TRUE, prob = placement_probs),
    episode_days   = pmax(1, round(rlnorm(n, meanlog = log(280), sdlog = 0.85))),
    age_at_entry   = pmin(17, pmax(0, round(rnorm(n, mean = 7.5, sd = 4.5)))),
    is_missing     = rbinom(n, 1, cost_params$pct_children_missing)
  )
}

afcars <- states_pop %>%
  rowwise() %>%
  reframe(generate_state_episodes(state, foster_pop_approx)) %>%
  ungroup() %>%
  mutate(child_id = row_number())

cat(glue("✓ Synthetic AFCARS episodes: {comma(nrow(afcars))} children across ",
         "{n_distinct(afcars$state)} states\n\n"))

###############################################################################
# ── 3. COST CALCULATIONS ─────────────────────────────────────────────────────
###############################################################################

# 3A. Merge daily rates
rate_lookup <- cost_params$daily_rate %>% select(placement_type, daily_rate_usd)

afcars <- afcars %>%
  left_join(rate_lookup, by = "placement_type") %>%
  mutate(
    # Direct placement cost
    direct_placement_cost = episode_days * daily_rate_usd,

    # Search cost for missing children
    search_cost = if_else(is_missing == 1, cost_params$search_cost_per_episode, 0),

    # Admin overhead (pro-rated to episode length)
    admin_cost = (episode_days / 365) * cost_params$admin_cost_per_child_year,

    # Indirect lifetime costs (applied once per child, weighted by time in care)
    #   Longer stays → higher share of adverse outcomes materialise
    exposure_weight = pmin(1, episode_days / 730),   # caps at ~2 years
    indirect_total  = exposure_weight *
      sum(cost_params$indirect_costs$per_child_lifetime_usd),

    # Grand total per episode
    total_cost = direct_placement_cost + search_cost + admin_cost + indirect_total
  )

cat("✓ Per-episode costs computed\n")

# ── 3B. National aggregation ─────────────────────────────────────────────────

national_summary <- afcars %>%
  summarise(
    n_children             = n(),
    total_episode_days     = sum(episode_days),
    mean_episode_days      = mean(episode_days),
    median_episode_days    = median(episode_days),
    direct_placement_total = sum(direct_placement_cost),
    search_costs_total     = sum(search_cost),
    admin_costs_total      = sum(admin_cost),
    indirect_costs_total   = sum(indirect_total),
    grand_total            = sum(total_cost),
    cost_per_child_avg     = mean(total_cost)
  )

# ── 3C. State-level aggregation ──────────────────────────────────────────────

state_summary <- afcars %>%
  group_by(state) %>%
  summarise(
    n_children             = n(),
    mean_episode_days      = round(mean(episode_days)),
    direct_placement_total = sum(direct_placement_cost),
    search_costs_total     = sum(search_cost),
    admin_costs_total      = sum(admin_cost),
    indirect_costs_total   = sum(indirect_total),
    grand_total            = sum(total_cost),
    cost_per_child         = mean(total_cost),
    .groups = "drop"
  ) %>%
  arrange(desc(grand_total))

cat("✓ National & state summaries aggregated\n")

###############################################################################
# ── 4. SCENARIO MODELING ─────────────────────────────────────────────────────
#    What if better dashboards / transparency tools reduce durations, missing
#    episodes, and admin friction?
###############################################################################

scenarios <- tibble::tribble(
  ~scenario,                       ~duration_reduction, ~missing_reduction, ~admin_reduction, ~annual_infra_cost,

  "Status Quo",                     0.00,               0.00,              0.00,              0,

  "Minimal Dashboard (Pilot)",      0.03,               0.10,              0.05,            5e6,
  "Moderate Transparency",          0.07,               0.25,              0.15,           18e6,
  "Full Transparency Platform",     0.10,               0.40,              0.25,           35e6,
  "Optimistic + Predictive AI",     0.15,               0.55,              0.35,           50e6
)

run_scenario <- function(sc) {
  afcars_sc <- afcars %>%
    mutate(
      episode_days_sc = round(episode_days * (1 - sc$duration_reduction)),
      is_missing_sc   = rbinom(n(), 1,
                               cost_params$pct_children_missing * (1 - sc$missing_reduction)),
      direct_sc   = episode_days_sc * daily_rate_usd,
      search_sc   = if_else(is_missing_sc == 1, cost_params$search_cost_per_episode, 0),
      admin_sc    = (episode_days_sc / 365) * cost_params$admin_cost_per_child_year *
                      (1 - sc$admin_reduction),
      exposure_sc = pmin(1, episode_days_sc / 730),
      indirect_sc = exposure_sc * sum(cost_params$indirect_costs$per_child_lifetime_usd),
      total_sc    = direct_sc + search_sc + admin_sc + indirect_sc
    )

  tibble(
    scenario         = sc$scenario,
    infra_cost       = sc$annual_infra_cost,
    direct_total     = sum(afcars_sc$direct_sc),
    search_total     = sum(afcars_sc$search_sc),
    admin_total      = sum(afcars_sc$admin_sc),
    indirect_total   = sum(afcars_sc$indirect_sc),
    grand_total      = sum(afcars_sc$total_sc),
    total_with_infra = sum(afcars_sc$total_sc) + sc$annual_infra_cost
  )
}

set.seed(99)
scenario_results <- scenarios %>%
  rowwise() %>%
  reframe(run_scenario(cur_data())) %>%
  ungroup() %>%
  mutate(
    savings_vs_sq     = first(grand_total) - grand_total,
    net_savings       = savings_vs_sq - infra_cost,
    roi_ratio         = if_else(infra_cost > 0, savings_vs_sq / infra_cost, NA_real_),
    pct_cost_avoided  = savings_vs_sq / first(grand_total) * 100
  )

cat("✓ 5 scenarios modeled\n")

###############################################################################
# ── 5. COST-DOMAIN BREAKDOWN TABLE ──────────────────────────────────────────
###############################################################################

domain_breakdown <- tibble(
  Domain = c("Direct Placement", "Missing-Child Search",
             "Administrative Overhead", "Indirect: Physical Health",
             "Indirect: Mental Health", "Indirect: Education Gaps",
             "Indirect: Criminal Justice", "Indirect: Homelessness",
             "Indirect: Substance Use"),
  Annual_National_Cost = c(
    national_summary$direct_placement_total,
    national_summary$search_costs_total,
    national_summary$admin_costs_total,
    # Split indirect by domain share
    national_summary$indirect_costs_total *
      cost_params$indirect_costs$per_child_lifetime_usd /
      sum(cost_params$indirect_costs$per_child_lifetime_usd)
  )
) %>%
  mutate(
    Pct_of_Total = Annual_National_Cost / sum(Annual_National_Cost) * 100,
    Cost_Label   = dollar(Annual_National_Cost, scale = 1e-9, suffix = "B",
                          accuracy = 0.01)
  )

cat("✓ Domain breakdown computed\n\n")

###############################################################################
# ── 6. VISUALIZATIONS ────────────────────────────────────────────────────────
###############################################################################

# ── 6A. WATERFALL CHART ──────────────────────────────────────────────────────

waterfall_data <- domain_breakdown %>%
  arrange(desc(Annual_National_Cost)) %>%
  mutate(
    Domain = fct_inorder(Domain),
    end    = cumsum(Annual_National_Cost),
    start  = lag(end, default = 0),
    fill_group = if_else(str_detect(Domain, "Indirect"), "Indirect", "Direct")
  )

# Add total bar
waterfall_data <- bind_rows(
  waterfall_data,
  tibble(
    Domain = "TOTAL", Annual_National_Cost = sum(waterfall_data$Annual_National_Cost),
    Pct_of_Total = 100, Cost_Label = dollar(sum(waterfall_data$Annual_National_Cost),
                                             scale = 1e-9, suffix = "B", accuracy = 0.01),
    start = 0, end = sum(waterfall_data$Annual_National_Cost), fill_group = "Total"
  )
) %>%
  mutate(Domain = fct_inorder(Domain))

color_map <- c("Direct" = "#2C6FAC", "Indirect" = "#E07B54", "Total" = "#333333")

p_waterfall <- ggplot(waterfall_data, aes(x = Domain)) +
  geom_rect(aes(xmin = as.numeric(Domain) - 0.4,
                xmax = as.numeric(Domain) + 0.4,
                ymin = start, ymax = end, fill = fill_group),
            color = "white", linewidth = 0.3) +
  geom_text(aes(y = end, label = Cost_Label),
            vjust = -0.5, size = 3.2, fontface = "bold") +
  scale_fill_manual(values = color_map, name = "Cost Type") +
  scale_y_continuous(labels = dollar_format(scale = 1e-9, suffix = "B"),
                     expand = expansion(mult = c(0, 0.12))) +
  labs(
    title    = "Annual National Cost of Foster-Care System Gaps",
    subtitle = "Waterfall decomposition across direct and indirect cost domains",
    x = NULL, y = "Cumulative Cost (2024 USD)"
  ) +
  theme(
    axis.text.x = element_text(angle = 35, hjust = 1, size = 10),
    legend.position = "top"
  )

ggsave(file.path(out_dir, "waterfall_chart.png"), p_waterfall,
       width = 13, height = 7, dpi = 300, bg = "white")
cat("✓ Waterfall chart saved\n")

# ── 6B. SCENARIO COMPARISON BAR CHART ────────────────────────────────────────

scenario_long <- scenario_results %>%
  select(scenario, direct_total, search_total, admin_total, indirect_total) %>%
  pivot_longer(-scenario, names_to = "cost_domain", values_to = "cost") %>%
  mutate(
    cost_domain = recode(cost_domain,
      direct_total   = "Direct Placement",
      search_total   = "Missing-Child Search",
      admin_total    = "Admin Overhead",
      indirect_total = "Indirect Lifetime"
    ),
    scenario = factor(scenario, levels = scenarios$scenario)
  )

p_scenario <- ggplot(scenario_long,
                     aes(x = scenario, y = cost, fill = cost_domain)) +
  geom_col(position = "stack", width = 0.7) +
  scale_y_continuous(labels = dollar_format(scale = 1e-9, suffix = "B"),
                     expand = expansion(mult = c(0, 0.05))) +
  scale_fill_brewer(palette = "Set2", name = "Cost Domain") +
  labs(
    title    = "Total System Cost Under Transparency Scenarios",
    subtitle = "Stacked by cost domain; excludes infrastructure investment cost",
    x = NULL, y = "Annual Cost (2024 USD)"
  ) +
  theme(axis.text.x = element_text(angle = 25, hjust = 1))

ggsave(file.path(out_dir, "scenario_comparison.png"), p_scenario,
       width = 12, height = 7, dpi = 300, bg = "white")
cat("✓ Scenario comparison chart saved\n")

# ── 6C. ROI DASHBOARD ────────────────────────────────────────────────────────

roi_data <- scenario_results %>% filter(!is.na(roi_ratio))

p_roi_bar <- ggplot(roi_data, aes(x = reorder(scenario, roi_ratio), y = roi_ratio)) +
  geom_col(fill = "#2C6FAC", width = 0.6) +
  geom_text(aes(label = paste0(round(roi_ratio, 1), "x")),
            hjust = -0.2, fontface = "bold", size = 4.5) +
  coord_flip() +
  scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
  labs(title = "Return on Investment Ratio",
       subtitle = "Gross savings ÷ infrastructure cost",
       x = NULL, y = "ROI Multiple")

p_net <- ggplot(roi_data, aes(x = reorder(scenario, net_savings), y = net_savings)) +
  geom_col(aes(fill = net_savings > 0), width = 0.6, show.legend = FALSE) +
  geom_text(aes(label = dollar(net_savings, scale = 1e-9, suffix = "B", accuracy = 0.1)),
            hjust = -0.15, fontface = "bold", size = 4) +
  coord_flip() +
  scale_fill_manual(values = c(`TRUE` = "#27AE60", `FALSE` = "#E74C3C")) +
  scale_y_continuous(labels = dollar_format(scale = 1e-9, suffix = "B"),
                     expand = expansion(mult = c(0.05, 0.2))) +
  labs(title = "Net Annual Savings After Infrastructure Cost",
       subtitle = "Green = positive net savings",
       x = NULL, y = "Net Savings (2024 USD)")

p_pct <- ggplot(roi_data, aes(x = reorder(scenario, pct_cost_avoided),
                              y = pct_cost_avoided)) +
  geom_segment(aes(xend = scenario, y = 0, yend = pct_cost_avoided),
               color = "grey50", linewidth = 1) +
  geom_point(size = 5, color = "#E07B54") +
  geom_text(aes(label = paste0(round(pct_cost_avoided, 1), "%")),
            hjust = -0.4, fontface = "bold", size = 4) +
  coord_flip() +
  scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
  labs(title = "Percent of System Costs Avoided",
       x = NULL, y = "% Reduction")

p_roi_dash <- (p_roi_bar | p_net) / p_pct +
  plot_annotation(
    title    = "ROI Dashboard: Investing in Child-Welfare Transparency Infrastructure",
    subtitle = "Based on AFCARS episode durations, published cost estimates, and CCOULD-linked multipliers",
    theme    = theme(
      plot.title    = element_text(face = "bold", size = 16),
      plot.subtitle = element_text(color = "grey40", size = 12)
    )
  )

ggsave(file.path(out_dir, "roi_dashboard.png"), p_roi_dash,
       width = 16, height = 11, dpi = 300, bg = "white")
cat("✓ ROI dashboard saved\n")

# ── 6D. STATE COST MAP (top-20 lollipop) ─────────────────────────────────────

top20 <- state_summary %>% slice_max(grand_total, n = 20)

p_state <- ggplot(top20, aes(x = reorder(state, grand_total), y = grand_total)) +
  geom_segment(aes(xend = state, y = 0, yend = grand_total),
               color = "#2C6FAC", linewidth = 1.2) +
  geom_point(size = 4, color = "#E07B54") +
  geom_text(aes(label = dollar(grand_total, scale = 1e-9, suffix = "B",
                                accuracy = 0.01)),
            hjust = -0.25, size = 3.5) +
  coord_flip() +
  scale_y_continuous(labels = dollar_format(scale = 1e-9, suffix = "B"),
                     expand = expansion(mult = c(0, 0.18))) +
  labs(
    title    = "Top 20 States by Estimated Total Foster-Care System Cost",
    subtitle = "Direct + indirect + admin + search costs combined",
    x = NULL, y = "Estimated Annual Cost (2024 USD)"
  )

ggsave(file.path(out_dir, "state_cost_ranking.png"), p_state,
       width = 11, height = 8, dpi = 300, bg = "white")
cat("✓ State ranking chart saved\n")

###############################################################################
# ── 7. SUMMARY TABLES ────────────────────────────────────────────────────────
###############################################################################

# 7A. National summary
national_table <- national_summary %>%
  pivot_longer(everything(), names_to = "Metric", values_to = "Value") %>%
  mutate(
    Metric = recode(Metric,
      n_children             = "Total Children in Care",
      total_episode_days     = "Total Episode-Days",
      mean_episode_days      = "Mean Episode Duration (days)",
      median_episode_days    = "Median Episode Duration (days)",
      direct_placement_total = "Direct Placement Costs",
      search_costs_total     = "Missing-Child Search Costs",
      admin_costs_total      = "Administrative Overhead",
      indirect_costs_total   = "Indirect Lifetime Costs",
      grand_total            = "Grand Total Annual Cost",
      cost_per_child_avg     = "Average Cost per Child"
    ),
    Value_Formatted = case_when(
      str_detect(Metric, "Cost|Total|Average|Overhead") ~
        dollar(Value, accuracy = 1),
      TRUE ~ comma(Value, accuracy = 1)
    )
  )

# 7B. Scenario table
scenario_table <- scenario_results %>%
  mutate(across(c(infra_cost, direct_total, search_total, admin_total,
                  indirect_total, grand_total, total_with_infra,
                  savings_vs_sq, net_savings),
                ~ dollar(.x, scale = 1e-6, suffix = "M", accuracy = 1))) %>%
  mutate(
    roi_ratio = if_else(is.na(roi_ratio), "—", paste0(round(roi_ratio, 1), "x")),
    pct_cost_avoided = paste0(round(pct_cost_avoided, 1), "%")
  )

# ── Write CSV outputs ────────────────────────────────────────────────────────

write_csv(domain_breakdown, file.path(out_dir, "cost_domain_breakdown.csv"))
write_csv(state_summary,    file.path(out_dir, "state_cost_summary.csv"))
write_csv(scenario_results, file.path(out_dir, "scenario_results.csv"))

cat("✓ CSV tables saved\n")

# ── Write Excel workbook ─────────────────────────────────────────────────────

write_xlsx(
  list(
    `National Summary`  = national_table,
    `Domain Breakdown`  = domain_breakdown,
    `State Summary`     = state_summary,
    `Scenario Analysis` = scenario_results,
    `Cost Parameters`   = bind_rows(
      cost_params$daily_rate %>% rename(item = placement_type, value = daily_rate_usd),
      cost_params$indirect_costs %>% rename(item = domain, value = per_child_lifetime_usd)
    )
  ),
  path = file.path(out_dir, "foster_care_cost_analysis.xlsx")
)

cat("✓ Excel workbook saved\n")

###############################################################################
# ── 8. ROI NARRATIVE (CONSOLE REPORT) ────────────────────────────────────────
###############################################################################

moderate <- scenario_results %>% filter(scenario == "Moderate Transparency")
full     <- scenario_results %>% filter(scenario == "Full Transparency Platform")

cat("\n")
cat("══════════════════════════════════════════════════════════\n")
cat("  ROI CASE FOR TRANSPARENCY INFRASTRUCTURE INVESTMENT\n")
cat("══════════════════════════════════════════════════════════\n\n")

cat(glue(
"CURRENT STATE
  • {comma(national_summary$n_children)} children served annually

  • Average episode: {round(national_summary$mean_episode_days)} days
  • Estimated annual system cost: {dollar(national_summary$grand_total, scale = 1e-9,
     suffix = 'B', accuracy = 0.1)}
    – Direct placement:  {dollar(national_summary$direct_placement_total,
       scale = 1e-9, suffix = 'B', accuracy = 0.1)}
    – Missing searches:  {dollar(national_summary$search_costs_total,
       scale = 1e-6, suffix = 'M', accuracy = 1)}
    – Admin overhead:    {dollar(national_summary$admin_costs_total,
       scale = 1e-9, suffix = 'B', accuracy = 0.1)}
    – Indirect lifetime: {dollar(national_summary$indirect_costs_total,
       scale = 1e-9, suffix = 'B', accuracy = 0.1)}

MODERATE TRANSPARENCY SCENARIO (7% duration cut, 25% missing reduction)
  • Infrastructure investment: {dollar(moderate$infra_cost, scale = 1e-6, suffix = 'M')}
  • Gross savings:  {dollar(moderate$savings_vs_sq, scale = 1e-9, suffix = 'B', accuracy = 0.1)}
  • Net savings:    {dollar(moderate$net_savings, scale = 1e-9, suffix = 'B', accuracy = 0.1)}
  • ROI multiple:   {round(moderate$roi_ratio, 1)}x
  • Cost avoided:   {round(moderate$pct_cost_avoided, 1)}%

FULL TRANSPARENCY SCENARIO (10% duration cut, 40% missing reduction)
  • Infrastructure investment: {dollar(full$infra_cost, scale = 1e-6, suffix = 'M')}
  • Gross savings:  {dollar(full$savings_vs_sq, scale = 1e-9, suffix = 'B', accuracy = 0.1)}
  • Net savings:    {dollar(full$net_savings, scale = 1e-9, suffix = 'B', accuracy = 0.1)}
  • ROI multiple:   {round(full$roi_ratio, 1)}x
  • Cost avoided:   {round(full$pct_cost_avoided, 1)}%

KEY ARGUMENT
  Every dollar invested in transparency dashboards yields
  approximately ${round(moderate$roi_ratio)} in reduced system costs,
  primarily through shorter placements and fewer missing episodes.
  Even conservative estimates show net savings exceeding
  {dollar(moderate$net_savings, scale = 1e-9, suffix = 'B', accuracy = 0.1)} annually.
"))

cat("\n\n══════════════════════════════════════════════════════════\n")
cat("  Outputs written to: ", normalizePath(out_dir), "\n")
cat("══════════════════════════════════════════════════════════\n")
